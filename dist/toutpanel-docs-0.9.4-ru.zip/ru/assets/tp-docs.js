(function (win, doc) {
  "use strict";
  var root = doc.documentElement;

  function bridge() {
    var dark = root.getAttribute("data-theme") === "dark";
    var b = doc.body;
    if (!b) { return; }
    b.setAttribute("data-md-color-scheme", dark ? "slate" : "default");
    b.setAttribute("data-md-color-primary", "custom");
    b.setAttribute("data-md-color-accent", "custom");
  }
  bridge();
  if (win.MutationObserver) {
    new win.MutationObserver(bridge).observe(root, { attributes: true, attributeFilter: ["data-theme"] });
  }

  var menu = doc.getElementById("menu");
  function closeAll(except) {
    var open = doc.querySelectorAll(".topnav .menu > li.open, .topnav .lang.open");
    for (var i = 0; i < open.length; i++) {
      if (open[i] !== except) {
        open[i].classList.remove("open");
        var bt = open[i].querySelector("button");
        if (bt) { bt.setAttribute("aria-expanded", "false"); }
      }
    }
  }
  var toggles = doc.querySelectorAll(".topnav .menu > li.has-drop > button, .topnav .lang > button");
  for (var i = 0; i < toggles.length; i++) {
    (function (bt) {
      bt.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var li = bt.parentElement, open = !li.classList.contains("open");
        closeAll(li);
        li.classList.toggle("open", open);
        bt.setAttribute("aria-expanded", open ? "true" : "false");
      });
    })(toggles[i]);
  }
  doc.addEventListener("click", function (ev) {
    if (ev.target && ev.target.closest && ev.target.closest(".topnav .lang .drop")) { return; }
    closeAll();
  });
  doc.addEventListener("keydown", function (ev) { if (ev.key === "Escape") { closeAll(); } });
  var burger = doc.getElementById("burger");
  if (burger && menu) {
    burger.addEventListener("click", function (ev) {
      ev.stopPropagation();
      var o = menu.classList.toggle("open");
      burger.setAttribute("aria-expanded", o ? "true" : "false");
    });
  }

  (function search() {
    var input = doc.querySelector(".md-search__input");
    var toggle = doc.querySelector("[data-md-toggle=search]");
    if (!input) { return; }
    var mac = /Mac|iPhone|iPad/.test((win.navigator && (win.navigator.platform || win.navigator.userAgent)) || "");
    var mod = doc.querySelector(".tp-kbd .tp-mod");
    if (mod && mac) { mod.textContent = "\u2318"; }
    doc.addEventListener("keydown", function (ev) {
      if ((ev.key === "k" || ev.key === "K") && (ev.ctrlKey || ev.metaKey) && !ev.altKey && !ev.shiftKey) {
        ev.preventDefault();
        if (toggle && !toggle.checked) {
          toggle.checked = true;
          toggle.dispatchEvent(new win.Event("change", { bubbles: true }));
        }
        input.focus();
        input.select();
      }
    });
  })();

  (function reveal() {
    var reduced = false;
    try { reduced = !!(win.matchMedia && win.matchMedia("(prefers-reduced-motion: reduce)").matches); } catch (e) { reduced = false; }
    if (reduced || !("IntersectionObserver" in win) || root.getAttribute("data-anim") === "off") { return; }
    var targets = doc.querySelectorAll(".md-typeset .admonition, .md-typeset details, .md-typeset .tabbed-set, .md-typeset .highlight, " +
      ".md-typeset__table, .md-typeset figure, .md-typeset > p > img, .md-typeset > p > a > img, .md-typeset .grid.cards > ul > li");
    if (!targets.length) { return; }
    var io = new win.IntersectionObserver(function (es) {
      for (var i = 0; i < es.length; i++) {
        if (es[i].isIntersecting) { es[i].target.classList.add("is-in"); io.unobserve(es[i].target); }
      }
    }, { threshold: 0.06, rootMargin: "0px 0px -4% 0px" });
    root.classList.add("tp-js");
    for (var i = 0; i < targets.length; i++) {
      var t = targets[i];
      if (t.parentNode && t.parentNode.closest && t.parentNode.closest(".tp-reveal")) { continue; }
      t.classList.add("tp-reveal");
      io.observe(t);
    }
    win.addEventListener("beforeprint", function () {
      var all = doc.querySelectorAll(".tp-reveal:not(.is-in)");
      for (var k = 0; k < all.length; k++) { all[k].classList.add("is-in"); }
    });
  })();

  (function spot() {
    var mq = function (q) { try { return win.matchMedia ? win.matchMedia(q).matches : false; } catch (e) { return false; } };
    if (mq("(prefers-reduced-motion: reduce)") || !mq("(hover: hover) and (pointer: fine)")) { return; }
    var cur = null, ev0 = null, pend = false;
    var raf = win.requestAnimationFrame ? win.requestAnimationFrame.bind(win) : function (f) { return setTimeout(f, 16); };
    function paint() {
      pend = false;
      if (!cur || !ev0) { return; }
      var r = cur.getBoundingClientRect();
      cur.style.setProperty("--mx", (ev0.clientX - r.left).toFixed(0) + "px");
      cur.style.setProperty("--my", (ev0.clientY - r.top).toFixed(0) + "px");
    }
    doc.addEventListener("pointermove", function (ev) {
      if (root.getAttribute("data-anim") === "off") { return; }
      var t = ev.target && ev.target.closest ? ev.target.closest(".md-typeset .grid.cards > ul > li") : null;
      if (!t) { cur = null; return; }
      cur = t; ev0 = ev;
      if (!pend) { pend = true; raf(paint); }
    }, { passive: true });
  })();

  (function tables() {
    var codes = doc.querySelectorAll(".md-typeset table code");
    for (var i = 0; i < codes.length; i++) {
      var c = codes[i], t = c.textContent;
      if (!t || /\s/.test(t) || c.children.length) { continue; }
      if (t.length <= 32) { c.classList.add("tp-nw"); continue; }
      if (t.indexOf("/") > 0) {
        var parts = t.split("/");
        c.textContent = "";
        for (var j = 0; j < parts.length; j++) {
          c.appendChild(doc.createTextNode(j < parts.length - 1 ? parts[j] + "/" : parts[j]));
          if (j < parts.length - 1) { c.appendChild(doc.createElement("wbr")); }
        }
      }
    }
  })();
})(window, document);
