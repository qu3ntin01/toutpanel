(function () {
  var KEY = "toutpanel-docs-lang";
  function run() {
    var links = document.querySelectorAll(".md-select__link[hreflang], a[data-tp-docs-lang]");
    if (!links.length) return;
    var rel = "";
    try {
      var cfg = JSON.parse(document.getElementById("__config").textContent);
      var root = new URL(cfg.base, location.href);
      rel = location.pathname.slice(root.pathname.length);
      rel = rel.replace(/index\.html$/, "");
    } catch (e) { return; }
    links.forEach(function (a) {
      try {
        var langRoot = new URL(a.getAttribute("href"), location.href);
        a.href = langRoot.pathname + rel + location.search + location.hash;
      } catch (e) {}
      a.addEventListener("click", function () {
        try { localStorage.setItem(KEY, a.getAttribute("hreflang")); } catch (e) {}
      });
    });
    window.addEventListener("hashchange", function () {
      links.forEach(function (a) { a.hash = location.hash; });
    });
  }
  if (window.document$ && window.document$.subscribe) window.document$.subscribe(run); else run();
})();
