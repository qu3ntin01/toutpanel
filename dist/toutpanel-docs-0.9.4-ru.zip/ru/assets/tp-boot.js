(function () {
  var r = document.documentElement;
  r.setAttribute("data-accent", "blue");
  r.classList.add("tp-docs");
})();
