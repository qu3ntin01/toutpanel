/* Bases de données, FTP, Sauvegardes, Tâches planifiées */
(function () {
  'use strict';
  const TP = window.TP, t = TP.t;

  // ---------------------------------------------------------------- Bases de données
  // Onglets : bases (utilisateurs, accès distant, tables, maintenance, import / export), serveurs Docker (administrateur),
  // Redis / Memcached par compte. Outils d'administration (Adminer, phpMyAdmin : connexion unique) et assistant de réplication pour l'administrateur.
  let dbTab = 'list';
  const ENGINE_LABELS = { mysql: 'MySQL / MariaDB', postgres: 'PostgreSQL', sqlite: 'SQLite', mongo: 'MongoDB' };
  const engineCls = (e) => e === 'mysql' ? 'info' : e === 'postgres' ? 'violet' : e === 'mongo' ? 'ok' : '';
  const tabsHtml = (tabs, active) => '<div class="tabs">' + tabs.map((x) => '<button' + (x[0] === active ? ' class="active"' : '') + ' data-tab="' + x[0] + '">' + TP.esc(x[1]) + '</button>').join('') + '</div>';
  const bindTabs = (bg, onChange) => TP.qsa('.tabs button', bg).forEach((b) => b.onclick = () => { TP.qsa('.tabs button', bg).forEach((x) => x.classList.toggle('active', x === b)); TP.qsa('[data-pane]', bg).forEach((pp) => pp.style.display = pp.dataset.pane === b.dataset.tab ? '' : 'none'); if (onChange) onChange(b.dataset.tab); });
  const sizeCell = (d) => { const s = Number(d.size_bytes) || 0; if (!d.quota_bytes) return '<span class="small">' + (d.size_checked_at || s ? TP.fmtBytes(s) : '<span class="muted">—</span>') + '</span>'; const pct = Math.min(100, Math.round(s * 100 / Math.max(1, d.quota_bytes))); return '<div class="small">' + TP.fmtBytes(s) + ' / ' + TP.fmtBytes(d.quota_bytes) + '</div><div class="progress' + (pct >= 95 ? ' danger' : pct >= 80 ? ' warn' : '') + '"><i style="width:' + pct + '%"></i></div>'; };
  const preOut = (txt) => '<pre class="pre dark" style="max-height:40vh;overflow:auto">' + TP.esc(txt || '') + '</pre>';

  async function openDatabase(d, data, reload) {
    const sql = d.engine !== 'sqlite';
    const tabs = [['info', t('Connexion')]].concat(sql ? [['users', t('Utilisateurs')]] : []).concat(sql && d.engine !== 'sqlite' ? [['remote', t('Accès distant')]] : [])
      .concat([['tables', d.engine === 'mongo' ? t('Collections') : t('Tables')], ['maint', t('Maintenance')], ['io', t('Import / export')]]);
    const pane = (id) => '<div data-pane="' + id + '"' + (id !== 'info' ? ' style="display:none"' : '') + '><div data-body="' + id + '">' + TP.loading() + '</div></div>';
    const m = TP.modal({ title: d.name + ' · ' + (ENGINE_LABELS[d.engine] || d.engine), size: 'xl', body: tabsHtml(tabs, 'info') + tabs.map((x) => pane(x[0])).join(''), footer: '<button class="btn" data-close>' + t('Fermer') + '</button>', onClose: reload });
    const bg = m.el; const body = (id) => TP.qs('[data-body="' + id + '"]', bg);
    const canEdit = TP.can('databases', 'edit');
    const loaders = {
      async info() {
        const r = await TP.get('/api/databases/' + d.id + '/details'); const x = r.data;
        body('info').innerHTML = '<dl class="kv">' +
          '<dt>' + t('Base') + '</dt><dd class="mono">' + TP.esc(x.name) + '</dd>' +
          (sql ? '<dt>' + t('Hôte') + '</dt><dd class="mono">' + TP.esc(x.connect_host) + (x.connect_port ? ':' + x.connect_port : '') + (x.server ? ' ' + TP.badge(t('Serveur') + ' ' + x.server.name + ' (' + x.server.image + ')', 'info') : '') + '</dd>' +
            '<dt>' + t('Utilisateur principal') + '</dt><dd class="mono">' + TP.esc(x.username) + '</dd>' +
            '<dt>' + t('Mot de passe') + '</dt><dd><span class="mono" data-pw>••••••••</span> <button class="btn xs ghost" data-show>' + TP.icon('eye') + '</button><button class="btn xs ghost" data-copypw>' + TP.icon('copy') + '</button></dd>' : '<dt>' + t('Fichier') + '</dt><dd class="mono small">' + TP.esc(x.host) + '</dd>') +
          '<dt>' + t('Taille') + '</dt><dd>' + (x.size_error ? '<span class="muted small">' + TP.esc(x.size_error) + '</span>' : TP.fmtBytes(x.size_bytes || 0)) + (x.quota_bytes ? ' / ' + TP.fmtBytes(x.quota_bytes) + ' ' + t('(quota du plan)') : '') + '</dd>' +
          (x.over_quota ? '<dt></dt><dd>' + TP.badge(t('Quota dépassé : écritures suspendues'), 'danger') + '</dd>' : '') +
          '</dl>' + ((x.dbadmin_tools || []).length && canEdit ? '<div class="mt row">' + x.dbadmin_tools.map((k) => '<button class="btn' + (k === x.dbadmin_default ? ' primary' : '') + '" data-open="' + k + '">' + TP.icon('external') + openLabel(k) + '</button>').join('') + '</div>' : '');
        const pw = TP.qs('[data-pw]', bg);
        if (pw) { const reveal = async () => (await TP.get('/api/databases/' + d.id + '/reveal')).data.password; /* lecture explicite, journalisée côté serveur */ TP.qs('[data-show]', bg).onclick = async () => { try { pw.textContent = pw.textContent.startsWith('•') ? await reveal() : '••••••••'; } catch (e) { TP.toast(e.message, 'error'); } }; TP.qs('[data-copypw]', bg).onclick = async () => { try { TP.copy(await reveal()); } catch (e) { TP.toast(e.message, 'error'); } }; }
        TP.qsa('[data-open]', bg).forEach((ob) => ob.onclick = () => openDbTool(d, ob.dataset.open));
      },
      async users() {
        const r = await TP.get('/api/databases/' + d.id + '/users'); const privs = r.data.privileges || [];
        const privLabel = (u) => u.readonly ? TP.badge(t('Lecture seule'), '') : (u.privileges || []).includes('ALL') ? TP.badge(t('Tous les privilèges'), 'info') : (u.privileges || []).map((p) => '<code>' + TP.esc(p) + '</code>').join(' ');
        body('users').innerHTML = (canEdit ? '<div class="row between mb"><span class="muted small">' + t('Chaque utilisateur reçoit exactement les privilèges cochés sur cette base.') + '</span><button class="btn sm primary" data-uadd>' + TP.icon('plus') + t('Nouvel utilisateur') + '</button></div>' : '') +
          TP.table([
            { label: t('Utilisateur'), render: (u) => '<b class="mono">' + TP.esc(u.username) + '</b>' + (u.primary ? ' ' + TP.badge(t('principal'), 'ok') : '') },
            { label: t('Hôte'), cls: 'mono small', render: (u) => d.engine === 'mysql' ? TP.esc(u.host) + ((r.data.remote_ips || []).length ? ' <span class="muted">+ ' + r.data.remote_ips.length + ' IP</span>' : '') : '<span class="muted">—</span>' },
            { label: t('Privilèges'), render: privLabel },
            { label: t('Mot de passe'), render: (u) => '<button class="btn xs ghost" data-ucopy="' + u.id + '">' + TP.icon('copy') + t('Copier') + '</button>' },
            { label: '', cls: 'r', render: (u) => canEdit ? '<div class="actions"><button class="btn xs" data-uedit="' + u.id + '">' + TP.icon('edit') + '</button>' + (u.primary ? '' : '<button class="btn xs danger" data-udel="' + u.id + '">' + TP.icon('trash') + '</button>') + '</div>' : '' },
          ], r.data.users, { empty: t('Aucun utilisateur'), icon: 'users' });
        const form = (u) => '<div class="form">' + (u ? '' : TP.field('username', t('Utilisateur'), { placeholder: 'app_lecture' })) + '<div class="f2">' + TP.field('password', t('Mot de passe'), { placeholder: u ? t('inchangé') : t('généré automatiquement') }) +
          (d.engine === 'mysql' ? TP.field('host', t('Hôte autorisé'), { value: u ? u.host : 'localhost', hint: t('localhost, une IP ou % ; les IP de l\'accès distant s\'ajoutent automatiquement.') }) : '<div></div>') + '</div>' +
          TP.field('readonly', t('Lecture seule (SELECT uniquement : réplica, rapports, outils d\'analyse)'), { type: 'checkbox', value: u ? u.readonly : false }) +
          '<div class="field" data-privs><label>' + t('Privilèges') + '</label><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px 14px">' + privs.map((p) => TP.field('priv_' + p, p === 'ALL' ? t('ALL (tous)') : p, { type: 'checkbox', value: u ? (u.privileges || []).includes(p) : p === 'ALL' })).join('') + '</div>' +
          (d.engine === 'postgres' ? '<div class="hint">' + t('PostgreSQL : DROP, ALTER et INDEX restent réservés au propriétaire de la base (utilisateur principal).') + '</div>' : d.engine === 'mongo' ? '<div class="hint">' + t('MongoDB : lecture seule → rôle read, sinon readWrite.') + '</div>' : '') + '</div></div>';
        const collect = (fbg) => { const f = TP.formData(fbg); const out = { password: f.password || '', readonly: !!f.readonly, privileges: privs.filter((p) => f['priv_' + p]) }; if (f.username !== undefined) out.username = f.username; if (f.host !== undefined) out.host = f.host; return out; };
        const wire = (fbg) => { const ro = TP.qs('[name=readonly]', fbg), box = TP.qs('[data-privs]', fbg); const upd = () => { box.style.opacity = ro.checked ? '.4' : ''; TP.qsa('[data-privs] input', fbg).forEach((i) => i.disabled = ro.checked); }; ro.onchange = upd; upd(); };
        const add = TP.qs('[data-uadd]', bg); if (add) add.onclick = () => TP.modal({ title: t('Nouvel utilisateur'), body: form(null), okText: t('Créer'), onOpen: wire, onOk: async (fbg) => { const rr = await TP.post('/api/databases/' + d.id + '/users', collect(fbg)); TP.modal({ title: t('Utilisateur créé'), body: '<dl class="kv"><dt>' + t('Utilisateur') + '</dt><dd class="mono">' + TP.esc(rr.data.username) + '</dd><dt>' + t('Mot de passe') + '</dt><dd class="mono">' + TP.esc(rr.data.password) + '</dd></dl>', footer: '<button class="btn primary" data-close>OK</button>' }); loaders.users(); } });
        TP.qsa('[data-ucopy]', bg).forEach((b) => b.onclick = async () => { try { TP.copy((await TP.get('/api/databases/' + d.id + '/users/' + b.dataset.ucopy + '/reveal')).data.password); } catch (e) { TP.toast(e.message, 'error'); } });
        TP.qsa('[data-uedit]', bg).forEach((b) => b.onclick = () => { const u = r.data.users.find((x) => x.id === Number(b.dataset.uedit)); TP.modal({ title: t('Modifier') + ' · ' + u.username, body: form(u), okText: t('Enregistrer'), onOpen: wire, onOk: async (fbg) => { const c = collect(fbg); if (!c.password) delete c.password; await TP.put('/api/databases/' + d.id + '/users/' + u.id, c); TP.toast(t('Utilisateur mis à jour')); loaders.users(); } }); });
        TP.qsa('[data-udel]', bg).forEach((b) => b.onclick = async () => { const u = r.data.users.find((x) => x.id === Number(b.dataset.udel)); if (await TP.confirm(t('Supprimer'), t('Supprimer l\'utilisateur {n} ?', { n: '<b>' + TP.esc(u.username) + '</b>' }), { danger: true })) { try { await TP.del('/api/databases/' + d.id + '/users/' + u.id); loaders.users(); } catch (e) { TP.toast(e.message, 'error'); } } });
      },
      async remote() {
        const r = await TP.get('/api/databases/' + d.id + '/users');
        body('remote').innerHTML = '<div class="alert info mb">' + TP.icon('info') + '<div>' + t('Adresses IP ou réseaux (CIDR) autorisés à se connecter directement à la base. Le port du moteur est ouvert dans le pare-feu pour ces adresses seulement ; vide = accès local uniquement.') + '</div></div>' +
          '<div class="form">' + TP.field('ips', t('IP / réseaux autorisés'), { type: 'textarea', rows: 4, value: (r.data.remote_ips || []).join('\n'), placeholder: '203.0.113.10\n198.51.100.0/24' }) + '</div>' +
          (canEdit ? '<button class="btn primary" data-rsave>' + TP.icon('check') + t('Enregistrer') + '</button>' : '') + '<div data-rmsg class="mt"></div>';
        const sv = TP.qs('[data-rsave]', bg); if (sv) sv.onclick = async () => { sv.disabled = true; try { const ips = TP.qs('[name=ips]', bg).value.split(/[\s,;]+/).filter(Boolean); const rr = await TP.put('/api/databases/' + d.id + '/remote', { ips }); TP.toast(rr.msg); TP.qs('[data-rmsg]', bg).innerHTML = (rr.data.messages || []).length ? preOut(rr.data.messages.join('\n')) : ''; } catch (e) { TP.toast(e.message, 'error'); } sv.disabled = false; };
      },
      async tables() {
        const r = await TP.get('/api/databases/' + d.id + '/tables');
        body('tables').innerHTML = TP.table([
          { label: t('Nom'), cls: 'mono', render: (x) => TP.esc(x.name) },
          { label: t('Lignes'), cls: 'r', render: (x) => String(x.rows) },
          { label: t('Données'), cls: 'r', render: (x) => TP.fmtBytes(x.data) },
          { label: t('Index'), cls: 'r', render: (x) => TP.fmtBytes(x.index) },
          { label: t('Total'), cls: 'r', render: (x) => '<b>' + TP.fmtBytes(x.size) + '</b>' },
        ], r.data, { empty: t('Aucune table'), icon: 'db' });
      },
      async maint() {
        const acts = d.engine === 'mongo' ? [['check', t('Vérifier')]] : [['check', t('Vérifier')], ['repair', t('Réparer')], ['optimize', t('Optimiser')], ['analyze', t('Analyser')]];
        body('maint').innerHTML = '<p class="muted small">' + (d.engine === 'mysql' ? t('mysqlcheck sur toutes les tables de la base.') : d.engine === 'postgres' ? t('VACUUM, ANALYZE et REINDEX sur la base.') : d.engine === 'sqlite' ? t('PRAGMA integrity_check, REINDEX, VACUUM et ANALYZE.') : t('validate sur chaque collection.')) + '</p>' +
          '<div class="row">' + acts.map((a) => '<button class="btn" data-m="' + a[0] + '"' + (canEdit ? '' : ' disabled') + '>' + TP.esc(a[1]) + '</button>').join('') + '</div><div data-mout class="mt"></div>';
        TP.qsa('[data-m]', bg).forEach((b) => b.onclick = async () => { TP.qsa('[data-m]', bg).forEach((x) => x.disabled = true); TP.qs('[data-mout]', bg).innerHTML = TP.loading(); try { const rr = await TP.api('POST', '/api/databases/' + d.id + '/maintenance', { action: b.dataset.m }, { timeout: 3600000 }); TP.qs('[data-mout]', bg).innerHTML = preOut(rr.data.output); } catch (e) { TP.qs('[data-mout]', bg).innerHTML = '<div class="alert danger">' + TP.esc(e.message) + '</div>'; } TP.qsa('[data-m]', bg).forEach((x) => x.disabled = false); });
      },
      async io() {
        const canImport = TP.can('databases', 'import');
        body('io').innerHTML = '<div class="card mb"><div class="card-h"><h3>' + t('Exporter') + '</h3></div><div class="card-b"><p class="muted small">' + t('Dump compressé (gzip) produit à la volée et téléchargé directement.') + '</p>' +
          '<div class="row"><a class="btn" href="/api/databases/' + d.id + '/export">' + TP.icon('download') + t('Télécharger le dump') + '</a><button class="btn" data-bk>' + TP.icon('backup') + t('Sauvegarder') + '</button>' + (TP.can('cron', 'create') || TP.can('cron', 'edit') ? '<button class="btn" data-plan>' + TP.icon('clock') + t('Planifier') + '</button>' : '') + '</div></div></div>' +
          (canImport ? '<div class="card"><div class="card-h"><h3>' + t('Importer') + '</h3></div><div class="card-b"><div class="alert warn mb">' + TP.icon('alert') + '<div>' + t('Les instructions du fichier sont exécutées dans la base (les tables existantes peuvent être remplacées).') + '</div></div>' +
            '<div class="row"><input type="file" class="input" data-file accept=".sql,.gz,.zip,.archive,.dump,.psql" style="flex:1"><button class="btn primary" data-up>' + TP.icon('upload') + t('Envoyer et importer') + '</button></div><div class="hint">' + (d.engine === 'mongo' ? t('Archive mongodump (--archive, éventuellement --gzip).') : t('.sql, .sql.gz ou .zip contenant un .sql ; envoi en flux, taille max réglable (db_import_max_mb).')) + '</div>' +
            '<div class="row mt"><input class="input" data-path placeholder="' + t('ou chemin d\'un fichier sur le serveur (dans vos sites)') + '" style="flex:1"><button class="btn" data-imp>' + TP.icon('upload') + t('Importer ce fichier') + '</button></div></div></div>' : '');
        TP.qs('[data-bk]', bg).onclick = async () => { try { const rr = await TP.post('/api/backups', { kind: 'database', target: String(d.id) }); TP.taskModal(rr.data.task_id, t('Sauvegarde') + ' · ' + d.name); } catch (e) { TP.toast(e.message, 'error'); } };
        const pl = TP.qs('[data-plan]', bg); if (pl) pl.onclick = () => TP.modal({ title: t('Planifier la sauvegarde') + ' · ' + d.name, body: '<div class="form">' + TP.field('schedule', t('Fréquence'), { type: 'select', value: '0 3 * * *', options: [['0 3 * * *', t('Chaque jour à 3h')], ['0 */6 * * *', t('Toutes les 6 heures')], ['0 3 * * 0', t('Chaque semaine')], ['0 3 1 * *', t('Chaque mois')]] }) + '</div>', okText: t('Créer la tâche'),
          onOk: async (fbg) => { await TP.post('/api/cron', { name: t('Sauvegarde base') + ' ' + d.name, schedule: TP.formData(fbg).schedule, job_type: 'backup_db', target: String(d.id), enabled: true }); TP.toast(t('Tâche planifiée créée')); } });
        const up = TP.qs('[data-up]', bg); if (up) up.onclick = async () => { const f = TP.qs('[data-file]', bg).files[0]; if (!f) return TP.toast(t('Choisissez un fichier'), 'warn'); up.disabled = true; try { const fd = new FormData(); fd.append('file', f); const rr = await TP.api('POST', '/api/databases/' + d.id + '/import/upload', fd, { timeout: 6 * 3600000 }); TP.taskModal(rr.data.task_id, t('Import') + ' · ' + d.name); } catch (e) { TP.toast(e.message, 'error'); } up.disabled = false; };
        const imp = TP.qs('[data-imp]', bg); if (imp) imp.onclick = async () => { const p = TP.qs('[data-path]', bg).value.trim(); if (!p) return; imp.disabled = true; try { const rr = await TP.api('POST', '/api/databases/' + d.id + '/import', { path: p }, { timeout: 6 * 3600000 }); TP.toast(rr.msg); } catch (e) { TP.toast(e.message, 'error'); } imp.disabled = false; };
      },
    };
    const loaded = {};
    const load = async (tab) => { if (loaded[tab] || !loaders[tab]) return; loaded[tab] = true; try { await loaders[tab](); } catch (e) { loaded[tab] = false; body(tab).innerHTML = '<div class="alert danger">' + TP.esc(e.message) + '</div>'; } };
    bindTabs(bg, load); load('info');
  }

  // ---------------------------------------------------------------- Outils d'administration : Adminer et phpMyAdmin (connexion unique)
  const TOOL_NAMES = { adminer: 'Adminer', phpmyadmin: 'phpMyAdmin' };
  const TOOL_ENGINES = { adminer: ['mysql', 'postgres'], phpmyadmin: ['mysql'] };
  const toolsFor = (engine, installed) => (installed || []).filter((k) => (TOOL_ENGINES[k] || []).includes(engine));
  const openLabel = (k) => k === 'phpmyadmin' ? t('Ouvrir dans phpMyAdmin') : t('Ouvrir dans Adminer');

  async function openDbTool(d, tool) {
    try { const r = await TP.post('/api/databases/' + d.id + '/open', tool ? { tool } : undefined); window.open(r.data.url, '_blank', 'noopener'); } catch (e) { TP.toast(e.message, 'error'); }
  }

  // menu « Ouvrir avec » (position fixe sous le bouton : jamais coupé par le tableau)
  function closeOpenMenu() { const m = TP.qs('.dbm'); if (m) { m.remove(); document.removeEventListener('click', closeOpenMenu, true); document.removeEventListener('keydown', menuKeys, true); } }
  function menuKeys(e) { if (e.key === 'Escape') { const m = TP.qs('.dbm'); const a = m && m._opener; closeOpenMenu(); if (a) a.focus(); } }
  function openMenu(btn, d, tools, def) {
    closeOpenMenu();
    const m = document.createElement('div'); m.className = 'dbm'; m.setAttribute('role', 'menu'); m.setAttribute('aria-label', t('Ouvrir avec')); m._opener = btn;
    m.innerHTML = '<div class="dbm-h">' + TP.esc(t('Ouvrir avec')) + '</div>' + tools.map((k) => '<button type="button" role="menuitem" class="dbm-i" data-tool="' + k + '"><b>' + TOOL_NAMES[k] + '</b>' + (k === def ? '<span class="muted small">' + TP.esc(t('par défaut')) + '</span>' : '') + '</button>').join('');
    document.body.appendChild(m);
    const r = btn.getBoundingClientRect(), w = m.offsetWidth;
    m.style.top = Math.min(window.innerHeight - m.offsetHeight - 8, r.bottom + 4) + 'px'; m.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + 'px';
    TP.qsa('.dbm-i', m).forEach((i) => i.onclick = () => { closeOpenMenu(); openDbTool(d, i.dataset.tool); });
    const first = TP.qs('.dbm-i', m); if (first) first.focus();
    m.onkeydown = (e) => { const items = TP.qsa('.dbm-i', m), i = items.indexOf(document.activeElement); if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length].focus(); } else if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); } };
    setTimeout(() => { document.addEventListener('click', (e) => { if (!m.contains(e.target)) closeOpenMenu(); }, true); document.addEventListener('keydown', menuKeys, true); }, 0);
  }

  const vnum = (v) => String(v || '').split('.').map((x) => parseInt(x, 10) || 0);
  const vcmp = (a, b) => { const x = vnum(a), y = vnum(b); for (let i = 0; i < 2; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
  // compatibilité d'une version (lignes de GET /dbadmin/{outil}/versions : php_min, php_max) avec une version de PHP
  const phpOk = (v, php) => !php || (vcmp(php, v.php_min) >= 0 && (!v.php_max || vcmp(php, v.php_max) <= 0));
  const phpRange = (v) => v.php_max ? 'PHP ' + v.php_min + ' – ' + v.php_max : 'PHP ' + v.php_min + '+';

  // formulaire d'installation (outil non installé) ou de changement de version (outil installé) : liste complète des versions
  // publiées avec badge de compatibilité PHP, choix de la version de PHP du site, domaine
  async function toolModal(s, tool, reload) {
    const cur = s[tool], change = cur.installed, hasSite = !!s.site_id;
    let vers = [], loaded = false, error = '', dbServer = '';
    const phps = s.php_versions || [];
    const effPhp = (bg) => { const f = TP.formData(bg); return f.php_version || s.php_version || s.default_php || ''; };
    const m = TP.modal({ title: change ? t('Changer de version') + ' · ' + TOOL_NAMES[tool] : t('Installer') + ' · ' + TOOL_NAMES[tool], size: 'lg', okText: change ? t('Changer de version') : t('Installer'),
      body: '<div class="form dba-form">' + (change ? '<div class="alert info">' + TP.icon('info') + '<div>' + t('Version installée') + ' : <b>' + TP.esc(cur.version || '?') + '</b>. ' + t('La configuration et la connexion unique sont conservées ; la version précédente est sauvegardée puis rétablie automatiquement si le changement échoue.') + '</div></div>' : '') +
        (change ? '' : TP.field('tool', t('Outil'), { type: 'select', value: tool, options: [['adminer', 'Adminer · MySQL / MariaDB, PostgreSQL'], ['phpmyadmin', 'phpMyAdmin · MySQL / MariaDB']] })) +
        '<div class="f2"><div><div class="field"><label for="dba-version">' + TP.esc(t('Version')) + '</label><select class="input" id="dba-version" name="version" aria-label="' + TP.esc(t('Version')) + '"><option value="">' + TP.esc(t('Chargement des versions…')) + '</option></select></div>' +
        TP.field('prerelease', t('Afficher les préversions (alpha, bêta, rc)'), { type: 'checkbox', value: false }) + '</div>' +
        '<div>' + TP.field('php_version', t('Version de PHP du site'), { type: 'select', value: change ? (s.php_version || '') : '', options: [['', t('Par défaut') + (s.php_version || s.default_php ? ' (PHP ' + (s.php_version || s.default_php) + ')' : '')]].concat(phps.map((p) => [p, 'PHP ' + p])), hint: t('Adminer et phpMyAdmin partagent la même version de PHP (celle du site « dbadmin » s\'il existe, sinon celle du vhost local).') }) + '</div></div>' +
        '<div data-compat class="dba-compat" aria-live="polite"></div>' +
        (change ? '' : TP.field('domain', t('Domaine dédié (facultatif)'), { value: s.domain || '', placeholder: 'db.exemple.fr', hint: hasSite ? t('Le site « dbadmin » existe déjà : le domaine est conservé s\'il reste vide.') : t('Laissez vide : l\'outil s\'ouvre sous le panel, sans nom de domaine ni DNS. Un domaine ajoute un accès dédié (site PHP « dbadmin », déjà pointé vers ce serveur).') })) + '</div>',
      onOpen: async (bg) => {
        const sel = TP.qs('[name=version]', bg), box = TP.qs('[data-compat]', bg), ok = TP.qs('[data-ok]', bg);
        const curTool = () => TP.qs('[name=tool]', bg) ? TP.qs('[name=tool]', bg).value : tool;
        const draw = () => {
          const f = TP.formData(bg), php = effPhp(bg), keep = f.version;
          const rows = vers.filter((v) => f.prerelease || !v.prerelease || v.version === keep);
          const groups = []; rows.forEach((v) => { let g = groups[groups.length - 1]; if (!g || g.b !== v.branch) { g = { b: v.branch, rows: [], v }; groups.push(g); } g.rows.push(v); });
          const latestV = (vers.find((v) => !v.prerelease && phpOk(v, php)) || {}).version;
          sel.innerHTML = '<option value="">' + TP.esc(latestV ? t('Dernière version stable compatible') + ' (' + latestV + ')' : t('Dernière version stable compatible')) + '</option>' +
            groups.map((g) => '<optgroup label="' + TP.esc(g.b + ' · ' + phpRange(g.v)) + '">' + g.rows.map((v) => '<option value="' + TP.esc(v.version) + '"' + (v.version === keep ? ' selected' : '') + '>' + TP.esc(v.version + (v.prerelease ? ' (' + t('préversion') + ')' : '') + ' — ' + (phpOk(v, php) ? t('compatible avec PHP {v}', { v: php }) : t('incompatible avec PHP {v}', { v: php }))) + '</option>').join('') + '</optgroup>').join('');
          const chosen = vers.find((v) => v.version === sel.value) || vers.find((v) => v.version === latestV);
          let html = '', block = false;
          if (error && !loaded) html = '<div class="alert danger">' + TP.icon('alert') + '<div>' + TP.esc(error) + '</div></div>';
          else if (chosen) {
            const good = phpOk(chosen, php);
            html = '<div class="dba-badges">' + TP.badge(TOOL_NAMES[curTool()] + ' ' + chosen.version, chosen.prerelease ? 'warn' : 'info') + ' ' + (php ? TP.badge(good ? t('compatible avec PHP {v}', { v: php }) : t('incompatible avec PHP {v}', { v: php }), good ? 'ok' : 'danger') : '') + ' ' + TP.badge(phpRange(chosen) + (chosen.php_approx && curTool() === 'phpmyadmin' ? ' (' + t('indicatif') + ')' : ''), '') +
              (chosen.db_compat ? ' ' + TP.badge(chosen.db_compat === 'ok' ? t('compatible avec {s}', { s: dbServer }) : t('à vérifier avec {s}', { s: dbServer }), chosen.db_compat === 'ok' ? 'ok' : 'warn') : '') + '</div>';
            if (!good) {
              block = true;
              const sug = []; const seen = {}; vers.forEach((v) => { if (!v.prerelease && phpOk(v, php) && !seen[v.branch] && sug.length < 3) { seen[v.branch] = 1; sug.push(v.version); } });
              html += '<div class="alert warn mt">' + TP.icon('alert') + '<div>' + t('Cette version n\'est pas compatible avec PHP {v}.', { v: php }) + ' ' + (sug.length ? t('Versions compatibles : {l}.', { l: sug.join(', ') }) : t('Aucune version publiée n\'est compatible avec PHP {v}.', { v: php })) + '</div></div>';
            }
            if (chosen.prerelease) html += '<div class="hint mt">' + t('Préversion : réservée aux essais.') + '</div>';
          } else if (loaded) html = '<div class="hint">' + t('Aucune version trouvée.') + '</div>';
          box.innerHTML = html; ok.disabled = block || !loaded;
        };
        const load = async () => {
          loaded = false; error = ''; draw();
          try { const r = await TP.get('/api/databases/dbadmin/' + curTool() + '/versions?prerelease=true'); vers = r.data.versions || []; dbServer = r.data.db_server || t('le serveur de bases'); loaded = true; if (r.data.error) TP.toast(t('Sources officielles injoignables : liste en cache utilisée'), 'warn'); } catch (e) { error = e.message; }
          draw();
        };
        bg.addEventListener('change', (e) => { if (e.target.name === 'tool') { sel.value = ''; const h = TP.qs('.modal-h h3', bg); if (h) h.textContent = t('Installer') + ' · ' + TOOL_NAMES[curTool()]; load(); } else draw(); });
        await load();
        if (change && cur.version) { const o = TP.qs('option[value="' + cur.version + '"]', sel); if (o) { o.selected = true; draw(); } }
      },
      onOk: async (bg, close) => {
        const f = TP.formData(bg); const tl = f.tool || tool;
        const rr = change ? await TP.post('/api/databases/dbadmin/' + tl + '/update', { version: f.version || '', php_version: f.php_version || '' })
          : await TP.post('/api/databases/dbadmin/install', { tool: tl, version: f.version || '', domain: f.domain || '', php_version: f.php_version || '' });
        close(); TP.taskModal(rr.data.task_id, (change ? t('Changement de version') : t('Installation')) + ' · ' + TOOL_NAMES[tl], () => reload());
        return false;
      } });
    return m;
  }

  // onglet « Outils d'administration » (administrateur)
  async function renderTools(box, reload) {
    const r = await TP.get('/api/databases/dbadmin'); const s = r.data;
    const info = { adminer: t('Un seul fichier PHP : MySQL / MariaDB et PostgreSQL.'), phpmyadmin: t('L\'administration MySQL / MariaDB la plus répandue ; installée depuis l\'archive officielle (somme SHA-256 vérifiée).') };
    const row = (x) => {
      const phpTxt = x.php_effective ? 'PHP ' + x.php_effective : '';
      return '<div class="dba-row" data-tool="' + x.tool + '"><div class="dba-id"><span class="dba-logo ' + x.tool + '" aria-hidden="true">' + (x.tool === 'phpmyadmin' ? 'Ph' : 'Ad') + '</span><div><h4>' + TOOL_NAMES[x.tool] + '</h4><p class="muted small">' + TP.esc(info[x.tool]) + '</p></div></div>' +
        '<div class="dba-state">' + (x.installed ? TP.badge(t('Installé') + ' ' + (x.version || ''), 'ok') : TP.badge(t('Non installé'), '')) +
        (x.update_available ? ' ' + TP.badge(t('Mise à jour disponible') + ' : ' + x.latest, 'warn') : x.installed && x.latest ? ' <span class="muted small">' + t('Dernière version stable') + ' : ' + TP.esc(x.latest) + '</span>' : x.latest ? ' <span class="muted small">' + t('Dernière version stable') + ' : ' + TP.esc(x.latest) + '</span>' : '') +
        (x.installed && x.php_ok === false ? '<div class="alert warn mt">' + TP.icon('alert') + '<div>' + t('La version installée n\'est pas compatible avec {p} : changez de version.', { p: phpTxt }) + '</div></div>' : '') +
        (x.installed && x.url ? '<div class="small mt">' + t('Domaine dédié') + ' : <a href="' + TP.esc(x.url) + '" target="_blank" rel="noopener" class="mono">' + TP.esc(x.url) + '</a>' + (phpTxt ? ' <span class="muted">· ' + TP.esc(phpTxt) + '</span>' : '') + '</div>' : '') +
        (x.installed && x.panel_path ? '<div class="small mt">' + t('Sous le panel (sans nom de domaine)') + ' : <span class="mono">' + TP.esc(x.panel_path) + '</span>' + (!x.url && phpTxt ? ' <span class="muted">· ' + TP.esc(phpTxt) + '</span>' : '') + '</div>' : '') +
        (x.installed && x.previous_version ? '<div class="muted small mt">' + t('Version précédente sauvegardée') + ' : ' + TP.esc(x.previous_version) + '</div>' : '') + '</div>' +
        '<div class="dba-actions">' + (x.installed
          ? (x.update_available ? '<button class="btn sm primary" data-up="' + x.tool + '">' + TP.icon('download') + t('Mettre à jour') + '</button>' : '') + '<button class="btn sm" data-ch="' + x.tool + '">' + TP.icon('refresh') + t('Changer de version') + '</button><button class="btn sm danger" data-un="' + x.tool + '">' + TP.icon('trash') + t('Désinstaller') + '</button>'
          : '<button class="btn sm primary" data-in="' + x.tool + '">' + TP.icon('download') + t('Installer') + '</button>') + '</div></div>';
    };
    const both = s.tools.every((x) => x.installed);
    box.innerHTML = '<div class="card dba-card"><div class="card-h"><h3>' + t('Outils d\'administration') + '</h3><div class="actions"><button class="btn sm" data-check>' + TP.icon('search') + t('Rechercher les nouvelles versions') + '</button></div></div><div class="card-b">' +
      '<p class="muted small">' + t('Adminer et phpMyAdmin s\'ouvrent sous le panel (adresse « /dbadmin/… »), sans nom de domaine : un serveur web local (127.0.0.1, Nginx ou Apache) les sert et seul le panel y accède, avec votre session. Le bouton « Ouvrir » d\'une base y connecte l\'utilisateur sans saisir de mot de passe (jeton à usage unique, 60 secondes). Un domaine dédié reste possible en option.') + '</p>' +
      (s.any_installed ? '<div class="dba-meta small">' + (s.site_id ? '<span>' + t('Domaine') + ' : <b class="mono">' + TP.esc(s.domain || '') + '</b></span>' : '') + '<span>' + t('Accès par défaut') + ' : <b>' + (s.access === 'domain' ? t('domaine dédié') : s.access === 'panel' ? t('sous le panel') : '—') + '</b>' + (s.panel_server ? ' <span class="muted">(' + TP.esc(s.panel_server) + ')</span>' : '') + '</span><span>' + t('Version de PHP') + ' : <b>' + TP.esc(s.php_version || (s.default_php ? s.default_php + ' (' + t('par défaut') + ')' : t('par défaut'))) + '</b></span>' + (s.db_server ? '<span>' + t('Serveur de bases détecté') + ' : <b>' + TP.esc(s.db_server) + '</b></span>' : '') + '</div>' : (s.db_server ? '<div class="dba-meta small"><span>' + t('Serveur de bases détecté') + ' : <b>' + TP.esc(s.db_server) + '</b></span></div>' : '')) +
      (s.panel_access && s.has_domain ? '<div class="dba-default"><label for="dba-acc">' + t('Accès ouvert par le bouton « Ouvrir »') + '</label><select class="input" id="dba-acc" aria-label="' + TP.esc(t('Accès')) + '"><option value="panel"' + (s.access === 'panel' ? ' selected' : '') + '>' + t('Sous le panel (sans nom de domaine)') + '</option><option value="domain"' + (s.access === 'domain' ? ' selected' : '') + '>' + t('Domaine dédié') + '</option></select></div>' : '') +
      s.tools.map(row).join('') +
      (both ? '<div class="dba-default"><label for="dba-def">' + t('Outil ouvert par défaut pour une base MySQL / MariaDB') + '</label><select class="input" id="dba-def" aria-label="' + TP.esc(t('Outil par défaut')) + '"><option value="adminer"' + (s.default_tool === 'adminer' ? ' selected' : '') + '>Adminer</option><option value="phpmyadmin"' + (s.default_tool === 'phpmyadmin' ? ' selected' : '') + '>phpMyAdmin</option></select></div>' : '') +
      '<div class="hint mt">' + t('PostgreSQL reste géré par Adminer (phpMyAdmin ne gère que MySQL / MariaDB).') + '</div></div></div>';
    const act = (sel, fn) => TP.qsa(sel, box).forEach((b) => b.onclick = () => fn(b.dataset[Object.keys(b.dataset)[0]], b));
    act('[data-in]', (tool) => toolModal(s, tool, reload));
    act('[data-ch]', (tool) => toolModal(s, tool, reload));
    act('[data-up]', async (tool) => { const x = s[tool];
      if (!(await TP.confirm(t('Mettre à jour') + ' ' + TOOL_NAMES[tool], t('Mettre à jour {n} de {a} vers {b} ? La configuration et la connexion unique sont conservées ; la version précédente est sauvegardée puis rétablie automatiquement en cas d\'échec.', { n: TOOL_NAMES[tool], a: x.version, b: x.latest })))) return;
      try { const rr = await TP.post('/api/databases/dbadmin/' + tool + '/update', {}); TP.taskModal(rr.data.task_id, t('Mise à jour') + ' · ' + TOOL_NAMES[tool], () => reload()); } catch (e) { TP.toast(e.message, 'error'); } });
    act('[data-un]', async (tool) => { if (await TP.confirm(t('Désinstaller'), t('Supprimer {n} ?', { n: '<b>' + TOOL_NAMES[tool] + '</b>' }) + (s.tools.filter((x) => x.installed).length === 1 ? ' ' + t('Le site « dbadmin » et le serveur web local sont supprimés avec le dernier outil.') : ''), { danger: true })) { try { await TP.del('/api/databases/dbadmin/' + tool); reload(); } catch (e) { TP.toast(e.message, 'error'); } } });
    const ck = TP.qs('[data-check]', box); if (ck) ck.onclick = async () => {
      ck.disabled = true; let n = 0, err = '';
      try { for (const tl of ['adminer', 'phpmyadmin']) { const rr = await TP.get('/api/databases/dbadmin/' + tl + '/versions?prerelease=true&refresh=true'); n += (rr.data.versions || []).length; if (rr.data.error) err = rr.data.error; } } catch (e) { err = e.message; }
      TP.toast(err ? t('Sources officielles injoignables : liste en cache utilisée') : t('Versions à jour : {n} versions publiées', { n }), err ? 'warn' : '');
      reload();
    };
    const acc = TP.qs('#dba-acc', box); if (acc) acc.onchange = async () => { try { const rr = await TP.put('/api/databases/dbadmin/access', { access: acc.value }); TP.toast(rr.msg); reload(); } catch (e) { TP.toast(e.message, 'error'); } };
    const def = TP.qs('#dba-def', box); if (def) def.onchange = async () => { try { const rr = await TP.put('/api/databases/dbadmin/default-tool', { tool: def.value }); TP.toast(rr.msg); } catch (e) { TP.toast(e.message, 'error'); } };
  }

  function replicationModal() {
    TP.modal({ title: t('Assistant de réplication'), size: 'xl', body: '<p class="muted">' + t('Commandes pré-remplies pour monter un réplica en lecture seule. Le panel ne les exécute pas : copiez-les sur chaque serveur.') + '</p>' +
      '<div class="form"><div class="f2">' + TP.field('engine', t('Moteur'), { type: 'select', value: 'mysql', options: [['mysql', 'MySQL / MariaDB'], ['postgres', 'PostgreSQL']] }) + TP.field('primary_host', t('Adresse du primaire'), { placeholder: t('IP de ce serveur') }) + '</div><div class="f2">' + TP.field('replica_user', t('Utilisateur de réplication'), { value: 'replicator' }) + TP.field('mariadb', t('MariaDB (sinon MySQL 8)'), { type: 'checkbox', value: true }) + '</div></div><div data-guide></div>',
      footer: '<button class="btn" data-close>' + t('Fermer') + '</button><button class="btn primary" data-gen>' + TP.icon('play') + t('Générer') + '</button>',
      onOpen: (bg) => { TP.qs('[data-gen]', bg).onclick = async () => { const f = TP.formData(bg); try { const r = await TP.get('/api/databases/replication/guide?' + new URLSearchParams({ engine: f.engine, primary_host: f.primary_host, replica_user: f.replica_user, mariadb: f.mariadb ? '1' : '0' }).toString());
        TP.qs('[data-guide]', bg).innerHTML = '<div class="alert info mt">' + TP.icon('key') + '<div>' + t('Mot de passe généré') + ' : <code>' + TP.esc(r.data.password) + '</code></div></div>' + r.data.steps.map((s, i) => '<h4 class="mt">' + (i + 1) + '. ' + TP.esc(s.title) + '</h4>' + preOut(s.code)).join('') + (r.data.notes || []).map((n) => '<p class="muted small">' + TP.esc(n) + '</p>').join(''); } catch (e) { TP.toast(e.message, 'error'); } }; } });
  }

  async function renderServers(box, reload) {
    const r = await TP.get('/api/databases/servers'); const x = r.data;
    box.innerHTML = (!x.available ? '<div class="alert warn mb">' + TP.icon('alert') + '<div>' + t('Docker n\'est pas disponible : installez-le depuis la page Logiciels pour héberger d\'autres versions de MariaDB, MySQL ou PostgreSQL.') + '</div></div>' : '') +
      '<div class="row between mb"><span class="muted small">' + t('Chaque serveur est un conteneur publié sur 127.0.0.1 (port dédié) ; choisissez-le à la création d\'une base.') + '</span><button class="btn primary" data-sadd' + (x.available ? '' : ' disabled') + '>' + TP.icon('plus') + t('Nouveau serveur') + '</button></div>' +
      '<div class="card">' + TP.table([
        { label: t('Nom'), render: (s) => '<b>' + TP.esc(s.name) + '</b>' },
        { label: t('Image'), cls: 'mono', render: (s) => TP.esc(s.image) },
        { label: 'Port', cls: 'mono', render: (s) => '127.0.0.1:' + s.port },
        { label: t('Bases'), render: (s) => String(s.databases || 0) },
        { label: t('État'), render: (s) => s.status === 'running' ? TP.badge(t('Actif'), 'ok') : TP.badge(s.status || '?', s.status === 'exited' ? 'danger' : 'warn') },
        { label: '', cls: 'r', render: (s) => '<div class="actions"><button class="btn xs" data-sa="start" data-sid="' + s.id + '" title="' + t('Démarrer') + '">' + TP.icon('play') + '</button><button class="btn xs" data-sa="stop" data-sid="' + s.id + '" title="' + t('Arrêter') + '">' + TP.icon('stop') + '</button><button class="btn xs" data-sa="restart" data-sid="' + s.id + '" title="' + t('Redémarrer') + '">' + TP.icon('refresh') + '</button><button class="btn xs" data-sa="creds" data-sid="' + s.id + '" title="' + t('Identifiants') + '">' + TP.icon('key') + '</button><button class="btn xs danger" data-sa="del" data-sid="' + s.id + '">' + TP.icon('trash') + '</button></div>' },
      ], x.servers, { empty: t('Aucun serveur supplémentaire'), icon: 'docker' }) + '</div>';
    const add = TP.qs('[data-sadd]', box); if (add) add.onclick = () => TP.modal({ title: t('Nouveau serveur de bases'), body: '<div class="form">' + TP.field('name', t('Nom'), { placeholder: 'mariadb11' }) + TP.field('image', t('Version'), { type: 'select', options: x.versions.map((v) => [v, v]) }) + '</div>', okText: t('Créer'), onOk: async (bg) => { const rr = await TP.post('/api/databases/servers', TP.formData(bg)); TP.taskModal(rr.data.task_id, t('Serveur de bases') + ' · ' + rr.data.server.name, () => reload()); } });
    TP.qsa('[data-sa]', box).forEach((b) => b.onclick = async () => { const s = x.servers.find((y) => y.id === Number(b.dataset.sid)); try {
      if (b.dataset.sa === 'creds') { const rr = await TP.get('/api/databases/servers/' + s.id + '/credentials'); TP.modal({ title: t('Identifiants') + ' · ' + s.name, body: '<dl class="kv"><dt>' + t('Hôte') + '</dt><dd class="mono">127.0.0.1:' + s.port + '</dd><dt>' + t('Utilisateur') + '</dt><dd class="mono">' + (s.engine === 'postgres' ? 'postgres' : 'root') + '</dd><dt>' + t('Mot de passe') + '</dt><dd class="mono">' + TP.esc(rr.data.root_password) + '</dd></dl>', footer: '<button class="btn primary" data-close>OK</button>' }); }
      else if (b.dataset.sa === 'del') { const bg = await TP.confirm(t('Supprimer'), t('Supprimer le serveur {n} ?', { n: '<b>' + TP.esc(s.name) + '</b>' }), { danger: true, extra: '<label class="check mt"><input type="checkbox" name="data"> ' + t('Supprimer aussi les données (irréversible)') + '</label>' }); if (bg) { await TP.del('/api/databases/servers/' + s.id + '?delete_data=' + TP.qs('[name=data]', bg).checked); reload(); } }
      else { await TP.post('/api/databases/servers/' + s.id + '/action', { action: b.dataset.sa }); TP.toast(t('Action effectuée')); reload(); }
    } catch (e) { TP.toast(e.message, 'error'); } });
  }

  async function renderKv(box, data, reload) {
    const r = await TP.get('/api/databases/kv'); const x = r.data; const caps = x.capabilities || {};
    const owners = data.owners || [];
    box.innerHTML = (!caps.systemd ? '<div class="alert warn mb">' + TP.icon('alert') + '<div>' + t('Les instances sont décrites mais ne démarrent qu\'avec systemd et un panel lancé en root.') + '</div></div>' : '') +
      '<div class="row between mb"><span class="muted small">' + t('Une instance Redis ou Memcached par compte, joignable uniquement par socket Unix, mémoire bornée par le plan.') + '</span>' + (TP.can('databases', 'create') ? '<button class="btn primary" data-kadd>' + TP.icon('plus') + t('Nouvelle instance') + '</button>' : '') + '</div>' +
      '<div class="card">' + TP.table([
        { label: t('Type'), render: (k) => TP.badge(k.kind === 'redis' ? 'Redis' : 'Memcached', k.kind === 'redis' ? 'danger' : 'info') },
        { label: t('Compte'), render: (k) => TP.esc(k.owner || ('#' + k.owner_id)) },
        { label: t('Mémoire'), render: (k) => TP.fmtSize(k.memory_mb, 'Mo') },
        { label: t('Socket'), cls: 'mono small', render: (k) => TP.esc(k.socket) },
        { label: t('État'), render: (k) => TP.badge(k.status || '?', k.status === 'actif' ? 'ok' : k.status === 'erreur' ? 'danger' : 'warn') },
        { label: '', cls: 'r', render: (k) => '<div class="actions"><button class="btn xs" data-ka="info" data-kid="' + k.id + '" title="' + t('Connexion') + '">' + TP.icon('info') + '</button>' + (TP.can('databases', 'edit') ? '<button class="btn xs" data-ka="mem" data-kid="' + k.id + '" title="' + t('Mémoire') + '">' + TP.icon('ram') + '</button><button class="btn xs" data-ka="restart" data-kid="' + k.id + '" title="' + t('Redémarrer') + '">' + TP.icon('refresh') + '</button>' : '') + (TP.can('databases', 'delete') ? '<button class="btn xs danger" data-ka="del" data-kid="' + k.id + '">' + TP.icon('trash') + '</button>' : '') + '</div>' },
      ], x.instances, { empty: t('Aucune instance'), icon: 'db' }) + '</div>';
    const add = TP.qs('[data-kadd]', box); if (add) add.onclick = () => TP.modal({ title: t('Nouvelle instance'), body: '<div class="form"><div class="f2">' + TP.field('kind', t('Type'), { type: 'select', options: [['redis', 'Redis'], ['memcached', 'Memcached']] }) + TP.field('memory_mb', t('Mémoire (Mo)'), { type: 'number', value: 64, hint: t('Plafonnée par le plan du compte.') }) + '</div>' + (owners.length ? TP.field('owner_id', t('Compte'), { type: 'select', options: owners.filter((o) => o.id).map((o) => [o.id, o.name]) }) : '') + '</div>', okText: t('Créer'),
      onOk: async (bg) => { const f = TP.formData(bg); if (f.owner_id) f.owner_id = Number(f.owner_id); const rr = await TP.post('/api/databases/kv', f); TP.toast(rr.msg); reload(); } });
    TP.qsa('[data-ka]', box).forEach((b) => b.onclick = async () => { const k = x.instances.find((y) => y.id === Number(b.dataset.kid)); try {
      if (b.dataset.ka === 'info') { const kr = (await TP.get('/api/databases/kv/' + k.id + '/reveal')).data; /* mot de passe : lecture explicite, journalisée */ TP.modal({ title: (k.kind === 'redis' ? 'Redis' : 'Memcached') + ' · ' + (k.owner || ''), size: 'lg', body: '<dl class="kv"><dt>' + t('Socket') + '</dt><dd class="mono">' + TP.esc(k.socket) + '</dd>' + (kr.password ? '<dt>' + t('Mot de passe') + '</dt><dd class="mono">' + TP.esc(kr.password) + '</dd>' : '') + '</dl>' + Object.entries(kr.connection || {}).map(([n, c]) => '<h4 class="mt">' + TP.esc(n === 'php' ? 'PHP' : 'WordPress (wp-config.php)') + '</h4>' + preOut(c)).join(''), footer: '<button class="btn primary" data-close>OK</button>' }); }
      else if (b.dataset.ka === 'mem') { const v = await TP.prompt(t('Mémoire (Mo)'), t('Nouvelle limite'), String(k.memory_mb)); if (v) { const rr = await TP.put('/api/databases/kv/' + k.id, { memory_mb: Number(v) }); TP.toast(rr.msg); reload(); } }
      else if (b.dataset.ka === 'restart') { const rr = await TP.post('/api/databases/kv/' + k.id + '/restart'); TP.toast(rr.msg); reload(); }
      else if (b.dataset.ka === 'del') { if (await TP.confirm(t('Supprimer'), t('Supprimer cette instance et ses données ?'), { danger: true })) { await TP.del('/api/databases/kv/' + k.id); reload(); } }
    } catch (e) { TP.toast(e.message, 'error'); } });
  }

  TP.registerPage('databases', {
    async render(root) {
      const reload = () => this.render(root);
      const r = await TP.get('/api/databases');
      const data = r.data, eng = data.engines, isAdmin = TP.can('settings', 'edit');
      const engBadge = (name, e) => !e ? '' : !e.available ? TP.badge(name + ' · ' + t('non installé'), '') : e.ok ? TP.badge(name + ' ' + (e.version || ''), 'ok') : TP.badge(name + ' · ' + t('connexion impossible'), 'danger');
      const tabs = [['list', t('Bases')]].concat(isAdmin ? [['servers', t('Serveurs')], ['tools', t('Outils d\'administration')]] : []).concat([['kv', 'Redis / Memcached']]);
      const qTab = TP.query().tab; if (qTab && tabs.some((x) => x[0] === qTab)) { dbTab = qTab; history.replaceState(null, '', '#/databases'); }  // lien « #/databases?tab=tools » (page Logiciels)
      if (!tabs.some((x) => x[0] === dbTab)) dbTab = 'list';
      root.innerHTML = TP.pageHead(t('Bases de données'), engBadge('MySQL', eng.mysql) + ' ' + engBadge('PostgreSQL', eng.postgres) + ' ' + engBadge('MongoDB', eng.mongo) + ' ' + TP.badge('SQLite', 'ok'),
          (isAdmin ? '<button class="btn" id="root">' + TP.icon('key') + t('Identifiants root') + '</button><button class="btn" id="server-list">' + TP.icon('eye') + t('Bases sur le serveur') + '</button><button class="btn" id="adminer">' + TP.icon('external') + t('Outils d\'administration') + '</button><button class="btn" id="repl">' + TP.icon('copy') + t('Réplication') + '</button>' : '') + (TP.can('databases', 'create') ? '<button class="btn primary" id="add">' + TP.icon('plus') + t('Nouvelle base') + '</button>' : '')) +
        (eng.mysql.available && !eng.mysql.ok && isAdmin ? '<div class="alert warn mb">' + TP.icon('alert') + '<div>MySQL : ' + TP.esc(eng.mysql.error || '') + ' — ' + t('renseignez les identifiants root.') + '</div></div>' : '') +
        tabsHtml(tabs, dbTab) +
        '<div data-pane="list"' + (dbTab === 'list' ? '' : ' style="display:none"') + '><div class="card">' + TP.table([
          { label: t('Base'), render: (d) => '<a href="#" data-a="open-db" data-id="' + d.id + '"><b>' + TP.esc(d.name) + '</b></a>' + (d.remark ? ' <span class="muted small">' + TP.esc(d.remark) + '</span>' : '') + (d.over_quota ? ' ' + TP.badge(t('quota dépassé'), 'danger') : '') },
          { label: t('Moteur'), render: (d) => TP.badge(ENGINE_LABELS[d.engine] || d.engine, engineCls(d.engine)) + (d.server ? ' <span class="small muted">' + TP.esc(d.server) + '</span>' : '') },
          { label: t('Utilisateurs'), cls: 'small', render: (d) => d.engine === 'sqlite' ? '<span class="muted">—</span>' : '<span class="mono">' + TP.esc(d.username) + '</span>' + (d.users_count > 1 ? ' <span class="muted">+' + (d.users_count - 1) + '</span>' : '') },
          { label: t('Taille'), render: sizeCell },
          { label: t('Accès distant'), cls: 'small', render: (d) => (d.remote_ips || []).length ? TP.badge((d.remote_ips || []).length + ' IP', 'warn') : '<span class="muted">' + t('local') + '</span>' },
        ].concat((data.owners || []).length ? [{ label: t('Propriétaire'), cls: 'small', render: (d) => TP.esc(d.owner || (d.owner_id ? '#' + d.owner_id : t('administrateur'))) }] : []).concat([
          { label: '', cls: 'r', render: (d) => { const tl = toolsFor(d.engine, data.dbadmin_tools); return '<div class="actions">' + (tl.length && TP.can('databases', 'edit') ? '<button class="btn xs" data-a="open" data-id="' + d.id + '" title="' + (tl.length > 1 ? t('Ouvrir avec') : openLabel(tl[0])) + '"' + (tl.length > 1 ? ' aria-haspopup="menu"' : '') + '>' + TP.icon('external') + '</button>' : '') +
            '<button class="btn xs" data-a="open-db" data-id="' + d.id + '" title="' + t('Gérer') + '">' + TP.icon('settings') + '</button>' + (TP.can('databases', 'edit') && d.engine !== 'sqlite' ? '<button class="btn xs" data-a="pwd" data-id="' + d.id + '" title="' + t('Changer le mot de passe') + '">' + TP.icon('key') + '</button>' : '') +
            '<a class="btn xs" href="/api/databases/' + d.id + '/export" title="' + t('Exporter') + '">' + TP.icon('download') + '</a>' + (TP.can('databases', 'delete') ? '<button class="btn xs danger" data-a="del" data-id="' + d.id + '">' + TP.icon('trash') + '</button>' : '') + '</div>'; } },
        ]), data.databases, { empty: t('Aucune base de données'), icon: 'db', cta: { label: t('Nouvelle base'), target: '#add' } }) + '</div></div>' +
        (isAdmin ? '<div data-pane="servers"' + (dbTab === 'servers' ? '' : ' style="display:none"') + '><div data-srv>' + TP.loading() + '</div></div>' : '') +
        (isAdmin ? '<div data-pane="tools"' + (dbTab === 'tools' ? '' : ' style="display:none"') + '><div data-tools>' + TP.loading() + '</div></div>' : '') +
        '<div data-pane="kv"' + (dbTab === 'kv' ? '' : ' style="display:none"') + '><div data-kv>' + TP.loading() + '</div></div>';
      const lazy = { servers: () => renderServers(TP.qs('[data-srv]', root), reload), tools: () => renderTools(TP.qs('[data-tools]', root), reload), kv: () => renderKv(TP.qs('[data-kv]', root), data, reload) };
      const shown = {};
      const show = (tab) => { dbTab = tab; if (lazy[tab] && !shown[tab]) { shown[tab] = true; lazy[tab]().catch((e) => { const b = TP.qs(tab === 'kv' ? '[data-kv]' : tab === 'tools' ? '[data-tools]' : '[data-srv]', root); if (b) b.innerHTML = '<div class="alert danger">' + TP.esc(e.message) + '</div>'; }); } };
      bindTabs(root, show); show(dbTab);
      const addDb = TP.qs('#add', root); if (addDb) addDb.onclick = () => TP.modal({ title: t('Nouvelle base de données'), body: '<div class="form">' +
        '<div class="f2">' + TP.field('engine', t('Moteur'), { type: 'select', value: eng.mysql.available ? 'mysql' : 'sqlite', options: [['mysql', 'MySQL / MariaDB'], ['postgres', 'PostgreSQL'], ['mongo', 'MongoDB'], ['sqlite', t('SQLite (fichier)')]] }) +
        (isAdmin && (data.servers || []).length ? TP.field('server_id', t('Serveur'), { type: 'select', value: '', options: [['', t('Serveur local')]].concat(data.servers.map((s) => [s.id, s.name + ' (' + s.image + ', port ' + s.port + ')'])) }) : '<div></div>') + '</div>' +
        TP.field('name', t('Nom de la base'), { placeholder: 'ma_base' }) + '<div class="f2">' + TP.field('username', t('Utilisateur'), { placeholder: t('= nom de la base') }) + TP.field('password', t('Mot de passe'), { placeholder: t('généré automatiquement') }) + '</div>' +
        TP.field('host', t('Hôte de l\'utilisateur (MySQL)'), { type: 'select', value: 'localhost', options: [['localhost', 'localhost'], ['%', t('Tout le monde (%)')]], hint: t('Pour un accès depuis d\'autres machines, préférez l\'onglet « Accès distant » de la base (IP précises + pare-feu).') }) +
        ((data.owners || []).length ? TP.field('owner_id', t('Propriétaire'), { type: 'select', value: '', options: [['', t('Moi')]].concat(data.owners.map((o) => [o.id, o.name])) }) : '') + TP.field('remark', t('Remarque')) + '</div>',
        okText: t('Créer'), onOk: async (bg) => { const f = TP.formData(bg); f.server_id = f.server_id ? Number(f.server_id) : null; f.owner_id = f.owner_id ? Number(f.owner_id) : null; const rr = await TP.post('/api/databases', f); TP.toast(rr.msg); TP.modal({ title: t('Base créée'), body: '<dl class="kv"><dt>' + t('Base') + '</dt><dd>' + TP.esc(rr.data.name) + '</dd><dt>' + t('Utilisateur') + '</dt><dd>' + TP.esc(rr.data.username) + '</dd>' + (rr.data.password ? '<dt>' + t('Mot de passe') + '</dt><dd class="mono">' + TP.esc(rr.data.password) + '</dd>' : '') + '</dl>', footer: '<button class="btn primary" data-close>OK</button>', onClose: reload }); } });
      const rootBtn = TP.qs('#root', root); if (rootBtn) rootBtn.onclick = async () => { const rr = await TP.get('/api/databases/root'); const engs = [['mysql', 'MySQL'], ['postgres', 'PostgreSQL'], ['mongo', 'MongoDB']];
        TP.modal({ title: t('Identifiants administrateur'), body: tabsHtml(engs, 'mysql') +
          engs.map(([e]) => { const c = rr.data[e] || {}; return '<div data-pane="' + e + '"' + (e !== 'mysql' ? ' style="display:none"' : '') + '><div class="form"><div class="f2">' + TP.field(e + '_host', t('Hôte'), { value: c.host }) + TP.field(e + '_port', 'Port', { type: 'number', value: c.port }) + '</div><div class="f2">' + TP.field(e + '_user', t('Utilisateur'), { value: c.user }) + TP.field(e + '_password', t('Mot de passe'), { type: 'password', value: c.password }) + '</div></div></div>'; }).join(''),
          okText: t('Enregistrer'), onOpen: (bg) => bindTabs(bg),
          onOk: async (bg) => { const f = TP.formData(bg); const active = TP.qs('.tabs button.active', bg).dataset.tab; const res = await TP.post('/api/databases/root', { engine: active, host: f[active + '_host'], port: f[active + '_port'], user: f[active + '_user'], password: f[active + '_password'] }); TP.toast(res.msg, res.data.ok ? '' : 'warn'); reload(); } }); };
      const srvList = TP.qs('#server-list', root); if (srvList) srvList.onclick = async () => { try { const rr = await TP.get('/api/databases/server/mysql'); TP.modal({ title: t('Bases présentes sur MySQL'), body: TP.table([{ label: t('Base'), render: (x) => TP.esc(x.name) }, { label: t('Tables'), render: (x) => x.tables }, { label: t('Taille'), render: (x) => TP.fmtBytes(x.size) }], rr.data), footer: '<button class="btn" data-close>' + t('Fermer') + '</button>' }); } catch (e) { TP.toast(e.message, 'error'); } };
      const adm = TP.qs('#adminer', root); if (adm) adm.onclick = () => { const tb = TP.qs('.tabs button[data-tab="tools"]', root); if (tb) tb.click(); };
      const repl = TP.qs('#repl', root); if (repl) repl.onclick = replicationModal;
      TP.qsa('[data-a]', root).forEach((b) => b.onclick = async (ev) => {
        ev.preventDefault();
        const d = data.databases.find((x) => x.id === Number(b.dataset.id)); const a = b.dataset.a;
        try {
          if (a === 'open-db') openDatabase(d, data, reload);
          else if (a === 'open') { const tl = toolsFor(d.engine, data.dbadmin_tools); if (tl.length > 1) openMenu(b, d, tl, data.dbadmin_default); else openDbTool(d, tl[0]); }
          else if (a === 'pwd') { const p = await TP.prompt(t('Nouveau mot de passe'), t('Laisser vide pour générer'), ''); if (p === null) return; const rr = await TP.post('/api/databases/' + d.id + '/password', { password: p }); TP.toast(rr.msg + ' : ' + rr.data.password, '', 8000); reload(); }
          else if (a === 'del') { const bg = await TP.confirm(t('Supprimer la base'), t('Supprimer {n} ?', { n: '<b>' + TP.esc(d.name) + '</b>' }), { danger: true, extra: '<label class="check mt"><input type="checkbox" name="drop" checked> ' + t('Supprimer aussi sur le serveur (irréversible)') + '</label>' }); if (bg) { const rr = await TP.del('/api/databases/' + d.id + '?drop=' + TP.qs('[name=drop]', bg).checked); TP.toast(rr.msg); reload(); } }
        } catch (e) { TP.toast(e.message, 'error'); }
      });
    },
  });

  // ---------------------------------------------------------------- FTP
  TP.registerPage('ftp', {
    async render(root) {
      const reload = () => this.render(root);
      const r = await TP.get('/api/ftp'); const d = r.data; const st = d.status || {}; const srv = d.server || {};
      const eng = Object.assign({ id: 'builtin', name: '', capabilities: {} }, d.engine || {}); const capOf = (k) => (eng.capabilities && eng.capabilities[k]) || 'yes';   // moteur FTP actif et ses capacités
      // Droits lisibles (mêmes clés que RIGHTS côté serveur, mappées sur la chaîne pyftpdlib elradfmwMT)
      const RIGHTS = [['list', t('Lister')], ['download', t('Télécharger')], ['upload', t('Téléverser')], ['modify', t('Modifier / remplacer')], ['delete', t('Supprimer')], ['rename', t('Renommer')], ['mkdir', t('Créer des dossiers')], ['chmod', t('Changer les permissions')]];
      const RO = { list: true, download: true }, RW = Object.fromEntries(RIGHTS.map((x) => [x[0], true]));
      const permBadge = (u) => { const rt = u.rights || {}; const on = RIGHTS.filter((x) => rt[x[0]]); if (on.length === RIGHTS.length) return TP.badge(t('Lecture / écriture'), 'info'); if (!on.length) return TP.badge(t('Aucun droit'), 'danger'); if (on.every((x) => RO[x[0]]) && rt.list) return TP.badge(t('Lecture seule'), ''); return '<span title="' + TP.esc(on.map((x) => x[1]).join(', ')) + '">' + TP.badge(t('Personnalisé') + ' (' + on.length + '/' + RIGHTS.length + ')', 'warn') + '</span>'; };
      const quotaCell = (u) => { if (u.quota_mb && capOf('quota') === 'no') return '<span class="small">' + TP.fmtBytes(u.usage_bytes) + ' ' + TP.badge(t('quota non appliqué'), 'warn') + '</span>'; if (!u.quota_mb) return '<span class="small">' + TP.fmtBytes(u.usage_bytes) + ' <span class="muted">/ ' + t('illimité') + '</span></span>'; const pct = Math.min(100, Math.round(u.usage_bytes * 100 / Math.max(1, u.quota_bytes))); return '<div class="small">' + TP.fmtBytes(u.usage_bytes) + ' / ' + TP.fmtBytes(u.quota_bytes) + ' <span class="muted">(' + pct + ' %)</span></div><div class="progress' + (pct >= 95 ? ' danger' : pct >= 80 ? ' warn' : '') + '"><i style="width:' + pct + '%"></i></div>'; };
      const headBadges = (st.running ? TP.badge(t('En écoute sur le port') + ' ' + st.port, 'ok') + ' ' + (st.tls ? TP.badge('FTPS / TLS ' + t('activé'), 'info') : TP.badge('TLS ' + t('désactivé'), '')) : TP.badge(t('Arrêté'), 'danger')) + (st.warning ? ' ' + TP.badge(st.warning, 'warn') : '');
      root.innerHTML = TP.pageHead(t('FTP'), TP.ftpEngines.subtitle(eng) + ' ' + headBadges,
          (d.is_admin ? '<button class="btn" id="eng">' + TP.icon('switch') + t('Moteur') + '</button>' : '') + '<button class="btn" id="srv">' + TP.icon('settings') + t('Serveur') + '</button><button class="btn" id="log">' + TP.icon('logs') + t('Journal') + '</button><button class="btn primary" id="add">' + TP.icon('plus') + t('Nouvel utilisateur') + '</button>') +
        '<div class="card mb">' + TP.table([
          { label: t('Utilisateur'), render: (u) => '<b>' + TP.esc(u.username) + '</b>' + (u.description ? '<div class="small muted">' + TP.esc(u.description) + '</div>' : '') + (u.active_sessions ? '<div class="small">' + TP.badge(u.active_sessions + ' ' + t('connecté(s)'), 'ok') + '</div>' : '') },
          { label: t('Répertoire'), cls: 'mono small', render: (u) => '<a href="#/files?path=' + encodeURIComponent(u.home) + '">' + TP.esc(u.home) + '</a>' + (u.site_id ? '<div class="muted">' + t('Site') + ' #' + u.site_id + '</div>' : '') },
          { label: t('Droits'), render: permBadge },
          { label: t('Quota'), render: quotaCell },
          { label: t('IP autorisées'), cls: 'mono small', render: (u) => u.allowed_ips ? TP.esc(u.allowed_ips) : '<span class="muted">' + t('Toutes') + '</span>' },
          { label: t('Expiration'), cls: 'small', render: (u) => !u.expires_at ? '<span class="muted">—</span>' : u.expired ? TP.badge(t('Expiré') + ' · ' + u.expires_at, 'danger') : TP.esc(u.expires_at) },
          { label: t('Dernière connexion'), cls: 'small', render: (u) => u.last_login ? TP.fmtDate(u.last_login) : '<span class="muted">' + t('Jamais') + '</span>' },
          { label: t('État'), render: (u) => u.enabled ? TP.badge(t('Actif'), 'ok') : TP.badge(t('Désactivé'), 'danger') },
          { label: '', cls: 'r', render: (u) => '<div class="actions"><button class="btn xs" data-a="pwd" data-id="' + u.id + '" title="' + t('Changer le mot de passe') + '">' + TP.icon('key') + '</button><button class="btn xs" data-a="toggle" data-id="' + u.id + '" title="' + (u.enabled ? t('Désactiver') : t('Activer')) + '">' + TP.icon(u.enabled ? 'stop' : 'play') + '</button><button class="btn xs" data-a="edit" data-id="' + u.id + '" title="' + t('Modifier') + '">' + TP.icon('edit') + '</button><button class="btn xs danger" data-a="del" data-id="' + u.id + '" title="' + t('Supprimer') + '">' + TP.icon('trash') + '</button></div>' },
        ], d.users, { empty: t('Aucun utilisateur FTP'), icon: 'ftp', assist: true }) + '</div>' +
        (capOf('sessions') === 'no' ? '' : '<div class="card mb"><div class="card-h"><h3>' + t('Connexions en cours') + '</h3>' + TP.badge(String((d.sessions || []).length), (d.sessions || []).length ? 'ok' : '') + '</div>' + TP.table([
          { label: t('Utilisateur'), render: (s) => '<b>' + TP.esc(s.user) + '</b>' },
          { label: 'IP', cls: 'mono small', render: (s) => TP.esc(s.ip || '') },
          { label: t('Depuis'), cls: 'small', render: (s) => TP.fmtDate(s.since) },
          { label: 'TLS', render: (s) => s.tls ? TP.badge(t('chiffré'), 'info') : TP.badge(t('en clair'), '') },
        ], d.sessions || [], { empty: t('Aucune connexion en cours'), icon: 'net' }) + '</div>') +
        '<div class="card" id="log-card"><div class="card-h"><h3>' + t('Journal') + ' <span class="small muted">ftp.log</span></h3><button class="btn sm" id="log-refresh">' + TP.icon('refresh') + t('Actualiser') + '</button></div><div id="log-body">' + TP.loading() + '</div></div>';

      // ---- journal (200 dernières lignes)
      const evBadge = (e) => TP.badge(e || '?', { LOGIN: 'ok', LOGOUT: '', CLOSE: '', FAILED: 'danger', QUOTA: 'warn', SENT: 'info', RECEIVED: 'info', PARTIAL: 'warn', START: 'ok', STOP: 'danger' }[e] || '');
      const loadLog = async () => { const body = TP.qs('#log-body', root); if (!body) return; try { const rr = await TP.get('/api/ftp/log?limit=200'); const rows = (rr.data.entries || []).slice().reverse();
        body.innerHTML = TP.table([
          { label: t('Date'), cls: 'small mono', render: (e) => TP.esc(e.time) },
          { label: t('Événement'), render: (e) => evBadge(e.event) },
          { label: t('Utilisateur'), render: (e) => TP.esc(e.user || '—') },
          { label: 'IP', cls: 'mono small', render: (e) => TP.esc(e.ip || '—') },
          { label: t('Détail'), cls: 'small mono', render: (e) => TP.esc(e.detail || '') },
        ], rows, { empty: t('Journal vide'), icon: 'logs' }); } catch (e) { body.innerHTML = '<div class="alert danger">' + TP.esc(e.message) + '</div>'; } };
      loadLog();
      TP.qs('#log-refresh', root).onclick = loadLog;
      TP.qs('#log', root).onclick = () => { loadLog(); TP.qs('#log-card', root).scrollIntoView({ behavior: 'smooth', block: 'start' }); };

      // ---- formulaire utilisateur (création / modification)
      let sitesCache = null;
      const loadSites = async () => { if (sitesCache) return sitesCache; try { const rr = await TP.get('/api/sites'); sitesCache = (rr.data || []).map((s) => ({ id: s.id, name: s.name, root: s.root })); } catch (e) { sitesCache = []; } return sitesCache; };
      const rightsBox = (rt) => '<div class="field"><label>' + t('Droits') + '</label><div class="small muted mb">' + t('Raccourcis :') + ' <a href="#" data-preset="ro">' + t('Lecture seule') + '</a> · <a href="#" data-preset="rw">' + t('Lecture-écriture') + '</a></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 14px">' + RIGHTS.map((x) => TP.field('right_' + x[0], x[1], { type: 'checkbox', value: !!rt[x[0]] })).join('') + '</div></div>';
      const userForm = (u, sites) => { const rt = u ? (u.rights || {}) : RW; const siteOpts = [['', t('Aucun (répertoire ci-dessous)')]].concat(sites.map((s) => [s.id, s.name + ' — ' + s.root])); return '<div class="form">' +
        '<div class="f2">' + (u ? TP.field('description', t('Description'), { value: u.description || '', placeholder: t('Remarque libre') }) : TP.field('username', t('Utilisateur'), { placeholder: 'ex : client1', hint: t('2 à 64 caractères : lettres, chiffres, . _ -') })) + TP.field('password', t('Mot de passe'), { type: 'password', placeholder: u ? t('inchangé') : t('6 caractères minimum') }) + '</div>' +
        '<div class="f2">' + TP.field('site_id', t('Site associé'), { type: 'select', value: u && u.site_id ? u.site_id : '', options: siteOpts, hint: t('Le dossier du site sert de racine FTP.') }) + TP.field('home', t('Répertoire racine'), { value: u ? u.home : '', placeholder: t('par défaut : wwwroot/utilisateur') }) + '</div>' +
        rightsBox(rt) +
        '<div class="f2">' + TP.field('quota_mb', t('Quota disque (Mo)'), { type: 'number', value: u ? u.quota_mb : 0, hint: t('0 = illimité. Les envois sont refusés une fois le quota atteint.') }) + TP.field('max_connections', t('Connexions simultanées max'), { type: 'number', value: u ? u.max_connections : 0, hint: t('0 = illimité') }) + '</div>' +
        '<div class="f2">' + TP.field('allowed_ips', t('IP autorisées'), { value: u ? u.allowed_ips : '', placeholder: '203.0.113.5, 10.0.0.0/8', hint: t('IP ou CIDR séparés par des virgules, vide = toutes') }) + TP.field('expires_at', t('Date d\'expiration'), { type: 'date', value: u && u.expires_at ? u.expires_at : '', hint: t('Vide = jamais. Le compte est refusé après cette date.') }) + '</div>' +
        (u ? '' : TP.field('description', t('Description'), { placeholder: t('Remarque libre') })) + '</div>'; };
      const bindForm = (bg) => { TP.qsa('[data-preset]', bg).forEach((a) => a.onclick = (e) => { e.preventDefault(); const set = a.dataset.preset === 'ro' ? RO : RW; RIGHTS.forEach((x) => { const cb = TP.qs('[name=right_' + x[0] + ']', bg); if (cb) cb.checked = !!set[x[0]]; }); }); TP.ftpEngines.applyUserCaps(bg, eng); const sel = TP.qs('[name=site_id]', bg), home = TP.qs('[name=home]', bg); if (sel && home) sel.onchange = () => { const s = (sitesCache || []).find((x) => String(x.id) === sel.value); if (s) home.value = s.root; home.disabled = !!s; }; if (sel && sel.value) home.disabled = true; };
      const collect = (bg) => { const f = TP.formData(bg); const rights = {}; RIGHTS.forEach((x) => { rights[x[0]] = !!f['right_' + x[0]]; delete f['right_' + x[0]]; }); f.rights = rights; f.site_id = f.site_id ? Number(f.site_id) : null; if (f.site_id) delete f.home; if (!f.password) delete f.password; f.quota_mb = f.quota_mb || 0; f.max_connections = f.max_connections || 0; f.expires_at = f.expires_at || null; return f; };
      TP.qs('#add', root).onclick = async () => { const sites = await loadSites(); TP.modal({ title: t('Nouvel utilisateur FTP'), size: 'lg', body: userForm(null, sites), okText: t('Créer'), onOpen: bindForm, onOk: async (bg) => { const rr = await TP.post('/api/ftp', collect(bg)); TP.toast(rr.msg); reload(); } }); };

      // ---- moteur FTP : choix, état, bascule (administrateur)
      const engBtn = TP.qs('#eng', root); if (engBtn) engBtn.onclick = () => TP.ftpEngines.openPicker(reload);

      // ---- modale serveur : onglets Réseau / Sécurité / Général
      TP.qs('#srv', root).onclick = () => {
        const tabs = [['network', t('Réseau')], ['security', t('Sécurité')], ['general', t('Général')]];
        const pane = (id, html) => '<div data-pane="' + id + '"' + (id !== 'network' ? ' style="display:none"' : '') + '><div class="form">' + html + '</div></div>';
        const body = '<div class="tabs">' + tabs.map((x, i) => '<button' + (i === 0 ? ' class="active"' : '') + ' data-tab="' + x[0] + '">' + TP.esc(x[1]) + '</button>').join('') + '</div>' +
          pane('network', '<div class="f2">' + TP.field('port', t('Port de contrôle'), { type: 'number', value: srv.port, hint: t('21 par défaut ; 2121 si le port 21 est pris.') }) + TP.field('bind', t('Interface d\'écoute'), { value: srv.bind || '0.0.0.0', placeholder: '0.0.0.0', hint: t('0.0.0.0 = toutes les interfaces') }) + '</div>' +
            '<div class="f2">' + TP.field('passive_ports', t('Ports passifs'), { value: srv.passive_ports, placeholder: '60000-60100', hint: t('Ouvrez cette plage dans le pare-feu.') }) + '<div class="field"><label>' + t('Adresse passive publique (masquerade)') + '</label><div class="row" style="gap:8px"><input class="input" name="masquerade_address" value="' + TP.esc(srv.masquerade_address || '') + '" placeholder="' + t('vide = automatique') + '" style="flex:1"><button type="button" class="btn" data-detect>' + TP.icon('search') + t('Détecter') + '</button></div><div class="hint">' + t('IP publique annoncée aux clients en mode passif, indispensable derrière un NAT.') + '</div></div></div>') +
          pane('security', TP.field('tls', t('FTPS explicite (TLS)'), { type: 'select', value: srv.tls || 'off', options: [['off', t('Désactivé')], ['optional', t('Optionnel (AUTH TLS accepté)')], ['required', t('Obligatoire (contrôle et données chiffrés)')]], hint: (st.tls_available ? t('Utilise le certificat du panel, ou celui du site choisi ci-dessous.') : '<span class="muted">' + t('Module pyopenssl absent : installez-le (pip install pyopenssl) pour activer TLS.') + '</span>') }) +
            TP.field('tls_site', t('Certificat du FTPS'), { type: 'select', value: srv.tls_site || '', options: [['', t('Certificat du panel')]].concat(srv.tls_site ? [[srv.tls_site, srv.tls_site]] : []), hint: t('Site dont le certificat TLS est utilisé pour le FTPS.') }) +
            TP.field('tls_implicit', t('FTPS implicite (port 990)'), { type: 'checkbox', value: !!srv.tls_implicit, hint: t('En plus du FTPS explicite ; certains anciens clients l\'exigent.') }) +
            '<div class="f2">' + TP.field('max_cons', t('Connexions max (total)'), { type: 'number', value: srv.max_cons }) + TP.field('max_cons_per_ip', t('Connexions max par IP'), { type: 'number', value: srv.max_cons_per_ip, hint: t('0 = illimité') }) + '</div>' +
            '<div class="f2">' + TP.field('timeout', t('Délai d\'inactivité (s)'), { type: 'number', value: srv.timeout, hint: t('30 minimum') }) + '<div></div></div>' +
            '<div class="f2">' + TP.field('max_upload_kbps', t('Débit max réception (Ko/s)'), { type: 'number', value: srv.max_upload_kbps, hint: t('Par connexion, 0 = illimité') }) + TP.field('max_download_kbps', t('Débit max envoi (Ko/s)'), { type: 'number', value: srv.max_download_kbps, hint: t('Par connexion, 0 = illimité') }) + '</div>') +
          pane('general', TP.field('banner', t('Bannière d\'accueil'), { value: srv.banner || '', placeholder: t('ToutPanel FTP prêt.') }) + TP.field('umask', t('Umask des fichiers créés'), { value: srv.umask || '022', placeholder: '022', hint: t('022 : fichiers 644, dossiers 755 ; 027 : sans accès pour les autres.') }) + TP.field('enabled', t('Démarrer automatiquement avec le panel'), { type: 'checkbox', value: !!srv.enabled }) +
            '<div class="alert info mt">' + TP.icon('info') + '<div>' + t('Enregistrer applique les réglages au prochain démarrage ; Redémarrer les applique immédiatement.') + '</div></div>');
        TP.modal({ title: t('Serveur FTP'), size: 'lg', body,
          footer: '<button class="btn" data-close>' + t('Fermer') + '</button><button class="btn" data-srv="save">' + TP.icon('check') + t('Enregistrer') + '</button>' + (st.running ? '<button class="btn danger" data-srv="stop">' + TP.icon('stop') + t('Arrêter') + '</button><button class="btn primary" data-srv="restart">' + TP.icon('refresh') + t('Redémarrer') + '</button>' : '<button class="btn primary" data-srv="start">' + TP.icon('play') + t('Démarrer') + '</button>'),
          onOpen: (bg, close) => {
            TP.ftpEngines.applyCaps(bg, Object.assign({}, eng, { field_caps: eng.field_caps })); TP.ftpEngines.fillSites(bg, srv.tls_site || '');
            TP.qsa('.tabs button', bg).forEach((b) => b.onclick = () => { TP.qsa('.tabs button', bg).forEach((x) => x.classList.toggle('active', x === b)); TP.qsa('[data-pane]', bg).forEach((pp) => pp.style.display = pp.dataset.pane === b.dataset.tab ? '' : 'none'); });
            TP.qs('[data-detect]', bg).onclick = async (e) => { const b = e.currentTarget; b.disabled = true; try { const rr = await TP.get('/api/ftp/public-ip'); TP.qs('[name=masquerade_address]', bg).value = rr.data.ip; TP.toast(t('IP publique détectée : {ip}', { ip: rr.data.ip })); } catch (err) { TP.toast(err.message, 'error'); } b.disabled = false; };
            TP.qsa('[data-srv]', bg).forEach((b) => b.onclick = async () => { b.disabled = true; try { const f = TP.formData(bg); f.action = b.dataset.srv; const rr = await TP.post('/api/ftp/server', f); TP.toast(rr.msg, rr.data.status && rr.data.status.warning ? 'warn' : ''); close(); reload(); } catch (err) { TP.toast(err.message, 'error'); b.disabled = false; } });
          } });
      };

      // ---- actions par utilisateur
      TP.qsa('[data-a]', root).forEach((b) => b.onclick = async () => {
        const u = d.users.find((x) => x.id === Number(b.dataset.id)); const a = b.dataset.a;
        try {
          if (a === 'pwd') { const p = await TP.prompt(t('Nouveau mot de passe'), t('Mot de passe')); if (p) { await TP.put('/api/ftp/' + u.id, { password: p }); TP.toast(t('Mot de passe modifié')); } }
          else if (a === 'toggle') { await TP.put('/api/ftp/' + u.id, { enabled: !u.enabled }); reload(); }
          else if (a === 'edit') { const sites = await loadSites(); TP.modal({ title: t('Modifier') + ' · ' + u.username, size: 'lg', body: userForm(u, sites), okText: t('Enregistrer'), onOpen: bindForm, onOk: async (bg) => { await TP.put('/api/ftp/' + u.id, collect(bg)); TP.toast(t('Utilisateur mis à jour')); reload(); } }); }
          else if (a === 'del') { if (await TP.confirm(t('Supprimer'), t('Supprimer l\'utilisateur {n} ?', { n: '<b>' + TP.esc(u.username) + '</b>' }), { danger: true })) { await TP.del('/api/ftp/' + u.id); reload(); } }
        } catch (e) { TP.toast(e.message, 'error'); }
      });
    },
  });

  // ---------------------------------------------------------------- Éditeur cron partagé (tâches planifiées, planifications de sauvegarde)
  // TP.cronEditor(box, valeur, { ownerId }) : champ par champ (minute, heure, jour, mois, jour de la semaine) synchronisé avec la
  // saisie brute (champ « schedule ») et aperçu des 5 prochaines exécutions (GET /api/cron/preview).
  TP.cronEditor = function (box, value, opts) {
    opts = opts || {};
    const F = [
      { k: 0, label: t('Minute'), min: 0, max: 59 }, { k: 1, label: t('Heure'), min: 0, max: 23 }, { k: 2, label: t('Jour du mois'), min: 1, max: 31 },
      { k: 3, label: t('Mois'), min: 1, max: 12 }, { k: 4, label: t('Jour de la semaine'), min: 0, max: 6 },
    ];
    const DAYS = [[1, t('Lun')], [2, t('Mar')], [3, t('Mer')], [4, t('Jeu')], [5, t('Ven')], [6, t('Sam')], [0, t('Dim')]];
    const PRESETS = [['', t('Modèles…')], ['*/5 * * * *', t('Toutes les 5 minutes')], ['0 * * * *', t('Chaque heure')], ['0 3 * * *', t('Chaque jour à 3h')],
      ['0 3 * * 1-5', t('Du lundi au vendredi à 3h')], ['0 3 * * 0', t('Chaque dimanche à 3h')], ['0 3 1 * *', t('Le 1er du mois à 3h')]];
    const fieldHtml = (f) => '<div class="field" style="margin:0"><label>' + TP.esc(f.label) + '</label><div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">' +
      '<select class="input" data-mode="' + f.k + '" style="width:auto"><option value="every">' + t('Toutes') + '</option><option value="step">' + t('Toutes les…') + '</option><option value="at">' + t('Valeurs précises') + '</option></select>' +
      (f.k === 4 ? '<span data-days style="display:flex;gap:6px;flex-wrap:wrap">' + DAYS.map((d) => '<label class="check small"><input type="checkbox" data-day="' + d[0] + '"> <span>' + TP.esc(d[1]) + '</span></label>').join('') + '</span>' : '') +
      '<input class="input" data-val="' + f.k + '" style="width:9em" placeholder="' + (f.k === 4 ? '1-5' : f.min + '-' + f.max + ', …') + '"></div></div>';
    box.innerHTML = '<div class="cron-editor">' +
      '<div class="f2">' + TP.field('cron_preset', t('Modèle'), { type: 'select', options: PRESETS }) + TP.field('schedule', t('Expression cron'), { value: value || '0 3 * * *', hint: t('min heure jour mois jour_semaine (0 ou 7 = dimanche)') }) + '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:8px">' + F.map(fieldHtml).join('') + '</div>' +
      '<div data-preview class="small mt" style="min-height:3em"></div></div>';
    const raw = TP.qs('[name=schedule]', box);
    const preset = TP.qs('[name=cron_preset]', box);
    preset.removeAttribute('name');
    const expand = (txt, min, max) => { const out = new Set(); String(txt).split(',').forEach((p) => { const m = p.trim().match(/^(\d+)(?:-(\d+))?$/); if (!m) return; const a = +m[1], b = m[2] !== undefined ? +m[2] : a; for (let i = a; i <= b && i <= max + 1; i++) out.add(i === 7 ? 0 : i); }); return out; };
    const toFields = () => {
      let expr = raw.value.trim();
      const alias = { '@hourly': '0 * * * *', '@daily': '0 3 * * *', '@weekly': '0 3 * * 0', '@monthly': '0 3 1 * *', '@minutely': '* * * * *' };
      expr = alias[expr] || expr;
      const parts = expr.split(/\s+/);
      if (parts.length !== 5) return;
      F.forEach((f) => {
        const p = parts[f.k], mode = TP.qs('[data-mode="' + f.k + '"]', box), val = TP.qs('[data-val="' + f.k + '"]', box);
        if (p === '*' || p === '?') { mode.value = 'every'; val.value = ''; }
        else if (/^\*\/\d+$/.test(p)) { mode.value = 'step'; val.value = p.slice(2); }
        else { mode.value = 'at'; val.value = p; }
        if (f.k === 4) { const set = mode.value === 'at' && /^[\d,\-]+$/.test(p) ? expand(p, 0, 7) : new Set(); TP.qsa('[data-day]', box).forEach((c) => c.checked = set.has(Number(c.dataset.day))); }
        showField(f.k);
      });
    };
    const showField = (k) => {
      const mode = TP.qs('[data-mode="' + k + '"]', box).value, val = TP.qs('[data-val="' + k + '"]', box), days = k === 4 ? TP.qs('[data-days]', box) : null;
      val.style.display = mode === 'every' || (days && mode === 'at') ? 'none' : '';
      if (days) days.style.display = mode === 'at' ? 'flex' : 'none';
    };
    const fromFields = () => {
      const parts = F.map((f) => {
        const mode = TP.qs('[data-mode="' + f.k + '"]', box).value, v = TP.qs('[data-val="' + f.k + '"]', box).value.trim();
        if (mode === 'every') return '*';
        if (mode === 'step') return '*/' + (parseInt(v, 10) > 0 ? parseInt(v, 10) : 5);
        if (f.k === 4) { const d = TP.qsa('[data-day]:checked', box).map((c) => Number(c.dataset.day)); return d.length ? d.sort((a, b) => a - b).join(',') : '*'; }
        return v || String(f.min);
      });
      raw.value = parts.join(' ');
      refresh();
    };
    const refresh = TP.debounce(async () => {
      const out = TP.qs('[data-preview]', box);
      try {
        const r = await TP.get('/api/cron/preview?schedule=' + encodeURIComponent(raw.value.trim()) + (opts.ownerId ? '&owner_id=' + opts.ownerId : ''));
        const d = r.data;
        out.innerHTML = '<b>' + t('Prochaines exécutions') + '</b> : ' + (d.next.length ? d.next.map((x) => '<span class="badge">' + TP.esc(TP.fmtDate(x)) + '</span>').join(' ') : '—') +
          (!d.allowed ? '<div class="alert warn mt">' + TP.icon('alert') + '<div>' + t('Votre plan impose au moins {n} min entre deux exécutions (cette planification : {g} min).', { n: d.plan_min_interval, g: d.min_interval }) + '</div></div>' : '');
      } catch (e) { out.innerHTML = '<span class="badge danger">' + TP.esc(e.message) + '</span>'; }
    }, 350);
    TP.qsa('[data-mode]', box).forEach((s) => s.onchange = () => { showField(Number(s.dataset.mode)); fromFields(); });
    TP.qsa('[data-val], [data-day]', box).forEach((i) => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', fromFields));
    raw.addEventListener('input', () => { toFields(); refresh(); });
    preset.onchange = () => { if (preset.value) { raw.value = preset.value; toFields(); refresh(); } };
    toFields(); refresh();
    return { value: () => raw.value.trim(), set: (v) => { raw.value = v; toFields(); refresh(); } };
  };

  // ---------------------------------------------------------------- Sauvegardes
  // Onglets : inventaire (navigation / restauration granulaire, vérification, restauration guidée du serveur), planifications (GFS, incrémentales,
  // chiffrement, profil « Serveur complet »), destinations (zip, restic, Borg, rsync…). Chiffrement des archives et options : fenêtres dédiées.
  let bkTab = 'list', bkFilter = '';
  const SCOPE_CLS = { site: 'info', database: 'violet', mailbox: 'ok', mail_domain: 'ok', account: 'warn', server: 'danger', path: '' };
  const scopeLabel = (s) => ({ site: t('Site'), database: t('Base'), mailbox: t('Boîte mail'), mail_domain: t('Domaine mail'), account: t('Compte'), server: t('Serveur'), path: t('Dossier') }[s] || s);
  const verifyBadge = (b) => b.verify_status === 'ok' ? '<span title="' + TP.esc(t('Vérifiée le {d}', { d: TP.fmtDate(b.verified_at) }) + (b.sha256 ? ' · sha256 ' + b.sha256.slice(0, 16) + '…' : '')) + '">' + TP.badge(t('Intègre'), 'ok') + '</span>'
    : b.verify_status === 'error' ? '<span title="' + TP.esc(b.verify_message || '') + '">' + TP.badge(t('Corrompue'), 'danger') + '</span>' : '<span class="muted">—</span>';
  const ENG_CLS = { zip: '', restic: 'violet', borg: 'violet', rsync: 'info' };
  const engLabel = (e, caps) => ((caps || {}).engine_labels || {})[e] || e;
  // « complète / incrémentale #n » (moteur natif), « partielle » (une partie des données manque), « serveur complet »
  const modeBadge = (b) => b.mode === 'incremental' ? ' ' + TP.badge(t('incrémentale') + ' #' + b.seq, 'info') : (b.mode === 'full' && b.chain_id ? ' ' + TP.badge(t('complète'), '') : '');
  const statusBadge = (b) => b.status === 'partial' ? ' <span title="' + TP.esc((b.errors || []).join('\n')) + '">' + TP.badge(t('Partielle'), 'warn') + '</span>' : '';
  const profileBadge = (b) => b.profile === 'full' ? ' ' + TP.badge(t('configuration comprise'), 'violet') : '';
  // Libellés renvoyés par le serveur (services/backup_engine.py : KIND_LABELS, S3_PROVIDERS), traduits ici ; ce bloc sert au relevé des chaînes à traduire :
  /* t('Dossier local (ou monté : NFS, disque externe)') t('S3 / compatible (AWS, Wasabi, R2, MinIO…)') t('SFTP / SSH') t('Backblaze B2') t('Microsoft Azure Blob') t('Google Cloud Storage') t('OpenStack Swift') t('Serveur REST restic') t('WebDAV (Nextcloud, ownCloud, SharePoint…)') t('Partage SMB / CIFS') t('Microsoft OneDrive / SharePoint (via rclone)') t('Dropbox (via rclone)') t('Box (via rclone)') t('pCloud (via rclone)') t('rclone (autre)') t('FTP (via rclone)') t('Google Drive (via rclone)') t('Autre service compatible S3') t('MinIO (auto-hébergé)') t('Ceph / RadosGW') t('Storj (passerelle S3)') t('Google Cloud Storage (interopérabilité S3)') t('Backblaze B2 (API S3)') t('Amazon S3') t('Cloudflare R2') t('DigitalOcean Spaces') t('Scaleway Object Storage') t('OVHcloud Object Storage') t('Hetzner Object Storage') t('Exoscale SOS') t('Akamai / Linode Object Storage') t('IONOS S3') t('IDrive e2') t('Wasabi') */
  const DEST_FIELDS = {
    local: [['path', t('Dossier'), '/mnt/sauvegardes']],
    s3: [['provider', t('Fournisseur'), '', 'select:s3'], ['endpoint', t('Point d\'accès (vide : déduit du fournisseur)'), 's3.amazonaws.com'], ['bucket', t('Bucket'), 'mes-sauvegardes'], ['region', t('Région'), 'eu-west-3'], ['account_id', t('Identifiant de compte (Cloudflare R2)'), ''],
      ['path', t('Préfixe'), 'toutpanel'], ['access_key', t('Clé d\'accès'), '', 'secret'], ['secret_key', t('Clé secrète'), '', 'secret']],
    sftp: [['host', t('Hôte'), 'backup.example.com'], ['port', t('Port'), '22'], ['user', t('Utilisateur'), 'backup'], ['path', t('Dossier distant'), 'toutpanel'], ['key_path', t('Clé SSH privée (chemin)'), '/root/.ssh/id_ed25519']],
    b2: [['bucket', t('Bucket'), 'mes-sauvegardes'], ['path', t('Préfixe'), 'toutpanel'], ['account_id', t('Identifiant de clé'), ''], ['account_key', t('Clé d\'application'), '', 'secret']],
    ftp: [['host', t('Hôte'), 'ftp.example.com'], ['port', t('Port'), '21'], ['user', t('Utilisateur'), ''], ['password', t('Mot de passe'), '', 'secret'], ['path', t('Dossier distant'), 'toutpanel']],
    gdrive: [['token', t('Jeton (JSON de « rclone authorize drive »)'), '{"access_token":…}', 'secret'], ['client_id', t('Client ID (optionnel)'), ''], ['client_secret', t('Secret client (optionnel)'), '', 'secret'], ['root_folder_id', t('Dossier racine (ID)'), ''], ['path', t('Dossier'), 'toutpanel']],
    azure: [['account_name', t('Compte de stockage'), 'monstockage'], ['container', t('Conteneur'), 'sauvegardes'], ['path', t('Préfixe'), 'toutpanel'], ['account_key', t('Clé du compte'), '', 'secret'], ['sas_token', t('ou jeton SAS'), 'sv=2022-11-02&…', 'secret'],
      ['endpoint_suffix', t('Suffixe du point d\'accès (optionnel)'), 'core.windows.net']],
    gcs: [['bucket', t('Bucket'), 'mes-sauvegardes'], ['project_id', t('Projet Google Cloud (optionnel)'), 'mon-projet-123'], ['path', t('Préfixe'), 'toutpanel'],
      ['service_account_json', t('Clé du compte de service (fichier JSON)'), '{"type":"service_account",…}', 'secret']],
    swift: [['auth_url', t('URL d\'authentification'), 'https://auth.cloud.example/v3'], ['container', t('Conteneur'), 'sauvegardes'], ['user', t('Utilisateur'), ''], ['password', t('Mot de passe'), '', 'secret'], ['project', t('Projet'), ''],
      ['user_domain', t('Domaine de l\'utilisateur'), 'Default'], ['project_domain', t('Domaine du projet'), 'Default'], ['region', t('Région'), 'GRA'], ['path', t('Préfixe'), 'toutpanel']],
    rest: [['url', t('URL du serveur REST'), 'https://backup.example.com:8000/mon-depot/'], ['user', t('Utilisateur (optionnel)'), ''], ['password', t('Mot de passe (optionnel)'), '', 'secret']],
    webdav: [['url', t('URL WebDAV'), 'https://cloud.example.com/remote.php/dav/files/utilisateur/'], ['vendor', t('Type de serveur'), '', 'select:webdav'], ['user', t('Utilisateur'), ''], ['password', t('Mot de passe'), '', 'secret'],
      ['bearer_token', t('ou jeton « bearer »'), '', 'secret'], ['path', t('Dossier'), 'toutpanel']],
    smb: [['host', t('Hôte'), 'nas.example.com'], ['port', t('Port'), '445'], ['share', t('Partage'), 'sauvegardes'], ['user', t('Utilisateur'), ''], ['password', t('Mot de passe'), '', 'secret'], ['domain', t('Domaine (optionnel)'), 'WORKGROUP'],
      ['path', t('Dossier dans le partage'), 'toutpanel']],
    onedrive: [['token', t('Jeton (JSON de « rclone authorize onedrive »)'), '{"access_token":…}', 'secret'], ['drive_type', t('Type de lecteur'), '', 'select:onedrive'], ['drive_id', t('Identifiant du lecteur (optionnel)'), ''],
      ['client_id', t('Client ID (optionnel)'), ''], ['client_secret', t('Secret client (optionnel)'), '', 'secret'], ['path', t('Dossier'), 'toutpanel']],
    dropbox: [['token', t('Jeton (JSON de « rclone authorize dropbox »)'), '{"access_token":…}', 'secret'], ['client_id', t('Client ID (optionnel)'), ''], ['client_secret', t('Secret client (optionnel)'), '', 'secret'], ['path', t('Dossier'), 'toutpanel']],
    box: [['token', t('Jeton (JSON de « rclone authorize box »)'), '{"access_token":…}', 'secret'], ['client_id', t('Client ID (optionnel)'), ''], ['client_secret', t('Secret client (optionnel)'), '', 'secret'], ['path', t('Dossier'), 'toutpanel']],
    pcloud: [['token', t('Jeton (JSON de « rclone authorize pcloud »)'), '{"access_token":…}', 'secret'], ['hostname', t('Serveur pCloud'), '', 'select:pcloud'], ['path', t('Dossier'), 'toutpanel']],
    rclone: [['type', t('Type de stockage rclone'), 'onedrive'], ['options', t('Options (une par ligne : clé = valeur)'), 'token = {...}', 'area'], ['path', t('Dossier'), 'toutpanel']],
  };
  const ENGINE_NOTES = {
    zip: t('Archives .zip dans un dossier local : empreinte sha256 et contrôle CRC à la création, chiffrement AES-256-GCM optionnel (phrase secrète du panel) et sauvegardes incrémentales. Seul moteur de l\'édition Personnelle.'),
    restic: t('Dépôt restic chiffré et dédupliqué (chaque sauvegarde est un instantané incrémental) : dossier local, S3 et compatibles, SFTP, Backblaze B2, Azure, Google Cloud Storage, Swift, serveur REST, WebDAV, SMB ou rclone (FTP, Google Drive, OneDrive, Dropbox…).'),
    borg: t('Dépôt BorgBackup chiffré (repokey) et dédupliqué, en dossier local ou en SSH ; borg doit aussi être installé sur le serveur distant.'),
    rsync: t('rsync vers un dossier ou par SSH (clé). Disposition « tree » : un dossier par sauvegarde, fichiers inchangés en liens physiques (--link-dest, incrémentale côté serveur), EN CLAIR sur la destination. Disposition « archive » : archives natives (chiffrables, incrémentales) déposées par rsync.'),
  };

  // Archive chiffrée dont la phrase n'est pas dans le trousseau du panel (HTTP 423) : on la demande puis on recommence ; elle n'est jamais conservée par le navigateur.
  function askPassphrase(msg) {
    return new Promise((resolve) => {
      let done = false;
      TP.modal({ title: t('Phrase secrète de la sauvegarde'), body: '<div class="alert warn">' + TP.icon('lock') + '<div>' + TP.esc(msg || t('Cette archive est chiffrée et sa phrase secrète n\'est pas connue de ce panel.')) + '</div></div>' + TP.field('passphrase', t('Phrase secrète'), { type: 'password' }),
        okText: t('Déverrouiller'), onOk: (bg) => { const v = TP.qs('[name=passphrase]', bg).value; if (!v) throw new Error(t('Phrase secrète requise')); done = true; resolve(v); }, onClose: () => { if (!done) resolve(null); } });
    });
  }
  async function withPassphrase(fn) {
    try { return await fn(null); } catch (e) {
      if (e.status !== 423) throw e;
      const pw = await askPassphrase(e.message);
      if (!pw) throw new Error(t('Phrase secrète requise'));
      return fn(pw);
    }
  }
  const pwHeaders = (pw) => pw ? { headers: { 'X-Backup-Passphrase': pw } } : undefined;

  function openBrowser(b, ctx) {
    const sel = new Set();
    let cur = '', pw = null;
    const dbOpts = [['', t('Base d\'origine')]].concat((ctx.databases || []).map((x) => [x.id, x.name + ' (' + x.engine + ')']));
    const notes = (b.mode === 'incremental' ? '<div class="alert info">' + TP.icon('info') + '<div>' + t('Sauvegarde incrémentale n°{n} : le contenu affiché est l\'état complet à cette date (la complète et les incrémentales précédentes de la chaîne sont appliquées dans l\'ordre).', { n: b.seq }) + '</div></div>' : '') +
      (b.encrypted && (b.engine === 'zip' || b.engine === 'rsync') ? '<div class="alert info">' + TP.icon('lock') + '<div>' + t('Archive chiffrée : elle est déchiffrée temporairement sur le serveur pour être parcourue ou restaurée.') + '</div></div>' : '');
    TP.modal({ title: t('Contenu de la sauvegarde') + ' #' + b.id + ' · ' + b.target, size: 'lg',
      body: notes + '<div data-crumb class="small mono mb"></div><div data-list style="max-height:45vh;overflow:auto"></div><div class="small muted mt" data-sel></div>' +
        '<div class="form mt"><div class="f2">' + TP.field('target', t('Restaurer'), { type: 'select', value: 'inplace', options: [['inplace', t('En place (sauvegarde de sécurité préalable)')], ['folder', t('Dans un dossier')]] }) +
        '<div data-folder style="display:none">' + TP.field('folder', t('Dossier de destination'), { placeholder: '/www/wwwroot/site/restauration' }) + '</div></div>' +
        (b.scope === 'database' || b.scope === 'account' || b.scope === 'server' ? TP.field('database', t('Base cible des dumps'), { type: 'select', options: dbOpts, hint: t('Les dumps sélectionnés sont réimportés (en place) ou copiés dans le dossier.') }) : '') + '</div>',
      footer: '<button class="btn" data-close>' + t('Fermer') + '</button><button class="btn primary" data-go>' + TP.icon('refresh') + t('Restaurer la sélection') + '</button>',
      onOpen: (bg, close) => {
        const tsel = TP.qs('[name=target]', bg);
        tsel.onchange = () => { TP.qs('[data-folder]', bg).style.display = tsel.value === 'folder' ? '' : 'none'; };
        const updSel = () => { TP.qs('[data-sel]', bg).textContent = sel.size ? t('{n} élément(s) sélectionné(s)', { n: sel.size }) : t('Aucune sélection : toute la sauvegarde sera restaurée'); };
        const load = async (path) => {
          const list = TP.qs('[data-list]', bg);
          list.innerHTML = TP.loading();
          try {
            const r = await withPassphrase(async (p) => { if (p) pw = p; return TP.get('/api/backups/' + b.id + '/browse?path=' + encodeURIComponent(path), pwHeaders(pw)); });
            const d = r.data; cur = d.path;
            const parts = cur ? cur.split('/') : [];
            TP.qs('[data-crumb]', bg).innerHTML = '<a href="#" data-nav="">/</a>' + parts.map((p, i) => ' / <a href="#" data-nav="' + TP.esc(parts.slice(0, i + 1).join('/')) + '">' + TP.esc(p) + '</a>').join('') + ' <span class="muted">· ' + t('{n} fichier(s) au total', { n: d.files }) + '</span>';
            list.innerHTML = TP.table([
              { label: '', render: (e) => '<input type="checkbox" data-pick="' + TP.esc(e.path) + '"' + (sel.has(e.path) ? ' checked' : '') + ' aria-label="' + TP.esc(e.name) + '">' },
              { label: t('Nom'), render: (e) => e.type === 'dir' ? '<a href="#" data-nav="' + TP.esc(e.path) + '">' + TP.icon('folder') + ' ' + TP.esc(e.name) + '</a>' : TP.icon('file') + ' ' + TP.esc(e.name) + (d.dumps.includes(e.path) ? ' ' + TP.badge(t('dump'), 'violet') : '') },
              { label: t('Taille'), cls: 'r', render: (e) => TP.fmtBytes(e.size) + (e.type === 'dir' ? ' <span class="muted small">(' + e.count + ')</span>' : '') },
            ], d.entries, { empty: t('Dossier vide'), icon: 'folder' });
            TP.qsa('[data-nav]', bg).forEach((a) => a.onclick = (ev) => { ev.preventDefault(); load(a.dataset.nav); });
            TP.qsa('[data-pick]', bg).forEach((c) => c.onchange = () => { if (c.checked) sel.add(c.dataset.pick); else sel.delete(c.dataset.pick); updSel(); });
          } catch (e) { list.innerHTML = '<div class="alert danger">' + TP.icon('alert') + '<div>' + TP.esc(e.message) + '</div></div>'; }
        };
        TP.qs('[data-go]', bg).onclick = async () => {
          const f = TP.formData(bg);
          const body = { items: Array.from(sel), target: f.target, folder: f.folder || '' };
          if (f.database) body.database = Number(f.database);
          if (pw) body.passphrase = pw;
          const msg = f.target === 'inplace' ? t('Les éléments sélectionnés écraseront les fichiers actuels (une sauvegarde de sécurité est créée avant). Continuer ?') : t('Extraire la sélection dans {d} ?', { d: '<code>' + TP.esc(f.folder) + '</code>' });
          if (!(await TP.confirm(t('Restaurer'), msg, { danger: f.target === 'inplace' }))) return;
          try {
            const r = await withPassphrase(async (p) => { if (p) { pw = p; body.passphrase = p; } return TP.post('/api/backups/' + b.id + '/restore', body); });
            close(); TP.taskModal(r.data.task_id, t('Restauration'), ctx.reload);
          } catch (e) { TP.toast(e.message, 'error'); }
        };
        updSel(); load('');
      } });
  }

  // Restauration guidée d'une sauvegarde « Serveur complet » : étapes dans l'ordre, simulation puis application, services rechargés.
  async function openServerRestore(b, ctx) {
    let pw = null, plan;
    try { plan = (await withPassphrase(async (p) => { if (p) pw = p; return TP.get('/api/backups/' + b.id + '/server-plan', pwHeaders(pw)); })).data; } catch (e) { TP.toast(e.message, 'error'); return; }
    const steps = plan.steps.map((s, i) => '<li style="margin:.35rem 0"><label class="check"><input type="checkbox" data-step="' + TP.esc(s.category) + '"' + (s.manual || s.category === 'panel' ? ' disabled' : ' checked') + '> <span><b>' + (i + 1) + '. ' + TP.esc(s.label) + '</b> <span class="muted small">· ' + t('{n} fichier(s)', { n: s.files }) + (s.services.length ? ' · ' + t('rechargement') + ' : ' + TP.esc(s.services.join(', ')) : '') + '</span>' +
      (s.category === 'panel' ? '<div class="small muted">' + t('Base, réglages et clé du panel : jamais écrasés depuis le panel en marche. En ligne de commande, panel arrêté : toutpanel backup restore-server FICHIER --apply --panel') + '</div>' : '') +
      (s.manual ? '<div class="small muted">' + t('Règles restaurées avec la base du panel ; utilisez ensuite Pare-feu → Réappliquer. Les exports nftables / iptables servent de référence.') + '</div>' : '') + '</span></label></li>').join('');
    TP.modal({ title: t('Restauration guidée du serveur') + ' · #' + b.id, size: 'lg',
      body: '<div class="alert info">' + TP.icon('info') + '<div>' + t('Sauvegarde du {d}{h}. La configuration est restaurée dans cet ordre ; chaque fichier remplacé est conservé sous le nom « fichier.pre-restore-AAAAMMJJ… » ; nginx est testé avant rechargement. Commencez par une simulation.', { d: TP.fmtDate(plan.created), h: plan.hostname ? ' · ' + plan.hostname : '' }) + '</div></div>' +
        '<ol style="list-style:none;padding:0;margin:.6rem 0">' + steps + '</ol>' +
        '<details class="mt"><summary><b>' + t('Procédure complète sur un serveur neuf') + '</b></summary><ol class="small" style="margin:.5rem 0 0 1.2rem">' + plan.procedure.map((x) => '<li>' + TP.esc(x) + '</li>').join('') + '</ol></details>' +
        '<details class="mt"><summary><b>' + t('Ce que la sauvegarde ne contient PAS') + '</b></summary><ul class="small" style="margin:.5rem 0 0 1.2rem">' + plan.not_included.map((x) => '<li>' + TP.esc(x) + '</li>').join('') + '</ul></details>',
      footer: '<button class="btn" data-close>' + t('Fermer') + '</button><button class="btn" data-sim>' + TP.icon('eye') + t('Simuler') + '</button><button class="btn danger" data-apply>' + TP.icon('refresh') + t('Restaurer la configuration') + '</button>',
      onOpen: (bg, close) => {
        const run = async (apply) => {
          const chosen = TP.qsa('[data-step]:checked', bg).map((c) => c.dataset.step);
          if (!chosen.length) { TP.toast(t('Choisissez au moins une étape'), 'error'); return; }
          if (apply && !(await TP.confirm(t('Restaurer la configuration'), t('Les fichiers de configuration seront remplacés (anciens fichiers conservés en .pre-restore-…) et les services rechargés. Continuer ?'), { danger: true }))) return;
          try {
            const body = { steps: chosen, apply: !!apply }; if (pw) body.passphrase = pw;
            const r = await TP.post('/api/backups/' + b.id + '/restore-server', body);
            TP.taskModal(r.data.task_id, apply ? t('Restauration guidée') : t('Simulation'), ctx.reload);
          } catch (e) { TP.toast(e.message, 'error'); }
        };
        TP.qs('[data-sim]', bg).onclick = () => run(false);
        TP.qs('[data-apply]', bg).onclick = () => run(true);
      } });
  }

  // Chiffrement des archives natives : phrase secrète (jamais réaffichée), chiffrement par défaut / obligatoire, avertissement de perte.
  async function openEncryption(enc, ctx) {
    enc = enc || (await TP.get('/api/backups/encryption')).data;
    TP.modal({ title: t('Chiffrement des sauvegardes'), size: 'lg', okText: t('Enregistrer'),
      body: '<div class="alert warn">' + TP.icon('alert') + '<div><b>' + t('Sans la phrase secrète, les sauvegardes chiffrées sont définitivement illisibles.') + '</b> ' + t('Personne ne peut les récupérer, pas même l\'éditeur. Conservez la phrase hors du serveur (gestionnaire de mots de passe, coffre) : le serveur peut être perdu en même temps que ses sauvegardes.') + '</div></div>' +
        '<p class="small muted">' + t('Les archives natives (zip, rsync « archive ») sont chiffrées en AES-256-GCM, bloc par bloc ; la clé est dérivée de la phrase par scrypt. restic et Borg ont leur propre mot de passe de dépôt. La phrase est stockée chiffrée avec la clé du panel et n\'apparaît jamais dans les journaux.') + '</p>' +
        (enc.configured ? '<div class="alert info">' + TP.icon('lock') + '<div>' + t('Phrase secrète définie (clé {k}, le {d}). Une nouvelle phrase s\'applique aux prochaines archives ; l\'ancienne reste utilisable pour relire les archives déjà produites.', { k: enc.key_id, d: TP.fmtDate(enc.created_at) }) + '</div></div>' : '<div class="alert info">' + TP.icon('info') + '<div>' + t('Aucune phrase secrète : les archives natives ne sont pas chiffrées.') + '</div></div>') +
        '<div class="form"><div class="f2">' + TP.field('passphrase', enc.configured ? t('Nouvelle phrase secrète (optionnel)') : t('Phrase secrète'), { type: 'password', hint: t('{n} caractères minimum ; une phrase de plusieurs mots est préférable.', { n: enc.min_length || 12 }), attrs: ' autocomplete="new-password"' }) +
        TP.field('confirm', t('Confirmation'), { type: 'password', attrs: ' autocomplete="new-password"' }) + '</div>' +
        TP.field('ack', t('J\'ai conservé cette phrase en lieu sûr, hors de ce serveur'), { type: 'checkbox', value: false }) +
        TP.field('backup_encrypt_default', t('Chiffrer par défaut les archives natives'), { type: 'checkbox', value: !!enc.default, hint: t('Sauvegardes manuelles, planifiées et de sécurité (sauf choix contraire).') }) +
        TP.field('backup_encrypt_required', t('Refuser toute sauvegarde non chiffrée'), { type: 'checkbox', value: !!enc.required, hint: t('Une sauvegarde non chiffrée (archive sans phrase, rsync « tree ») est alors refusée et signalée.') }) + '</div>',
      onOk: async (bg) => {
        const f = TP.formData(bg);
        if (f.passphrase) {
          if (f.passphrase !== f.confirm) throw new Error(t('La confirmation ne correspond pas à la phrase secrète'));
          if (!f.ack) throw new Error(t('Confirmez que vous avez conservé la phrase hors du serveur'));
          await TP.post('/api/backups/encryption', { passphrase: f.passphrase, confirm: f.confirm });
        }
        if (!!enc.default !== f.backup_encrypt_default || !!enc.required !== f.backup_encrypt_required) await TP.post('/api/settings', { backup_encrypt_default: f.backup_encrypt_default, backup_encrypt_required: f.backup_encrypt_required });
        TP.toast(t('Chiffrement des sauvegardes enregistré'));
        ctx.reload();
      } });
  }

  // Options générales : conservation, incrémentales, mode strict, vérification, test de restauration, rapport hebdomadaire.
  function openOptions(o, ctx) {
    TP.modal({ title: t('Options des sauvegardes'), size: 'lg', okText: t('Enregistrer'),
      body: '<div class="form"><div class="f2">' + TP.field('backup_keep', t('Sauvegardes manuelles conservées par cible'), { type: 'number', value: o.backup_keep }) +
        TP.field('backup_full_every', t('Incrémentales : nouvelle complète après N incrémentales'), { type: 'number', value: o.backup_full_every, hint: t('0 = jamais ; sans effet sur restic, Borg et rsync « tree » (incrémentaux par nature).') }) + '</div>' +
        TP.field('backup_strict', t('Mode strict : un dump de base en échec annule la sauvegarde'), { type: 'checkbox', value: !!o.backup_strict, hint: t('Sinon la sauvegarde est créée mais marquée « partielle » et une alerte est envoyée.') }) +
        '<div class="f2">' + TP.field('backup_verify_weekly', t('Vérification hebdomadaire de l\'intégrité'), { type: 'checkbox', value: !!o.backup_verify_weekly, hint: t('Dimanche 4 h 17 : sha256, CRC, authentification AES-GCM, contrôle des dépôts.') }) +
        TP.field('backup_verify_count', t('Sauvegardes récentes revérifiées'), { type: 'number', value: o.backup_verify_count }) + '</div>' +
        '<div class="f2">' + TP.field('backup_restore_test', t('Test de restauration (désactivé par défaut)'), { type: 'checkbox', value: !!o.backup_restore_test, hint: t('Lors de la vérification : chaque dump MySQL / PostgreSQL est réimporté dans une base temporaire « nom_tpverify » (supprimée ensuite) et un échantillon de fichiers est restauré puis contrôlé (somme de contrôle).') }) +
        TP.field('backup_restore_test_files', t('Fichiers restaurés par le test'), { type: 'number', value: o.backup_restore_test_files, hint: t('0 = pas de test des fichiers.') }) + '</div>' +
        TP.field('backup_report_weekly', t('Rapport hebdomadaire des sauvegardes (désactivé par défaut)'), { type: 'checkbox', value: !!o.backup_report_weekly, hint: t('Chaque lundi à 7 h 13 sur les canaux d\'alerte : sauvegardes de la semaine, planifications et vérifications en échec, sauvegardes partielles.') }) +
        '<div class="f2">' + TP.field('backup_pre_op', t('Sauvegarde de sécurité avant les opérations risquées'), { type: 'checkbox', value: !!o.backup_pre_op }) +
        TP.field('backup_before_delete', t('Sauvegarde avant suppression d\'un site ou d\'une base'), { type: 'checkbox', value: !!o.backup_before_delete }) + '</div></div>',
      footer: '<button class="btn" data-close>' + t('Annuler') + '</button><button class="btn" data-report>' + TP.icon('mail') + t('Envoyer un rapport maintenant') + '</button><button class="btn primary" data-ok>' + t('Enregistrer') + '</button>',
      onOpen: (bg) => { TP.qs('[data-report]', bg).onclick = async () => { try { await TP.post('/api/backups/report'); TP.toast(t('Rapport envoyé')); } catch (e) { TP.toast(e.message, 'error'); } }; },
      onOk: async (bg) => { const f = TP.formData(bg); await TP.post('/api/settings', f); TP.toast(t('Options enregistrées')); ctx.reload(); } });
  }

  // Listes déroulantes des champs « select:<liste> » des destinations
  function selectOptions(name, caps) {
    if (name === 's3') return [['', t('Amazon S3 ou autre (point d\'accès libre)')]].concat(Object.entries(caps.s3_providers || {}).map(([id, v]) => [id, t(v.label)]));
    if (name === 'webdav') return (caps.webdav_vendors || ['other']).map((v) => [v, v === 'other' ? t('Autre / générique') : v]);
    if (name === 'onedrive') return [['personal', t('Personnel')], ['business', t('Professionnel (Microsoft 365)')], ['documentLibrary', t('Bibliothèque de documents SharePoint')]];
    if (name === 'pcloud') return [['api.pcloud.com', t('Amérique (api.pcloud.com)')], ['eapi.pcloud.com', t('Europe (eapi.pcloud.com)')]];
    return [];
  }
  function destForm(d, caps) {
    d = d || { kind: 'local', engine: '', config: {} };
    const engine = d.engine || (d.kind === 'local' ? 'zip' : 'restic'), cfg0 = d.config || {};
    const engOpts = (caps.engines || ['zip', 'restic']).map((e) => [e, engLabel(e, caps)]);
    const kinds = (caps.kinds || Object.keys(DEST_FIELDS)).map((k) => [k, t((caps.kind_labels || {})[k] || k)]);
    const eng = (list, html) => '<div data-eng="' + list + '">' + html + '</div>';
    return '<div class="form"><div class="f2">' + TP.field('name', t('Nom'), { value: d.name || '' }) + TP.field('engine', t('Moteur'), { type: 'select', value: engine, options: engOpts }) + '</div>' +
      '<div class="f2">' + TP.field('kind', t('Type'), { type: 'select', value: d.kind, options: kinds }) + TP.field('default', t('Destination par défaut'), { type: 'checkbox', value: !!d.default }) + '</div>' +
      '<div class="alert info" data-engnote>' + TP.icon('info') + '<div></div></div>' +
      Object.entries(DEST_FIELDS).map(([k, fields]) => '<div data-kind="' + k + '"' + (k === d.kind ? '' : ' style="display:none"') + '><div class="f2">' + fields.map((f) => {
        const cfg = d.kind === k ? cfg0 : {};
        if (f[3] === 'secret') return TP.field('c_' + k + '_' + f[0], f[1], { type: ['token', 'service_account_json'].includes(f[0]) ? 'textarea' : 'password', value: '', placeholder: cfg[f[0] + '_set'] ? t('(inchangé)') : f[2] });
        if (f[3] && f[3].startsWith('select:')) return TP.field('c_' + k + '_' + f[0], f[1], { type: 'select', value: cfg[f[0]] ?? '', options: selectOptions(f[3].slice(7), caps) });
        if (f[3] === 'area') return TP.field('c_' + k + '_' + f[0], f[1], { type: 'textarea', rows: 3, value: Object.entries(cfg.options || {}).map(([a, v]) => a + ' = ' + v).join('\n'), placeholder: f[2] });
        return TP.field('c_' + k + '_' + f[0], f[1], { value: cfg[f[0]] ?? '', placeholder: f[2] });
      }).join('') + (k === 'ftp' ? TP.field('c_ftp_tls', t('TLS explicite (FTPS)'), { type: 'checkbox', value: (d.config || {}).tls !== false }) : '') + '</div></div>').join('') +
      eng('rsync', '<div class="f2">' + TP.field('e_layout', t('Disposition'), { type: 'select', value: cfg0.layout || 'tree', options: [['tree', t('tree : liens physiques, non chiffré')], ['archive', t('archive : archives natives, chiffrables')]] }) +
        TP.field('e_bwlimit', t('Limite de débit (Ko/s, 0 = illimité)'), { type: 'number', value: cfg0.bwlimit || 0 }) + '</div>' +
        '<div class="f2">' + TP.field('e_compress', t('Compression pendant le transfert (-z)'), { type: 'checkbox', value: !!cfg0.compress }) +
        TP.field('e_strict_host_key', t('Vérification de la clé d\'hôte SSH'), { type: 'select', value: cfg0.strict_host_key || 'accept-new', options: [['accept-new', t('Accepter à la première connexion')], ['yes', t('Stricte (known_hosts)')], ['no', t('Aucune (déconseillé)')]] }) + '</div>') +
      eng('borg', '<div data-borgssh>' + TP.field('e_remote_path', t('Commande borg sur le serveur distant (optionnel)'), { value: cfg0.remote_path || '', placeholder: 'borg' }) + '</div>') +
      eng('zip rsync', '<div data-encopt>' + TP.field('e_encrypt', t('Chiffrer les archives (AES-256-GCM, phrase secrète de sauvegarde)'), { type: 'checkbox', value: !!cfg0.encrypt, hint: t('Définissez d\'abord la phrase dans Sauvegardes → Chiffrement.') }) + '</div>') +
      '<div class="alert info mt">' + TP.icon('info') + '<div>' + t('Les identifiants sont chiffrés sur le serveur et ne sont jamais réaffichés ; laissez un secret vide pour le conserver. FTP, Google Drive et les autres stockages passent par rclone. Moteurs restic, Borg, rsync et destinations distantes : édition Professionnelle.') + '<br>' + t('Jetons Google Drive, OneDrive, Dropbox, Box et pCloud : à produire avec « rclone authorize » sur un poste muni d\'un navigateur, puis à coller ici. Un dossier monté (NFS, disque externe) se déclare comme dossier local.') + '</div></div></div>';
  }
  function destCollect(bg) {
    const f = TP.formData(bg), cfg = {};
    Object.keys(f).forEach((k) => { const p = 'c_' + f.kind + '_'; if (k.startsWith(p)) cfg[k.slice(p.length)] = f[k]; });
    Object.keys(f).forEach((k) => { if (k.startsWith('e_')) cfg[k.slice(2)] = f[k]; });
    if (f.engine === 'rsync' && cfg.layout === 'tree') cfg.encrypt = false;
    if (f.engine === 'borg' && f.kind !== 'sftp') delete cfg.remote_path;
    return { name: f.name, kind: f.kind, engine: f.engine, default: f.default, enabled: true, config: cfg };
  }
  // Moteur ↔ types de destination acceptés, options propres au moteur, note explicative.
  function bindDestForm(bg, caps) {
    const k = TP.qs('[name=kind]', bg), e = TP.qs('[name=engine]', bg), lay = TP.qs('[name=e_layout]', bg);
    const allKinds = caps.kind_labels || {};
    const sync = () => {
      const allowed = (caps.engine_kinds || {})[e.value] || Object.keys(allKinds);
      const cur = k.value;
      k.innerHTML = allowed.map((x) => '<option value="' + TP.esc(x) + '"' + (x === cur ? ' selected' : '') + '>' + TP.esc(t(allKinds[x] || x)) + '</option>').join('');
      if (!allowed.includes(cur)) k.value = allowed[0];
      TP.qsa('[data-kind]', bg).forEach((p) => p.style.display = p.dataset.kind === k.value ? '' : 'none');
      TP.qsa('[data-eng]', bg).forEach((p) => p.style.display = p.dataset.eng.split(' ').includes(e.value) ? '' : 'none');
      const bs = TP.qs('[data-borgssh]', bg); if (bs) bs.style.display = k.value === 'sftp' ? '' : 'none';
      const eo = TP.qs('[data-encopt]', bg); if (eo) eo.style.display = e.value === 'zip' || (e.value === 'rsync' && lay && lay.value === 'archive') ? '' : 'none';
      TP.qs('[data-engnote] div', bg).textContent = ENGINE_NOTES[e.value] || '';
    };
    k.onchange = sync; e.onchange = sync; if (lay) lay.onchange = sync;
    const pv = TP.qs('[name=c_s3_provider]', bg);   // fournisseur S3 : le point d'accès et la région proposés suivent le choix
    if (pv) {
      const ep = TP.qs('[name=c_s3_endpoint]', bg), rg = TP.qs('[name=c_s3_region]', bg), ac = TP.qs('[name=c_s3_account_id]', bg);
      const hint = () => { const p = (caps.s3_providers || {})[pv.value]; ep.placeholder = p && p.endpoint ? p.endpoint : (p ? 'https://minio.local:9000' : 's3.amazonaws.com'); rg.placeholder = p && p.region ? p.region : 'eu-west-3';
        const f = ac && ac.closest('.field'); if (f) f.style.display = pv.value === 'r2' ? '' : 'none'; };
      pv.onchange = hint; hint();
    }
    sync();
  }
  function showRepoKey(d) {
    if (!d.repository_key) return;
    TP.modal({ title: d.engine === 'borg' ? t('Mot de passe du dépôt Borg') : t('Mot de passe du dépôt restic'), size: 'lg', body: '<div class="alert warn">' + TP.icon('alert') + '<div>' + t('Conservez ce mot de passe hors du serveur : il est affiché une seule fois et sans lui les sauvegardes de cette destination sont illisibles.') + '</div></div><pre class="pre mono">' + TP.esc(d.repository_key) + '</pre>',
      footer: '<button class="btn" data-copy>' + TP.icon('copy') + t('Copier') + '</button><button class="btn primary" data-close>' + t('J\'ai conservé le mot de passe') + '</button>',
      onOpen: (bg) => { TP.qs('[data-copy]', bg).onclick = () => TP.copy(d.repository_key); } });
  }

  function planForm(p, ctx) {
    p = p || { scope: {}, schedule: '0 3 * * *', keep_last: 3, keep_daily: 7, keep_weekly: 4, keep_monthly: 6, enabled: true, destination_id: ctx.defaultDest, mode: 'full', full_every: 7, encrypt: false, profile: 'data', strict: false };
    const sc = p.scope || {}, enc = ctx.enc || {};
    const pick = (key, items, label, fmt) => '<div class="field"><label>' + TP.esc(label) + '</label>' + (key === 'sites' || key === 'databases' ? '<label class="check"><input type="checkbox" data-all="' + key + '"' + (sc[key] === 'all' ? ' checked' : '') + '> <span>' + t('Tous (y compris ceux créés plus tard)') + '</span></label>' : '') +
      '<div data-pick="' + key + '" style="max-height:120px;overflow:auto;display:flex;flex-wrap:wrap;gap:4px 12px">' + (items.length ? items.map((x) => '<label class="check small"><input type="checkbox" data-id="' + x.id + '"' + (Array.isArray(sc[key]) && sc[key].includes(x.id) ? ' checked' : '') + '> <span>' + TP.esc(fmt(x)) + '</span></label>').join('') : '<span class="muted small">' + t('Aucun') + '</span>') + '</div></div>';
    return '<div class="form">' + (!p.id && ctx.owners.length ? '<div class="f2">' + TP.field('name', t('Nom'), { value: p.name || '' }) +
      TP.field('owner_id', t('Compte'), { type: 'select', value: '', options: [['', ctx.isAdmin ? t('Administrateur (global)') : t('Mon compte')]].concat(ctx.owners.map((o) => [o.id, o.name])), hint: t('Les éléments choisis doivent appartenir à ce compte.') }) + '</div>'
      : TP.field('name', t('Nom'), { value: p.name || '' })) +
      '<div class="f2">' + pick('sites', ctx.sites, t('Sites'), (x) => x.name) + pick('databases', ctx.databases, t('Bases de données'), (x) => x.name + ' (' + x.engine + ')') + '</div>' +
      '<div class="f2">' + pick('mail_domains', ctx.domains, t('Domaines mail'), (x) => x.domain) + pick('mailboxes', ctx.mailboxes, t('Boîtes mail'), (x) => x.address) + '</div>' +
      '<div class="f2">' + TP.field('account', t('Compte complet (sites, bases, mails)'), { type: 'checkbox', value: !!sc.account }) + (ctx.isAdmin ? TP.field('server', t('Serveur entier (sites, mails, bases, réglages et base du panel)'), { type: 'checkbox', value: !!sc.server }) : '') + '</div>' +
      (ctx.isAdmin ? '<div data-srvprofile style="' + (sc.server ? '' : 'display:none') + '">' + TP.field('profile', t('Profil du serveur entier'), { type: 'select', value: p.profile || 'data', options: [['data', t('Sites et données')], ['full', t('Serveur complet (configuration comprise)')]],
        hint: t('« Serveur complet » ajoute la configuration générée (vhosts, pools PHP-FPM, certificats et clés privées, DKIM, mail, DNS, FTP, crontabs, règles de pare-feu). Il exige une archive chiffrée (ou restic / Borg). Ni le système ni les paquets ne sont inclus.') }) + '</div>' : '') +
      (ctx.isAdmin ? TP.field('paths', t('Chemins supplémentaires (un par ligne)'), { type: 'textarea', rows: 2, value: (sc.paths || []).join('\n') }) : '') +
      TP.field('destination_id', t('Destination'), { type: 'select', value: p.destination_id || 0, options: [[0, t('Local (archives zip)')]].concat(ctx.dests.filter((d) => d.enabled !== false).map((d) => [d.id, d.name + ' · ' + t(d.kind_label || d.kind)])) }) +
      '<div data-cron></div>' +
      '<div class="f2">' + TP.field('mode', t('Type de sauvegarde'), { type: 'select', value: p.mode || 'full', options: [['full', t('Complète à chaque fois')], ['incremental', t('Incrémentale (seuls les fichiers modifiés)')]], hint: t('Archives natives (zip, rsync « archive ») ; restic, Borg et rsync « tree » sont incrémentaux par nature. La rétention conserve toujours la chaîne complète nécessaire.') }) +
      TP.field('full_every', t('Nouvelle complète après N incrémentales'), { type: 'number', value: p.full_every ?? 7, hint: t('0 = jamais.') }) + '</div>' +
      '<div class="f2">' + TP.field('encrypt', t('Chiffrer les archives (AES-256-GCM)'), { type: 'checkbox', value: !!p.encrypt, hint: enc.configured ? t('Phrase secrète définie. restic et Borg chiffrent toujours.') : t('Définissez d\'abord la phrase secrète (bouton « Chiffrement »). restic et Borg chiffrent toujours.') }) +
      (ctx.isAdmin ? TP.field('strict', t('Mode strict : un dump de base en échec annule la sauvegarde'), { type: 'checkbox', value: !!p.strict, hint: t('Sinon : sauvegarde « partielle » et alerte.') }) : '') + '</div>' +
      '<div class="f2">' + TP.field('keep_last', t('Dernières conservées'), { type: 'number', value: p.keep_last }) + TP.field('keep_daily', t('Quotidiennes'), { type: 'number', value: p.keep_daily }) + '</div>' +
      '<div class="f2">' + TP.field('keep_weekly', t('Hebdomadaires'), { type: 'number', value: p.keep_weekly }) + TP.field('keep_monthly', t('Mensuelles'), { type: 'number', value: p.keep_monthly }) + '</div>' +
      '<div class="f2">' + TP.field('use_snapshot', t('Instantané du système de fichiers (btrfs, ZFS, LVM) avant lecture'), { type: 'checkbox', value: !!p.use_snapshot, hint: t('Sans effet si le système de fichiers ne le permet pas.') }) +
      TP.field('enabled', t('Activée'), { type: 'checkbox', value: p.enabled !== false }) + '</div></div>';
  }
  function planCollect(bg) {
    const f = TP.formData(bg), scope = {};
    ['sites', 'databases', 'mail_domains', 'mailboxes'].forEach((k) => {
      const all = TP.qs('[data-all="' + k + '"]', bg);
      if (all && all.checked) { scope[k] = 'all'; return; }
      const ids = TP.qsa('[data-pick="' + k + '"] input:checked', bg).map((c) => Number(c.dataset.id));
      if (ids.length) scope[k] = ids;
    });
    if (f.account) scope.account = true;
    if (f.server) scope.server = true;
    if (f.paths) scope.paths = f.paths.split('\n').map((x) => x.trim()).filter(Boolean);
    const out = { name: f.name, scope, destination_id: Number(f.destination_id) || 0, schedule: f.schedule, keep_last: f.keep_last || 0, keep_daily: f.keep_daily || 0,
      keep_weekly: f.keep_weekly || 0, keep_monthly: f.keep_monthly || 0, use_snapshot: f.use_snapshot, enabled: f.enabled, encrypt: !!f.encrypt, mode: f.mode || 'full', full_every: f.full_every ?? 7,
      profile: f.server && f.profile ? f.profile : 'data', strict: !!f.strict };
    if (f.owner_id) out.owner_id = Number(f.owner_id);
    return out;
  }

  TP.registerPage('backups', {
    async render(root) {
      const reload = () => this.render(root);
      const [r, s, d, dl, pl, m] = await Promise.all([TP.get('/api/backups'), TP.get('/api/sites'), TP.get('/api/databases'), TP.get('/api/backups/destinations'),
        TP.get('/api/backups/plans'), TP.get('/api/mail').catch(() => ({ data: { domains: [], mailboxes: [] } }))]);
      const isAdmin = r.data.is_admin, caps = dl.data.capabilities || {}, dests = dl.data.destinations || [], enc = r.data.encryption || {}, opts = r.data.options || {};
      const ctx = { reload, isAdmin, enc, sites: s.data.sites || [], databases: d.data.databases || [], domains: m.data.domains || [], mailboxes: m.data.mailboxes || [],
        dests, defaultDest: r.data.default_destination || 0, owners: (r.data.owners || []).filter((o) => o.id !== (TP.user || {}).id) };
      const destName = (id) => id ? ((dests.find((x) => x.id === id) || {}).name || '#' + id) : t('Local');
      const rows = r.data.backups.filter((b) => bkFilter === '' ? true : bkFilter === 'manual' ? !b.tag : b.tag === bkFilter);
      const partial = r.data.backups.filter((b) => b.status === 'partial').slice(0, 3);
      const partialBanner = partial.length ? '<div class="alert warn" role="alert">' + TP.icon('alert') + '<div><b>' + (partial.length > 1 ? t('Sauvegardes partielles : une partie des données n\'a pas pu être sauvegardée') : t('Dernière sauvegarde partielle : une partie des données n\'a pas pu être sauvegardée')) + '</b>' +
        partial.map((b) => '<div class="small">#' + b.id + ' · ' + TP.esc(b.target) + ' · ' + TP.fmtDate(b.created_at) + ' — ' + TP.esc((b.errors || []).join(' ; ')) + '</div>').join('') +
        '<div class="small muted">' + t('Corrigez la cause (base inaccessible, droits…) puis relancez la sauvegarde ; le mode strict (Options) annule la sauvegarde au lieu de la marquer partielle.') + '</div></div></div>' : '';
      const encBanner = isAdmin ? '<div class="alert ' + (enc.configured ? 'info' : 'warn') + '" style="display:flex;align-items:center;gap:.8rem;flex-wrap:wrap">' + TP.icon('lock') + '<div style="flex:1;min-width:14rem">' +
        (enc.configured ? '<b>' + t('Archives natives chiffrables (AES-256-GCM)') + '</b> · ' + t('phrase secrète définie') + (enc.default ? ' · ' + t('chiffrées par défaut') : '') + (enc.required ? ' · ' + t('non chiffré refusé') : '')
          : '<b>' + t('Les archives zip ne sont pas chiffrées.') + '</b> ' + t('Définissez une phrase secrète pour les chiffrer (obligatoire pour le profil « Serveur complet » sans restic / Borg).')) + '</div>' +
        '<button class="btn sm" id="enc-open">' + TP.icon('key') + (enc.configured ? t('Gérer le chiffrement') : t('Activer le chiffrement')) + '</button></div>' : '';
      const listPane = '<div class="card"><div class="card-h"><div class="tabs sm" data-filter>' + [['', t('Toutes')], ['manual', t('Manuelles')], ['plan', t('Planifiées')], ['pre-op', t('De sécurité')]].map((x) => '<button' + (x[0] === bkFilter ? ' class="active"' : '') + ' data-f="' + x[0] + '">' + TP.esc(x[1]) + '</button>').join('') + '</div>' +
        (isAdmin ? '<button class="btn sm" id="verify-all">' + TP.icon('check') + t('Vérifier les plus récentes') + '</button>' : '') + '</div>' + TP.table([
          { label: t('Type'), render: (b) => TP.badge(scopeLabel(b.scope || b.kind), SCOPE_CLS[b.scope || b.kind] || '') + profileBadge(b) + (b.tag === 'pre-op' ? ' ' + TP.badge(t('sécurité'), 'warn') : b.tag === 'plan' ? ' ' + TP.badge(t('planifiée'), 'info') : '') + modeBadge(b) + statusBadge(b) },
          { label: t('Cible'), render: (b) => '<b>' + TP.esc(b.target) + '</b>' + (b.note ? '<div class="small muted">' + TP.esc(b.note) + '</div>' : '') + (b.owner ? '<div class="small muted">' + TP.esc(b.owner) + '</div>' : '') },
          { label: t('Destination'), render: (b) => '<span class="small">' + TP.esc(destName(b.destination_id)) + '</span> ' + TP.badge(b.engine || 'zip', ENG_CLS[b.engine] || '') + (b.encrypted ? ' <span title="' + TP.esc(t('Chiffrée')) + '">' + TP.icon('lock') + '</span>' : '') },
          { label: t('Taille'), render: (b) => TP.fmtBytes(b.size) },
          { label: t('Date'), cls: 'muted', render: (b) => TP.fmtDate(b.created_at) },
          { label: t('Intégrité'), render: verifyBadge },
          { label: '', cls: 'r', render: (b) => '<div class="actions"><button class="btn xs" data-a="browse" data-id="' + b.id + '" title="' + t('Parcourir et restaurer') + '" aria-label="' + t('Parcourir et restaurer') + '">' + TP.icon('folder') + '</button>' +
            (isAdmin && b.profile === 'full' && b.scope === 'server' ? '<button class="btn xs" data-a="srv" data-id="' + b.id + '" title="' + t('Restauration guidée du serveur') + '" aria-label="' + t('Restauration guidée du serveur') + '">' + TP.icon('tool') + '</button>' : '') +
            (b.downloadable ? '<a class="btn xs" href="/api/backups/' + b.id + '/download" title="' + t('Télécharger') + '" aria-label="' + t('Télécharger') + '">' + TP.icon('download') + '</a>' : '') +
            '<button class="btn xs" data-a="verify" data-id="' + b.id + '" title="' + t('Vérifier') + '" aria-label="' + t('Vérifier') + '">' + TP.icon('check') + '</button>' +
            '<button class="btn xs danger" data-a="del" data-id="' + b.id + '" aria-label="' + t('Supprimer') + '">' + TP.icon('trash') + '</button></div>' },
        ], rows, { empty: t('Aucune sauvegarde'), icon: 'backup', cta: { label: t('Nouvelle sauvegarde'), target: '#add' } }) + '</div>';
      const planPane = '<div class="card">' + TP.table([
        { label: t('Planification'), render: (p) => '<b>' + TP.esc(p.name) + '</b>' + (p.owner ? '<div class="small muted">' + TP.esc(p.owner) + '</div>' : '') + '<div class="small muted">' + TP.esc(Object.entries(p.scope).map(([k, v]) => k + (Array.isArray(v) ? ' (' + v.length + ')' : v === 'all' ? ' (' + t('tous') + ')' : '')).join(', ')) + '</div>' },
        { label: t('Destination'), render: (p) => TP.esc(destName(p.destination_id)) + (p.encrypt ? ' <span title="' + TP.esc(t('Archives chiffrées')) + '">' + TP.icon('lock') + '</span>' : '') },
        { label: t('Type'), render: (p) => (p.mode === 'incremental' ? TP.badge(t('incrémentale'), 'info') + '<div class="small muted">' + (p.full_every ? t('complète tous les {n}', { n: p.full_every }) : t('une seule complète')) + '</div>' : TP.badge(t('complète'), '')) + (p.profile === 'full' ? '<div>' + TP.badge(t('configuration comprise'), 'violet') + '</div>' : '') + (p.strict ? '<div class="small muted">' + t('mode strict') + '</div>' : '') },
        { label: t('Planning'), cls: 'mono', render: (p) => TP.esc(p.schedule) + (p.enabled ? '' : ' ' + TP.badge(t('désactivée'), '')) },
        { label: t('Rétention'), cls: 'small', render: (p) => t('{l} dern. · {d} j · {w} sem. · {m} mois', { l: p.keep_last, d: p.keep_daily, w: p.keep_weekly, m: p.keep_monthly }) },
        { label: t('Dernière'), render: (p) => p.last_run ? '<span class="muted small">' + TP.fmtDate(p.last_run) + '</span> ' + (p.last_status === 'ok' ? TP.badge('OK', 'ok') : p.last_status === 'partial' ? TP.badge(t('Partielle'), 'warn') : TP.badge(t('Erreur'), 'danger')) : '<span class="muted">—</span>' },
        { label: t('Prochaine'), cls: 'muted small', render: (p) => p.enabled && p.next_run ? TP.fmtDate(p.next_run) : '—' },
        { label: '', cls: 'r', render: (p) => '<div class="actions"><button class="btn xs" data-p="run" data-id="' + p.id + '" title="' + t('Exécuter maintenant') + '" aria-label="' + t('Exécuter maintenant') + '">' + TP.icon('play') + '</button>' + (p.last_message ? '<button class="btn xs" data-p="log" data-id="' + p.id + '" title="' + t('Dernier compte rendu') + '" aria-label="' + t('Dernier compte rendu') + '">' + TP.icon('logs') + '</button>' : '') +
          '<button class="btn xs" data-p="edit" data-id="' + p.id + '" aria-label="' + t('Modifier') + '">' + TP.icon('edit') + '</button><button class="btn xs danger" data-p="del" data-id="' + p.id + '" aria-label="' + t('Supprimer') + '">' + TP.icon('trash') + '</button></div>' },
      ], pl.data, { empty: t('Aucune planification'), icon: 'clock' }) + '</div>';
      const toolWarn = (tool, label, engine) => (!caps[tool] && dests.some((x) => x.engine === engine)) ? '<div class="alert warn">' + TP.icon('info') + '<div>' + t('{n} n\'est pas installé : les destinations {e} ne fonctionneront pas (Logiciels → {n}).', { n: label, e: engine }) + '</div></div>' : '';
      const destPane = '<div class="card">' + (caps.restic ? '' : '<div class="alert warn">' + TP.icon('info') + '<div>' + t('restic n\'est pas installé : seules les archives zip locales fonctionnent (Logiciels → restic, et rclone pour FTP / Google Drive).') + '</div></div>') + toolWarn('borg', 'BorgBackup', 'borg') + toolWarn('rsync', 'rsync', 'rsync') + TP.table([
        { label: t('Destination'), render: (x) => '<b>' + TP.esc(x.name) + '</b>' + (x.default ? ' ' + TP.badge(t('par défaut'), 'info') : '') + (x.global && !isAdmin ? ' ' + TP.badge(t('globale'), '') : '') + (x.config_error ? '<div class="small" style="color:var(--danger)">' + TP.esc(x.config_error) + '</div>' : '') },
        { label: t('Type'), render: (x) => TP.esc(t(x.kind_label || x.kind)) },
        { label: t('Moteur'), render: (x) => TP.badge(engLabel(x.engine, caps), ENG_CLS[x.engine] || '') + (x.engine === 'restic' || x.engine === 'borg' || (x.config && x.config.encrypt) ? ' <span title="' + TP.esc(t('Chiffrée')) + '">' + TP.icon('lock') + '</span>' : '') + (x.engine === 'rsync' && x.config ? '<div class="small muted">' + (x.config.layout === 'archive' ? t('archives') : t('tree · liens physiques')) + '</div>' : '') },
        { label: t('Dernier test'), render: (x) => x.last_test ? (x.last_test_ok ? TP.badge('OK', 'ok') : TP.badge(t('Échec'), 'danger')) + ' <span class="small muted" title="' + TP.esc(x.last_test_msg || '') + '">' + TP.fmtDate(x.last_test) + '</span>' : '<span class="muted">—</span>' },
        { label: '', cls: 'r', render: (x) => x.global && !isAdmin ? '' : '<div class="actions"><button class="btn xs" data-d="test" data-id="' + x.id + '" title="' + t('Tester la connexion') + '" aria-label="' + t('Tester la connexion') + '">' + TP.icon('activity') + '</button>' + (isAdmin && x.key_present ? '<button class="btn xs" data-d="key" data-id="' + x.id + '" title="' + t('Exporter la clé du dépôt') + '" aria-label="' + t('Exporter la clé du dépôt') + '">' + TP.icon('key') + '</button>' : '') +
          '<button class="btn xs" data-d="edit" data-id="' + x.id + '" aria-label="' + t('Modifier') + '">' + TP.icon('edit') + '</button><button class="btn xs danger" data-d="del" data-id="' + x.id + '" aria-label="' + t('Supprimer') + '">' + TP.icon('trash') + '</button></div>' },
      ], dests, { empty: t('Aucune destination : les sauvegardes sont des archives zip dans le dossier local'), icon: 'hdd' }) + '</div>';
      const tabs = [['list', t('Sauvegardes')], ['plans', t('Planifications')]].concat(caps.can_manage || dests.length ? [['dests', t('Destinations')]] : []);
      const actions = bkTab === 'plans' ? '<button class="btn primary" id="add-plan">' + TP.icon('plus') + t('Nouvelle planification') + '</button>'
        : bkTab === 'dests' ? (caps.can_manage ? '<button class="btn primary" id="add-dest">' + TP.icon('plus') + t('Nouvelle destination') + '</button>' : '')
          : (isAdmin ? '<button class="btn" id="bk-options">' + TP.icon('settings') + t('Options') + '</button>' : '') + '<button class="btn primary" id="add">' + TP.icon('plus') + t('Nouvelle sauvegarde') + '</button>';
      root.innerHTML = TP.pageHead(t('Sauvegardes'), (r.data.dir ? t('Archives locales dans') + ' <code>' + TP.esc(r.data.dir) + '</code> · ' : '') + t('conservation') + ' : ' + r.data.keep + ' ' + t('par cible'), actions) +
        partialBanner + encBanner + tabsHtml(tabs, bkTab) + '<div data-pane="list"' + (bkTab === 'list' ? '' : ' style="display:none"') + '>' + listPane + '</div><div data-pane="plans"' + (bkTab === 'plans' ? '' : ' style="display:none"') + '>' + planPane + '</div>' +
        '<div data-pane="dests"' + (bkTab === 'dests' ? '' : ' style="display:none"') + '>' + destPane + '</div>';
      bindTabs(root, (tab) => { bkTab = tab; reload(); });
      TP.qsa('[data-filter] [data-f]', root).forEach((b) => b.onclick = () => { bkFilter = b.dataset.f; reload(); });
      const destOpts = [[0, t('Local (archive zip)')]].concat(dests.filter((x) => x.enabled !== false).map((x) => [x.id, x.name + ' · ' + t(x.kind_label || x.kind)]));
      const va = TP.qs('#verify-all', root); if (va) va.onclick = async () => { try { const rr = await TP.post('/api/backups/verify-recent'); TP.taskModal(rr.data.task_id, t('Vérification'), reload); } catch (e) { TP.toast(e.message, 'error'); } };
      const eo = TP.qs('#enc-open', root); if (eo) eo.onclick = () => openEncryption(null, ctx).catch((e) => TP.toast(e.message, 'error'));
      const bo = TP.qs('#bk-options', root); if (bo) bo.onclick = () => openOptions(opts, ctx);

      // ---- nouvelle sauvegarde ponctuelle
      const addBtn = TP.qs('#add', root);
      if (addBtn) addBtn.onclick = () => {
        const kinds = [['site', t('Site')], ['database', t('Base de données')], ['mailbox', t('Boîte mail')], ['mail_domain', t('Domaine mail')], ['account', t('Compte complet')]].concat(isAdmin ? [['server', t('Serveur entier')], ['path', t('Dossier / fichier')]] : []);
        TP.modal({ title: t('Nouvelle sauvegarde'), body: '<div class="form">' + TP.field('kind', t('Type'), { type: 'select', value: 'site', options: kinds }) +
          '<div data-k="site">' + TP.field('site', t('Site'), { type: 'select', options: ctx.sites.map((x) => [x.id, x.name]) }) + '</div>' +
          '<div data-k="database" style="display:none">' + TP.field('db', t('Base'), { type: 'select', options: ctx.databases.map((x) => [x.id, x.name + ' (' + x.engine + ')']) }) + '</div>' +
          '<div data-k="mailbox" style="display:none">' + TP.field('mailbox', t('Boîte mail'), { type: 'select', options: ctx.mailboxes.map((x) => [x.id, x.address]) }) + '</div>' +
          '<div data-k="mail_domain" style="display:none">' + TP.field('domain', t('Domaine mail'), { type: 'select', options: ctx.domains.map((x) => [x.id, x.domain]) }) + '</div>' +
          '<div data-k="account" style="display:none">' + (isAdmin || r.data.owners.length ? TP.field('account', t('Compte'), { type: 'select', options: (r.data.owners || []).map((o) => [o.id, o.name]) }) : '<p class="muted small">' + t('Sites, bases et messages de votre compte.') + '</p>') + '</div>' +
          '<div data-k="server" style="display:none">' + TP.field('profile', t('Profil'), { type: 'select', value: 'data', options: [['data', t('Sites et données (sites, mails, bases, réglages et base du panel)')], ['full', t('Serveur complet (configuration comprise)')]],
            hint: t('« Serveur complet » ajoute vhosts, pools PHP-FPM, certificats et clés privées, DKIM, mail, DNS, FTP, crontabs et règles de pare-feu ; il exige une archive chiffrée. Le système et les paquets ne sont pas inclus.') }) + '</div>' +
          '<div data-k="path" style="display:none">' + TP.field('path', t('Chemin'), { placeholder: '/var/www' }) + '</div>' +
          TP.field('destination_id', t('Destination'), { type: 'select', value: r.data.default_destination || 0, options: destOpts }) +
          '<div class="f2">' + TP.field('mode', t('Type de sauvegarde'), { type: 'select', value: 'full', options: [['full', t('Complète')], ['incremental', t('Incrémentale (fichiers modifiés seulement)')]], hint: t('Archives natives ; restic, Borg et rsync « tree » sont incrémentaux par nature.') }) +
          TP.field('encrypt', t('Chiffrement'), { type: 'select', value: '', options: [['', t('Selon la destination et les réglages')], ['1', t('Oui : chiffrer l\'archive')], ['0', t('Non')]] }) + '</div>' +
          '<div data-encwarn class="alert warn" style="display:none">' + TP.icon('alert') + '<div>' + t('Aucune phrase secrète n\'est définie : la sauvegarde sera refusée. Définissez-la d\'abord (bouton « Chiffrement »).') + '</div></div>' +
          (isAdmin ? TP.field('strict', t('Mode strict : un dump de base en échec annule la sauvegarde'), { type: 'checkbox', value: false }) : '') + '</div>',
          okText: t('Lancer'), onOpen: (bg) => {
            const sync = () => { TP.qsa('[data-k]', bg).forEach((p) => p.style.display = p.dataset.k === TP.qs('[name=kind]', bg).value ? '' : 'none'); TP.qs('[data-encwarn]', bg).style.display = TP.qs('[name=encrypt]', bg).value === '1' && !enc.configured ? '' : 'none'; };
            TP.qs('[name=kind]', bg).onchange = sync; TP.qs('[name=encrypt]', bg).onchange = sync;
          },
          onOk: async (bg) => {
            const f = TP.formData(bg);
            const target = { site: f.site, database: f.db, mailbox: f.mailbox, mail_domain: f.domain, account: f.account || '', server: '0', path: f.path }[f.kind];
            if (!target && !['account', 'server'].includes(f.kind)) throw new Error(t('Cible requise'));
            const body = { kind: f.kind, target: String(target || ''), destination_id: Number(f.destination_id) || 0, mode: f.mode || 'full', encrypt: f.encrypt === '' ? null : f.encrypt === '1', profile: f.kind === 'server' ? (f.profile || 'data') : 'data' };
            if (isAdmin && f.strict) body.strict = true;
            const rr = await TP.post('/api/backups', body);
            TP.taskModal(rr.data.task_id, t('Sauvegarde'), () => reload());
          } });
      };

      // ---- actions sur une sauvegarde
      TP.qsa('[data-a]', root).forEach((b) => b.onclick = async () => { const a = b.dataset.a, id = Number(b.dataset.id); const bk = r.data.backups.find((x) => x.id === id); try {
        if (a === 'del') {
          if (!(await TP.confirm(t('Supprimer'), t('Supprimer cette sauvegarde ?'), { danger: true }))) return;
          try { await TP.del('/api/backups/' + id); reload(); } catch (e) {
            // sauvegarde de base d'une chaîne incrémentale : proposer la suppression de toute la chaîne
            if (e.status === 400 && /incrémentale/.test(e.message)) { if (await TP.confirm(t('Supprimer la chaîne'), TP.esc(e.message) + '<br>' + t('Supprimer cette sauvegarde ET celles qui en dépendent ?'), { danger: true })) { await TP.del('/api/backups/' + id + '?chain=true'); reload(); } } else throw e;
          }
        }
        else if (a === 'verify') { const rr = await TP.post('/api/backups/' + id + '/verify'); TP.taskModal(rr.data.task_id, t('Vérification'), reload); }
        else if (a === 'browse') openBrowser(bk, ctx);
        else if (a === 'srv') openServerRestore(bk, ctx);
      } catch (e) { TP.toast(e.message, 'error'); } });

      // ---- planifications
      const planModal = (p) => TP.modal({ title: p ? t('Modifier') + ' · ' + p.name : t('Nouvelle planification'), size: 'lg', body: planForm(p, ctx), okText: p ? t('Enregistrer') : t('Créer'),
        onOpen: (bg) => { TP.cronEditor(TP.qs('[data-cron]', bg), p ? p.schedule : '0 3 * * *', { ownerId: p ? p.owner_id : undefined }); const sv = TP.qs('[name=server]', bg), pr = TP.qs('[data-srvprofile]', bg); if (sv && pr) sv.onchange = () => { pr.style.display = sv.checked ? '' : 'none'; }; },
        onOk: async (bg) => { const body = planCollect(bg); if (p) await TP.put('/api/backups/plans/' + p.id, body); else await TP.post('/api/backups/plans', body); TP.toast(p ? t('Planification mise à jour') : t('Planification créée')); bkTab = 'plans'; reload(); } });
      const ap = TP.qs('#add-plan', root); if (ap) ap.onclick = () => planModal(null);
      TP.qsa('[data-p]', root).forEach((b) => b.onclick = async () => { const p = pl.data.find((x) => x.id === Number(b.dataset.id)); try {
        if (b.dataset.p === 'run') { const rr = await TP.post('/api/backups/plans/' + p.id + '/run'); TP.taskModal(rr.data.task_id, p.name, reload); }
        else if (b.dataset.p === 'log') TP.modal({ title: t('Dernier compte rendu') + ' · ' + p.name, size: 'lg', body: preOut(p.last_message), footer: '<button class="btn" data-close>' + t('Fermer') + '</button>' });
        else if (b.dataset.p === 'edit') planModal(p);
        else if (b.dataset.p === 'del') { const bg = await TP.confirm(t('Supprimer'), t('Supprimer la planification {n} ?', { n: '<b>' + TP.esc(p.name) + '</b>' }), { danger: true, extra: TP.field('wipe', t('Supprimer aussi ses sauvegardes'), { type: 'checkbox' }) }); if (bg) { await TP.del('/api/backups/plans/' + p.id + '?delete_backups=' + (TP.qs('[name=wipe]', bg).checked ? 'true' : 'false')); reload(); } }
      } catch (e) { TP.toast(e.message, 'error'); } });

      // ---- destinations
      const destModal = (x) => TP.modal({ title: x ? t('Modifier') + ' · ' + x.name : t('Nouvelle destination'), size: 'lg', body: destForm(x, caps), okText: x ? t('Enregistrer') : t('Créer'), onOpen: (bg) => bindDestForm(bg, caps),
        onOk: async (bg) => { const body = destCollect(bg); const rr = x ? await TP.put('/api/backups/destinations/' + x.id, body) : await TP.post('/api/backups/destinations', body); TP.toast(rr.msg); bkTab = 'dests'; reload(); showRepoKey(rr.data); } });
      const ad = TP.qs('#add-dest', root); if (ad) ad.onclick = () => destModal(null);
      TP.qsa('[data-d]', root).forEach((b) => b.onclick = async () => { const x = dests.find((y) => y.id === Number(b.dataset.id)); try {
        if (b.dataset.d === 'test') { b.disabled = true; const rr = await TP.post('/api/backups/destinations/' + x.id + '/test'); TP.toast(rr.data.message, rr.data.ok ? '' : 'error'); reload(); }
        else if (b.dataset.d === 'key') { const rr = await TP.get('/api/backups/destinations/' + x.id + '/key'); showRepoKey({ repository_key: rr.data.key, engine: x.engine }); }
        else if (b.dataset.d === 'edit') destModal(x);
        else if (b.dataset.d === 'del') { if (await TP.confirm(t('Supprimer'), t('Retirer la destination {n} du panel ? Le dépôt distant et sa clé sont conservés.', { n: '<b>' + TP.esc(x.name) + '</b>' }), { danger: true })) { await TP.del('/api/backups/destinations/' + x.id); reload(); } }
      } catch (e) { TP.toast(e.message, 'error'); b.disabled = false; } });
    },
  });

  // ---------------------------------------------------------------- Cron
  function openRuns(j) {
    TP.modal({ title: t('Historique') + ' · ' + j.name, size: 'lg', body: '<div data-runs>' + TP.loading() + '</div><div data-out class="mt"></div>', footer: '<button class="btn" data-close>' + t('Fermer') + '</button>',
      onOpen: async (bg) => {
        try {
          const r = await TP.get('/api/cron/' + j.id + '/runs?limit=100');
          const runs = r.data.runs;
          TP.qs('[data-runs]', bg).innerHTML = '<p class="small muted">' + t('Utilisateur d\'exécution : {u} · {k} dernières exécutions conservées', { u: '<code>' + TP.esc(r.data.job.run_as || '—') + '</code>', k: r.data.keep }) + '</p>' + TP.table([
            { label: t('Date'), render: (x) => TP.fmtDate(x.started_at) },
            { label: t('Durée'), cls: 'small', render: (x) => x.duration_ms < 1000 ? x.duration_ms + ' ms' : (x.duration_ms / 1000).toFixed(1) + ' s' },
            { label: t('Statut'), render: (x) => (x.status === 'ok' ? TP.badge('OK', 'ok') : TP.badge(t('Erreur'), 'danger')) + (x.exit_code !== null && x.exit_code !== undefined ? ' <span class="small muted mono">' + x.exit_code + '</span>' : '') },
            { label: t('Déclenchement'), cls: 'small muted', render: (x) => x.trigger === 'manual' ? t('manuel') : t('planifié') },
            { label: t('Utilisateur'), cls: 'small mono', render: (x) => TP.esc(x.run_as || '—') },
            { label: '', cls: 'r', render: (x) => '<button class="btn xs" data-run="' + x.id + '">' + TP.icon('logs') + '</button>' },
          ], runs, { empty: t('(aucune exécution)'), icon: 'clock' });
          TP.qsa('[data-run]', bg).forEach((b) => b.onclick = async () => { const rr = await TP.get('/api/cron/' + j.id + '/runs/' + b.dataset.run); TP.qs('[data-out]', bg).innerHTML = preOut(rr.data.output || t('(sortie vide)')); });
        } catch (e) { TP.qs('[data-runs]', bg).innerHTML = TP.esc(e.message); }
      } });
  }

  TP.registerPage('cron', {
    async render(root) {
      const reload = () => this.render(root);
      const [r, s, d] = await Promise.all([TP.get('/api/cron'), TP.get('/api/sites'), TP.get('/api/databases')]);
      const isAdmin = !!((TP.user || {}).is_admin || (TP.user || {}).role === 'admin');
      let be = null; if (isAdmin) { try { be = (await TP.get('/api/cron/backend')).data; } catch (e) { be = null; } }
      const beLabel = { internal: t('Interne au panel'), systemd: t('Minuteurs systemd'), crontab: t('cron système') };
      const typeLabel = { shell: t('Commande'), url: 'URL', backup_site: t('Sauvegarde site'), backup_db: t('Sauvegarde base'), backup_path: t('Sauvegarde dossier') };
      const notifyLabel = { never: t('Jamais'), error: t('En cas d\'erreur'), always: t('Toujours') };
      const targetLabel = (j) => j.job_type === 'backup_site' ? (s.data.sites.find((x) => x.id === Number(j.target)) || {}).name || j.target : j.job_type === 'backup_db' ? (d.data.databases.find((x) => x.id === Number(j.target)) || {}).name || j.target : j.target;
      root.innerHTML = TP.pageHead(t('Tâches planifiées'), t('Les commandes des comptes clients s\'exécutent sous leur utilisateur système (ou celui du site), jamais en root.'), '<button class="btn primary" id="add">' + TP.icon('plus') + t('Nouvelle tâche') + '</button>') +
        (be ? '<div class="card mb"><div class="card-b row between"><div><b>' + t('Planificateur') + '</b> : ' + TP.badge(beLabel[be.effective] || be.effective, be.effective === 'internal' ? '' : 'ok') + (be.reason ? ' <span class="small muted">' + TP.esc(t('Repli sur le planificateur interne')) + ' : ' + TP.esc(be.reason) + '</span>' : '') + '<div class="small muted">' + t('Interne : les tâches s\'arrêtent avec le panel. Minuteurs systemd / cron système : elles tournent même panel arrêté (rattrapage au redémarrage avec systemd).') + '</div></div><div class="row" style="flex-wrap:nowrap;align-items:center;gap:8px"><select class="input" id="cron-be" style="min-width:12rem" aria-label="' + TP.esc(t('Planificateur')) + '">' + Object.entries(beLabel).map(([k, v]) => '<option value="' + k + '"' + (k === be.setting ? ' selected' : '') + '>' + TP.esc(v) + '</option>').join('') + '</select><button class="btn" id="cron-sync">' + t('Synchroniser') + '</button></div></div></div>' : '') +
        '<div class="card">' + TP.table([
          { label: t('Tâche'), render: (j) => '<b>' + TP.esc(j.name) + '</b>' + (j.owner ? ' <span class="small muted">· ' + TP.esc(j.owner) + '</span>' : '') + '<div class="small muted mono">' + TP.esc(targetLabel(j)).slice(0, 80) + '</div>' },
          { label: t('Type'), render: (j) => TP.badge(typeLabel[j.job_type] || j.job_type, 'info') + (j.job_type === 'shell' && j.run_as ? '<div class="small muted mono">' + TP.icon('user') + ' ' + TP.esc(j.run_as) + (j.run_user === 'site' ? ' · ' + t('site') : '') + '</div>' : '') + (j.backend && j.backend !== 'internal' ? ' ' + TP.badge(beLabel[j.backend] || j.backend, '') : '') },
          { label: t('Planning'), cls: 'mono', render: (j) => TP.esc(j.schedule) + (j.notify && j.notify !== 'never' ? ' <span title="' + TP.esc(t('Notification') + ' : ' + notifyLabel[j.notify]) + '">' + TP.icon('bell') + '</span>' : '') },
          { label: t('Prochaine'), cls: 'muted', render: (j) => j.enabled ? TP.fmtDate(j.next_run) : '—' },
          { label: t('Dernière'), render: (j) => j.last_run ? '<span class="muted">' + TP.fmtDate(j.last_run) + '</span> ' + (j.last_status === 'ok' ? TP.badge('OK', 'ok') : TP.badge(t('Erreur'), 'danger')) + (j.last_duration_ms ? ' <span class="small muted">' + (j.last_duration_ms < 1000 ? j.last_duration_ms + ' ms' : (j.last_duration_ms / 1000).toFixed(1) + ' s') + '</span>' : '') : '<span class="muted">—</span>' },
          { label: '', cls: 'r', render: (j) => '<div class="actions"><button class="btn xs" data-a="run" data-id="' + j.id + '" title="' + t('Exécuter') + '">' + TP.icon('play') + '</button><button class="btn xs" data-a="log" data-id="' + j.id + '" title="' + t('Historique') + '">' + TP.icon('logs') + '</button><button class="btn xs" data-a="edit" data-id="' + j.id + '">' + TP.icon('edit') + '</button><button class="btn xs danger" data-a="del" data-id="' + j.id + '">' + TP.icon('trash') + '</button></div>' },
        ], r.data, { empty: t('Aucune tâche planifiée'), icon: 'clock', cta: { label: t('Nouvelle tâche'), target: '#add' } }) + '</div>';
      const form = (j) => { j = j || {}; return '<div class="form">' + TP.field('name', t('Nom'), { value: j.name }) +
        TP.field('job_type', t('Type'), { type: 'select', value: j.job_type || 'shell', options: Object.entries(typeLabel) }) +
        '<div data-cron></div>' +
        '<div data-t="shell url backup_path">' + TP.field('target', t('Commande / URL / chemin'), { type: 'textarea', value: j.target && !j.job_type?.startsWith('backup_') || j.job_type === 'backup_path' ? j.target : '', rows: 3 }) + '</div>' +
        '<div data-t="backup_site" style="display:none">' + TP.field('site', t('Site'), { type: 'select', value: j.job_type === 'backup_site' ? j.target : '', options: s.data.sites.map((x) => [x.id, x.name]) }) + '</div>' +
        '<div data-t="backup_db" style="display:none">' + TP.field('db', t('Base'), { type: 'select', value: j.job_type === 'backup_db' ? j.target : '', options: d.data.databases.map((x) => [x.id, x.name]) }) + '</div>' +
        '<div data-t="shell">' + '<div class="f2">' + TP.field('run_user', t('Exécuter sous'), { type: 'select', value: j.run_user || '', options: [['', isAdmin ? t('Utilisateur par défaut (réglage)') : t('Mon compte')], ['site', t('Utilisateur du site (dossier de travail : sa racine)')]].concat(isAdmin ? [['root', t('root (administrateur, avec confirmation)')]] : []) }) + TP.field('site_id', t('Site'), { type: 'select', value: j.site_id || '', options: [['', '—']].concat(s.data.sites.filter((x) => !isAdmin || (x.owner_id || 0) === (j.owner_id || 0)).map((x) => [x.id, x.name])), hint: t('Obligatoire pour « Utilisateur du site ».') }) + '</div>' +
          (isAdmin ? '<div data-root style="display:none" class="alert warn">' + TP.icon('alert') + '<div><div>' + t('La commande aura tous les droits sur le serveur. Cette configuration et chaque exécution sont inscrites dans le journal d\'audit.') + '</div><div class="mt"><label class="check"><input type="checkbox" name="confirm_root"> <span>' + t('Je confirme l\'exécution en root') + '</span></label></div></div></div>' : '') + '</div>' +
        '<div class="f2">' + TP.field('notify', t('Notification de fin d\'exécution'), { type: 'select', value: j.notify || 'never', options: Object.entries(notifyLabel) }) + TP.field('notify_email', t('E-mail du destinataire (optionnel)'), { type: 'email', value: j.notify_email || '', placeholder: 'ops@example.com' }) + '</div>' +
        TP.field('enabled', t('Activée'), { type: 'checkbox', value: j.enabled !== false }) + '</div>'; };
      const wire = (bg, j) => { const sel = TP.qs('[name=job_type]', bg); const ru = TP.qs('[name=run_user]', bg); const upd = () => { TP.qsa('[data-t]', bg).forEach((p) => p.style.display = p.dataset.t.split(' ').includes(sel.value) ? '' : 'none'); const rt = TP.qs('[data-root]', bg); if (rt) rt.style.display = (ru && ru.value === 'root' && sel.value === 'shell') ? '' : 'none'; }; sel.onchange = upd; if (ru) ru.onchange = upd; upd(); TP.cronEditor(TP.qs('[data-cron]', bg), (j && j.schedule) || '0 3 * * *', { ownerId: j && j.owner_id }); };
      const collect = (bg) => { const f = TP.formData(bg); const target = f.job_type === 'backup_site' ? f.site : f.job_type === 'backup_db' ? f.db : f.target; const out = { name: f.name, schedule: f.schedule, job_type: f.job_type, target: String(target || ''), enabled: f.enabled, notify: f.notify, notify_email: f.notify_email || '' }; if (f.job_type === 'shell') { out.run_user = f.run_user || ''; out.site_id = f.site_id ? Number(f.site_id) : null; if (out.run_user === 'root') out.confirm_root = !!f.confirm_root; } return out; };
      const beSel = TP.qs('#cron-be', root); if (beSel) beSel.onchange = async () => { try { const rr = await TP.post('/api/settings', { cron_backend: beSel.value }); TP.toast(rr.msg); reload(); } catch (e) { TP.toast(e.message, 'error'); reload(); } };
      const beSync = TP.qs('#cron-sync', root); if (beSync) beSync.onclick = async () => { try { const rr = await TP.post('/api/cron/backend/sync'); TP.toast(rr.msg); reload(); } catch (e) { TP.toast(e.message, 'error'); } };
      TP.qs('#add', root).onclick = () => TP.modal({ title: t('Nouvelle tâche'), size: 'lg', body: form(), okText: t('Créer'), onOpen: (bg) => wire(bg, null), onOk: async (bg) => { await TP.post('/api/cron', collect(bg)); TP.toast(t('Tâche créée')); reload(); } });
      TP.qsa('[data-a]', root).forEach((b) => b.onclick = async () => { const j = r.data.find((x) => x.id === Number(b.dataset.id)); const a = b.dataset.a; try {
        if (a === 'run') { await TP.post('/api/cron/' + j.id + '/run'); TP.toast(t('Exécution lancée')); setTimeout(reload, 2500); }
        else if (a === 'log') openRuns(j);
        else if (a === 'edit') TP.modal({ title: t('Modifier') + ' · ' + j.name, size: 'lg', body: form(j), okText: t('Enregistrer'), onOpen: (bg) => wire(bg, j), onOk: async (bg) => { await TP.put('/api/cron/' + j.id, collect(bg)); TP.toast(t('Tâche mise à jour')); reload(); } });
        else if (a === 'del') { if (await TP.confirm(t('Supprimer'), t('Supprimer la tâche {n} ?', { n: '<b>' + TP.esc(j.name) + '</b>' }), { danger: true })) { await TP.del('/api/cron/' + j.id); reload(); } }
      } catch (e) { TP.toast(e.message, 'error'); } });
    },
  });
})();
