/* ToutPanel — cadre des assistants de configuration : TP.assist.
   Un assistant = une définition déclarative (étapes, champs, validation, préréglages) + un pendant serveur (services/assist/<id>.py,
   routes /api/assist/<id>/check|apply|test|fix). Ce fichier fournit :
   - le moteur d'étapes (pur, sans DOM : TP.assist.engine, testé par node) ;
   - la fenêtre flottante (TP.modal), l'indicateur de progression, la validation en direct, le récapitulatif avant application ;
   - le chargement animé pendant que la tâche de fond travaille (anneau + engrenage, étapes qui se cochent) ;
   - l'étape « Tester » (rapport ✓ / ⚠ / ✕, causes, corrections automatiques, aide) et l'écran « Et maintenant ? » ;
   - le lanceur : carte du tableau de bord, bouton « Assistant » des pages, menu rapide « + », palette Ctrl+K, états vides.
   Mode d'emploi pour développeurs : docs/ASSISTANTS-DEV.md. */
(function () {
  'use strict';
  const W = typeof window !== 'undefined' ? window : globalThis;
  const TP = W.TP = W.TP || {};
  const t = (k, v) => (TP.t ? TP.t(k, v) : String(k).replace(/\{(\w+)\}/g, (m, n) => (v && v[n] !== undefined ? v[n] : m)));
  const esc = (s) => (TP.esc ? TP.esc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
  const icon = (n, c) => (TP.icon ? TP.icon(n, c) : '');
  // textes fournis par le serveur (libellés d'étapes, causes, remèdes) : écrits en français, ils servent de clé de traduction comme les t('…') ; inconnus = inchangés
  const ts = (s) => (s && typeof s === 'string' && TP.t ? TP.t(s) : s);
  // idem pour un texte à variables (serveur : T("… {x}", x=…) → { t, v }) : le modèle français est la clé de traduction
  const tv = (text, tpl) => (tpl && tpl.t ? t(tpl.t, tpl.v) : ts(text));

  // ============================================================ moteur pur (sans DOM)
  const V = {};  // validateurs réutilisables : retournent '' (valide) ou un message en langage simple
  V.domain = (v) => (/^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}$/i.test(String(v || '').trim().replace(/^www\./i, '')) ? '' : t('Nom de domaine invalide : écrivez-le comme exemple.fr (sans http:// ni espaces).'));
  V.email = (v) => (/^[^@\s]{1,64}@[^@\s]{1,190}\.[a-z]{2,}$/i.test(String(v || '').trim()) ? '' : t('Adresse e-mail invalide (ex. nom@exemple.fr).'));
  V.identifier = (max, what) => (v) => (new RegExp('^[a-zA-Z][a-zA-Z0-9_]{0,' + ((max || 32) - 1) + '}$').test(String(v || '')) ? '' : t('{what} : lettres, chiffres et _ uniquement, commence par une lettre ({n} caractères maximum).', { what: what || t('Nom'), n: max || 32 }));
  V.ipv4 = (v) => { const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(\/(\d{1,2}))?$/.exec(String(v || '').trim()); return m && [1, 2, 3, 4].every((i) => Number(m[i]) <= 255) && (!m[6] || Number(m[6]) <= 32); };
  V.ipv6 = (v) => /^[0-9a-f:]+(\/\d{1,3})?$/i.test(String(v || '').trim()) && String(v).includes(':');
  V.ip = (v) => (V.ipv4(v) || V.ipv6(v) ? '' : t('Adresse IP invalide (ex. 203.0.113.7 ou 203.0.113.0/24).'));
  V.ipList = (v) => { const items = String(v || '').split(/[\s,;]+/).filter(Boolean); if (!items.length) return ''; const bad = items.find((x) => V.ip(x)); return bad ? t('« {x} » n\'est pas une adresse IP valide (séparez-les par des virgules).', { x: bad }) : ''; };
  V.port = (v) => (/^\d+$/.test(String(v)) && Number(v) >= 1 && Number(v) <= 65535 ? '' : t('Port invalide (entre 1 et 65535).'));
  V.strongPassword = (v) => { v = String(v || ''); if (v.length < 10) return t('Au moins 10 caractères.'); const k = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter((r) => r.test(v)).length; return k >= 3 ? '' : t('Mélangez majuscules, minuscules, chiffres et symboles.'); };

  const E = {};  // moteur
  E.V = V;
  E.isVisible = (item, data, ctx, mode) => !(item.advanced && mode !== 'advanced') && (typeof item.show !== 'function' || !!item.show(data, ctx));
  E.visibleSteps = (def, data, ctx, mode) => (def.steps || []).filter((s) => E.isVisible(s, data, ctx, mode));
  E.visibleFields = (step, data, ctx, mode) => (step.fields || []).filter((f) => E.isVisible(f, data, ctx, mode));
  E.isEmpty = (f, v) => (f.type === 'checkbox' ? !v : Array.isArray(v) ? v.length === 0 : v === undefined || v === null || String(v).trim() === '');
  // retourne '' ou le message d'erreur du champ
  E.validateField = (f, value, data, ctx) => {
    if (f.type === 'info' || f.type === 'html') return '';
    if (E.isEmpty(f, value)) return (typeof f.required === 'function' ? f.required(data, ctx) : f.required) ? (f.requiredMsg || t('Ce champ est obligatoire.')) : '';
    if (f.type === 'checkbox') return '';
    if (Array.isArray(value)) return typeof f.validate === 'function' ? (f.validate(value, data, ctx) || '') : '';
    const s = String(value).trim();
    if (f.type === 'email') { const m = V.email(s); if (m) return m; }
    if (f.type === 'number') {
      if (!/^-?\d+(\.\d+)?$/.test(s)) return t('Saisissez un nombre.');
      if (f.min !== undefined && Number(s) < f.min) return t('La valeur minimale est {n}.', { n: f.min });
      if (f.max !== undefined && Number(s) > f.max) return t('La valeur maximale est {n}.', { n: f.max });
    }
    if (f.minLength && s.length < f.minLength) return t('Au moins {n} caractères.', { n: f.minLength });
    if (f.maxLength && s.length > f.maxLength) return t('{n} caractères au maximum.', { n: f.maxLength });
    if (f.pattern && !new RegExp(f.pattern).test(s)) return f.patternMsg || t('Format invalide.');
    if (f.options && f.type === 'select' && Array.isArray(f.options) && f.strict && !f.options.some((o) => String(Array.isArray(o) ? o[0] : o.value) === s)) return t('Choisissez une valeur de la liste.');
    if (typeof f.validate === 'function') return f.validate(f.trim === false ? value : s, data, ctx) || '';
    return '';
  };
  // erreurs de toutes les zones visibles d'une étape : { champ: message }
  E.validateStep = (step, data, ctx, mode) => {
    const errs = {};
    E.visibleFields(step, data, ctx, mode).forEach((f) => { const m = E.validateField(f, data[f.name], data, ctx); if (m) errs[f.name] = m; });
    if (typeof step.validate === 'function') { const m = step.validate(data, ctx); if (m) errs._step = m; }
    return errs;
  };
  // première étape (index dans visibleSteps) qui contient une erreur ; -1 si tout est valide
  E.firstInvalid = (def, data, ctx, mode) => { const steps = E.visibleSteps(def, data, ctx, mode); for (let i = 0; i < steps.length; i++) if (Object.keys(E.validateStep(steps[i], data, ctx, mode)).length) return i; return -1; };
  E.stepOfField = (def, name, data, ctx, mode) => E.visibleSteps(def, data, ctx, mode).findIndex((s) => (s.fields || []).some((f) => f.name === name));
  E.defaults = (def, ctx) => {
    const d = {};
    (def.steps || []).forEach((s) => (s.fields || []).forEach((f) => { if (f.name && f.default !== undefined) d[f.name] = typeof f.default === 'function' ? f.default(ctx) : f.default; }));
    return Object.assign(d, typeof def.defaults === 'function' ? def.defaults(ctx) : (def.defaults || {}));
  };
  // données à envoyer : sans clés privées (_x), champs masqués et fonctions
  E.payload = (def, data, ctx, mode) => {
    const out = {}; const names = new Set();
    E.visibleSteps(def, data, ctx, mode).forEach((s) => E.visibleFields(s, data, ctx, mode).forEach((f) => { if (f.name) names.add(f.name); }));
    Object.keys(data).forEach((k) => {
      if (k[0] === '_' || typeof data[k] === 'function') return;
      if (!names.has(k) && !(def.keep || []).includes(k) && (def.steps || []).some((s) => (s.fields || []).some((f) => f.name === k))) return;  // champ masqué
      out[k] = data[k];
    });
    return out;
  };
  E.preset = (def, id, ctx) => {
    const list = def.presets || [];
    const p = id ? list.find((x) => x.id === id) : (list.find((x) => x.recommended) || list[0]);
    if (!p) return null;
    return typeof p.values === 'function' ? p.values(ctx) : (p.values || {});
  };
  // progression d'une exécution (0..1) et secondes restantes estimées
  E.progress = (run, now) => {
    const steps = (run && run.steps) || [];
    if (!steps.length) return { fraction: 0, remaining: null };
    const fin = steps.filter((s) => ['ok', 'warn', 'skipped'].includes(s.status)).length;
    const running = steps.some((s) => s.status === 'running') ? 0.4 : 0;
    const fraction = run.status === 'done' ? 1 : Math.min(0.97, (fin + running) / steps.length);
    const elapsed = Math.max(0, ((now || Date.now() / 1000) - (run.started || 0)));
    const eta = run.eta || 0;
    let remaining = null;
    if (eta) remaining = fraction > 0.05 && elapsed > 3 ? Math.max(0, Math.round(elapsed * (1 - fraction) / fraction)) : Math.max(0, Math.round(eta - elapsed));
    return { fraction, remaining, elapsed: Math.round(elapsed) };
  };
  E.genPassword = (len) => {
    len = len || 16;
    const sets = ['abcdefghijkmnopqrstuvwxyz', 'ABCDEFGHJKLMNPQRSTUVWXYZ', '23456789', '#%+-_=@!?'];  // sans caractères ambigus (0 O 1 l I)
    const all = sets.join('');
    const rnd = (n) => { const a = new Uint32Array(1); (W.crypto || {}).getRandomValues ? W.crypto.getRandomValues(a) : (a[0] = Math.floor(Math.random() * 4294967296)); return a[0] % n; };
    const out = sets.map((s) => s[rnd(s.length)]);
    while (out.length < len) out.push(all[rnd(all.length)]);
    for (let i = out.length - 1; i > 0; i--) { const j = rnd(i + 1); const x = out[i]; out[i] = out[j]; out[j] = x; }
    return out.join('');
  };
  E.strength = (pw) => { pw = String(pw || ''); let s = 0; if (pw.length >= 8) s++; if (pw.length >= 12) s++; if ([/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter((r) => r.test(pw)).length >= 3) s++; if (pw.length >= 16) s++; return Math.min(4, s); };
  E.slug = (s) => String(s || '').toLowerCase().replace(/^www\./, '').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  E.clone = (o) => JSON.parse(JSON.stringify(o || {}));

  // ============================================================ registre
  const REG = {};
  const drafts = {};      // brouillons en mémoire de session (jamais écrits sur disque ni envoyés)
  const A = TP.assist = { engine: E, v: V, drafts, defs: REG };
  A.register = (def) => {
    if (!def || !def.id) throw new Error('assistant sans id');
    if (!Array.isArray(def.steps)) def.steps = [];
    def.pages = def.pages || [];
    def.group = def.group || 'site';
    REG[def.id] = def;
    return def;
  };
  A.get = (id) => REG[id];
  const can = (def) => !def.perm || (TP.can ? TP.can(def.perm[0], def.perm[1]) : true);
  A.list = () => Object.keys(REG).map((k) => REG[k]).filter(can);
  A.forPage = (route) => A.list().filter((d) => d.pages.includes(route));
  A.groupLabel = (g) => ({ site: t('Sites web'), data: t('Données'), access: t('Accès et comptes'), mail: t('Messagerie'), backup: t('Sauvegardes et tâches'), security: t('Sécurité') }[g] || g);

  let srvCache = null;
  A.server = (force) => {  // liste des assistants côté serveur (disponibilité, verrou d'édition) ; mise en cache 60 s
    if (!force && srvCache && Date.now() - srvCache.t < 60000) return srvCache.p;
    const p = TP.get('/api/assist').then((r) => r.data.assistants || []).catch(() => []);
    srvCache = { t: Date.now(), p };
    return p;
  };

  // ============================================================ animation de chargement
  function gearPath(cx, cy, rOut, rIn, n) {
    const pts = [];
    for (let i = 0; i < n; i++) {
      const c = (2 * Math.PI * i) / n, a = Math.PI / n;
      [[c - a * 0.62, rIn], [c - a * 0.34, rOut], [c + a * 0.34, rOut], [c + a * 0.62, rIn]].forEach(([ang, r]) => pts.push((cx + r * Math.cos(ang)).toFixed(1) + ' ' + (cy + r * Math.sin(ang)).toFixed(1)));
    }
    return 'M' + pts.join('L') + 'Z';
  }
  A.spinnerSvg = (size) => '<svg class="as-gear" viewBox="0 0 120 120" width="' + (size || 112) + '" height="' + (size || 112) + '" aria-hidden="true" focusable="false">' +
    '<circle class="as-ring-track" cx="60" cy="60" r="52"/>' +
    '<circle class="as-ring-arc" cx="60" cy="60" r="52" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>' +
    '<circle class="as-ring-spin" cx="60" cy="60" r="52" pathLength="100" stroke-dasharray="18 82"/>' +
    '<g class="as-cog"><path fill-rule="evenodd" d="' + gearPath(60, 60, 27, 21, 8) + 'M60 48a12 12 0 1 0 0.01 0Z"/></g></svg>';
  const stepIcon = (s) => '<span class="as-sic" aria-hidden="true">' +
    ({ ok: '<svg viewBox="0 0 24 24"><circle class="as-sic-bg" cx="12" cy="12" r="10"/><path class="as-tick" d="m7.5 12.5 3 3 6-6.5" pathLength="20"/></svg>',
      warn: '<svg viewBox="0 0 24 24"><circle class="as-sic-bg" cx="12" cy="12" r="10"/><path class="as-tick" d="M12 7v6M12 16.5v.5" pathLength="20"/></svg>',
      error: '<svg viewBox="0 0 24 24"><circle class="as-sic-bg" cx="12" cy="12" r="10"/><path class="as-tick" d="m8.5 8.5 7 7M15.5 8.5l-7 7" pathLength="20"/></svg>',
      skipped: '<svg viewBox="0 0 24 24"><circle class="as-sic-bg" cx="12" cy="12" r="10"/><path class="as-tick" d="M8 12h8" pathLength="20"/></svg>',
      running: '<span class="as-mini-spin"></span>', pending: '<svg viewBox="0 0 24 24"><circle class="as-sic-ring" cx="12" cy="12" r="9"/></svg>' }[s] || '') + '</span>';
  const STATE_TXT = () => ({ ok: t('terminé'), warn: t('attention'), error: t('échec'), skipped: t('ignoré'), running: t('en cours'), pending: t('en attente') });

  // liste d'étapes avec mise à jour incrémentale (les coches ne se rejouent pas à chaque interrogation)
  function stepList(host, items) {
    host.innerHTML = '';
    host.classList.add('as-steps');
    const els = {};
    items.forEach((s) => {
      const li = document.createElement('li');
      li.dataset.key = s.key;
      li.innerHTML = '<span class="as-sic-wrap"></span><div class="as-sb"><b></b><small></small></div>';
      TP.qs('b', li).textContent = ts(s.label);
      host.appendChild(li); els[s.key] = li;
    });
    const api = {
      set(key, status, detail) {
        const li = els[key]; if (!li) return;
        const prev = li.dataset.state;
        if (prev !== status) {
          li.dataset.state = status; li.className = 'as-' + status;
          TP.qs('.as-sic-wrap', li).innerHTML = stepIcon(status) + '<span class="sr-only">' + esc(STATE_TXT()[status] || status) + '</span>';
        }
        const sm = TP.qs('small', li);
        const dt = ts(detail || ''); if (sm.textContent !== dt) sm.textContent = dt;
      },
      update(steps) { (steps || []).forEach((s) => api.set(s.key, s.status, s.detail)); },
    };
    items.forEach((s) => api.set(s.key, s.status || 'pending', s.detail || ''));
    return api;
  }
  A.stepList = stepList;

  // ============================================================ erreurs du serveur
  const errBlock = (e) => {
    const d = (e && e.data) || {};
    return '<div class="alert danger as-err-block" role="alert">' + icon('alert') + '<div><b>' + esc(tv(d.msg, d.msg_t) || (e && e.message) || t('Une erreur est survenue')) + '</b>' +
      (d.cause ? '<div class="small mt-s"><b>' + t('Cause probable') + ' :</b> ' + esc(tv(d.cause, d.cause_t)) + '</div>' : '') +
      (d.fix ? '<div class="small mt-s"><b>' + t('Que faire') + ' :</b> ' + esc(tv(d.fix, d.fix_t)) + '</div>' : '') +
      (d.help ? '<div class="mt-s"><button type="button" class="btn xs" data-help="' + esc(d.help) + '">' + icon('help') + t('Voir l\'aide') + '</button></div>' : '') + '</div></div>';
  };

  // ============================================================ fenêtre de l'assistant
  const modeStore = { get() { try { return sessionStorage.getItem('tp-assist-mode') || 'simple'; } catch (e) { return 'simple'; } }, set(v) { try { sessionStorage.setItem('tp-assist-mode', v); } catch (e) { /* stockage indisponible */ } } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  A.open = async function (id, opts) {
    opts = opts || {};
    const def = REG[id];
    if (!def) { if (TP.toast) TP.toast(t('Assistant introuvable'), 'error'); return null; }
    if (!can(def)) { TP.toast(t('Votre compte n\'a pas le droit d\'utiliser cet assistant.'), 'error'); return null; }
    const ctx = { def, meta: {}, data: {}, mode: modeStore.get(), result: null, user: TP.user, opts, close: () => {}, reload: () => A.reloadPage() };
    const saved = !opts.fresh && drafts[id];
    const st = { stage: 'load', i: 0, errors: {}, touched: {}, check: null, run: null, tests: null, task: null, closed: false, busy: false, restored: false, polling: false };
    const size = def.size || 'lg';
    const m = TP.modal({ title: def.title, size: size + ' assist', sticky: true, body: '<div class="as-root" id="as-root"></div>', footer: '<div class="as-foot"></div>',
      onClose: () => { st.closed = true; if (st.task && st.stage === 'apply') watchInBackground(def, st, ctx); if (st.applied) { A.reloadPage(def); } if (opts.onClose) opts.onClose(ctx); } });
    ctx.close = m.close;
    const bg = m.el; bg.classList.add('assist-bg');
    const box = TP.qs('#as-root', bg), foot = TP.qs('.as-foot', bg), dlg = TP.qs('.modal', bg);
    box.setAttribute('aria-live', 'polite');  // les changements d'étape sont annoncés
    const live = document.createElement('div'); live.className = 'sr-only'; live.setAttribute('role', 'status'); live.setAttribute('aria-live', 'polite'); dlg.appendChild(live);
    const say = (msg) => { live.textContent = ''; setTimeout(() => { live.textContent = msg; }, 30); };
    foot.parentNode.classList.add('as-modal-f');

    const steps = () => E.visibleSteps(def, ctx.data, ctx, ctx.mode);
    const stages = () => steps().map((s) => ({ title: s.title })).concat([{ title: t('Récapitulatif') }, { title: t('Création') }, { title: t('Vérification') }]);
    const stageIndex = () => st.stage === 'form' ? st.i : st.stage === 'review' ? steps().length : st.stage === 'apply' ? steps().length + 1 : st.stage === 'done' ? steps().length + 3 : steps().length + 2;
    const saveDraft = () => { if (!st.applied) drafts[id] = { data: E.clone(ctx.data), i: st.i, mode: ctx.mode, auto: !!st.auto }; };

    // ---------- en-tête : progression + mode simple / avancé + lien vers la page complète
    function head() {
      const all = stages(), cur = stageIndex(), n = all.length;
      const adv = def.advanced !== false && (def.advancedRoute || def.pages[0]);
      const hasAdvFields = (def.steps || []).some((s) => s.advanced || (s.fields || []).some((f) => f.advanced));
      return '<div class="as-head"><div class="as-top"><div class="as-prog-txt" id="as-prog-txt">' + (st.stage === 'done' ? t('Terminé') : t('Étape {i} sur {n}', { i: Math.min(cur + 1, n), n }) + ' <span class="muted">· ' + esc(all[Math.min(cur, n - 1)].title) + '</span>') + '</div>' +
        '<div class="as-tools">' + (hasAdvFields && (st.stage === 'form' || st.stage === 'review') ? '<div class="as-seg" role="group" aria-label="' + esc(t('Niveau de détail')) + '"><button type="button" data-mode="simple" aria-pressed="' + (ctx.mode === 'simple') + '">' + t('Simple') + '</button><button type="button" data-mode="advanced" aria-pressed="' + (ctx.mode === 'advanced') + '">' + t('Avancé') + '</button></div>' : '') +
        (adv && st.stage !== 'apply' ? '<a class="as-adv" href="#/' + esc(adv) + '" data-as-adv>' + icon('settings') + t('Réglages avancés') + '</a>' : '') + '</div></div></div>' +
        '<ol class="as-dots" aria-label="' + esc(t('Étapes')) + '">' + all.map((s, i) => '<li class="' + (i === cur ? 'on' : i < cur ? 'done' : '') + '"' + (i === cur ? ' aria-current="step"' : '') + '><span class="as-dot" title="' + esc(s.title) + '">' + (i < cur ? icon('check') : (i + 1)) + '</span>' + (i === cur ? '<span class="as-dl">' + esc(s.title) + '</span>' : '<span class="sr-only">' + esc(s.title) + '</span>') + '</li>').join('') + '</ol>' +
        '<div class="as-bar" aria-hidden="true"><i style="width:' + Math.min(100, Math.round(((cur + 0.5) / n) * 100)) + '%"></i></div>';
    }
    // ---------- champs
    function fieldHtml(f) {
      const v = ctx.data[f.name], id = 'asf-' + f.name, err = st.errors[f.name] || '';
      const opts_ = typeof f.options === 'function' ? f.options(ctx.data, ctx) : (f.options || []);
      const hint = f.hint ? '<div class="hint" id="' + id + '-h">' + (f.hintHtml ? f.hint : esc(typeof f.hint === 'function' ? f.hint(ctx.data, ctx) : f.hint)) + '</div>' : '';
      const errEl = '<div class="as-ferr" id="' + id + '-e" aria-live="polite">' + (err ? icon('alert') + '<span>' + esc(err) + '</span>' : '') + '</div>';
      const desc = ' aria-describedby="' + (f.hint ? id + '-h ' : '') + id + '-e"';
      const inv = err ? ' aria-invalid="true"' : '';
      const req = (typeof f.required === 'function' ? f.required(ctx.data, ctx) : f.required) ? ' aria-required="true"' : '';
      const label = '<label for="' + id + '">' + esc(f.label) + ((typeof f.required === 'function' ? f.required(ctx.data, ctx) : f.required) ? ' <span class="as-req" aria-hidden="true">*</span>' : '') + (f.optional ? ' <span class="muted as-opt">(' + t('facultatif') + ')</span>' : '') + '</label>';
      let ctl = '';
      if (f.type === 'info') return '<div class="as-field as-info" data-field="' + esc(f.name || '') + '"><div class="alert ' + (f.tone || 'info') + '">' + icon(f.tone === 'warn' ? 'alert' : 'info') + '<div>' + (typeof f.html === 'function' ? f.html(ctx.data, ctx) : (f.html || esc(f.label))) + '</div></div></div>';
      if (f.type === 'html') return '<div class="as-field" data-field="' + esc(f.name || '') + '">' + (typeof f.render === 'function' ? f.render(ctx.data, ctx) : '') + '</div>';
      if (f.type === 'checkbox') {
        return '<div class="as-field as-check" data-field="' + esc(f.name) + '"><label class="as-switch"><input type="checkbox" id="' + id + '" name="' + esc(f.name) + '"' + (v ? ' checked' : '') + desc + '><span class="as-sw" aria-hidden="true"></span><span class="as-sl"><b>' + esc(f.label) + '</b>' + (f.hint ? '<small id="' + id + '-h">' + esc(typeof f.hint === 'function' ? f.hint(ctx.data, ctx) : f.hint) + '</small>' : '') + '</span></label>' + errEl + '</div>';
      }
      if (f.type === 'cards') {
        ctl = '<div class="as-cards" role="radiogroup" aria-labelledby="' + id + '-l"' + desc + '>' + opts_.map((o) => {
          const val = Array.isArray(o) ? o[0] : o.value, lab = Array.isArray(o) ? o[1] : o.label, dsc = Array.isArray(o) ? '' : (o.desc || ''), ic = Array.isArray(o) ? '' : (o.icon || '');
          const on = String(v) === String(val);
          return '<button type="button" class="as-card' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" tabindex="' + (on || (!opts_.some((x) => String(Array.isArray(x) ? x[0] : x.value) === String(v)) && val === (Array.isArray(opts_[0]) ? opts_[0][0] : opts_[0].value)) ? 0 : -1) + '" data-card="' + esc(f.name) + '" data-val="' + esc(val) + '">' +
            (ic ? '<span class="as-card-ic">' + icon(ic) + '</span>' : '') + '<span class="as-card-t"><b>' + esc(lab) + (o.tag ? ' <em class="as-tag">' + esc(o.tag) + '</em>' : '') + '</b>' + (dsc ? '<small>' + esc(dsc) + '</small>' : '') + '</span><span class="as-radio" aria-hidden="true"></span></button>';
        }).join('') + '</div>';
        return '<div class="as-field" data-field="' + esc(f.name) + '"><div class="as-lbl" id="' + id + '-l">' + esc(f.label) + ((typeof f.required === 'function' ? f.required(ctx.data, ctx) : f.required) ? ' <span class="as-req" aria-hidden="true">*</span>' : '') + '</div>' + hint + ctl + errEl + '</div>';
      }
      if (f.type === 'multi') {
        const cur = Array.isArray(v) ? v.map(String) : [];
        ctl = '<fieldset class="as-multi" aria-labelledby="' + id + '-l"' + desc + '>' + opts_.map((o) => { const val = Array.isArray(o) ? o[0] : o.value, lab = Array.isArray(o) ? o[1] : o.label; return '<label class="as-mchk"><input type="checkbox" data-multi="' + esc(f.name) + '" value="' + esc(val) + '"' + (cur.includes(String(val)) ? ' checked' : '') + '><span>' + esc(lab) + '</span></label>'; }).join('') + '</fieldset>';
        return '<div class="as-field" data-field="' + esc(f.name) + '"><div class="as-lbl" id="' + id + '-l">' + esc(f.label) + ((typeof f.required === 'function' ? f.required(ctx.data, ctx) : f.required) ? ' <span class="as-req" aria-hidden="true">*</span>' : '') + '</div>' + hint + ctl + errEl + '</div>';
      }
      if (f.type === 'select') {
        ctl = '<select class="input" id="' + id + '" name="' + esc(f.name) + '"' + desc + inv + req + '>' + opts_.map((o) => { const val = Array.isArray(o) ? o[0] : o.value, lab = Array.isArray(o) ? o[1] : o.label; return '<option value="' + esc(val) + '"' + (String(val) === String(v ?? '') ? ' selected' : '') + '>' + esc(lab) + '</option>'; }).join('') + '</select>';
      } else if (f.type === 'textarea') {
        ctl = '<textarea class="input" id="' + id + '" name="' + esc(f.name) + '" rows="' + (f.rows || 3) + '" placeholder="' + esc(f.placeholder || '') + '"' + desc + inv + req + '>' + esc(v ?? '') + '</textarea>';
      } else if (f.type === 'password') {
        ctl = '<div class="as-pw"><input class="input mono" id="' + id + '" name="' + esc(f.name) + '" type="text" autocomplete="new-password" spellcheck="false" value="' + esc(v ?? '') + '"' + desc + inv + req + (f.reveal === false ? '' : ' data-masked="1"') + '>' +
          '<button type="button" class="btn sm" data-eye="' + esc(f.name) + '" title="' + esc(t('Afficher / masquer')) + '" aria-label="' + esc(t('Afficher / masquer')) + '">' + icon('eye') + '</button>' +
          (f.generate !== false ? '<button type="button" class="btn sm" data-gen="' + esc(f.name) + '">' + icon('refresh') + t('Générer') + '</button>' : '') +
          '<button type="button" class="btn sm" data-copyf="' + esc(f.name) + '" title="' + esc(t('Copier')) + '" aria-label="' + esc(t('Copier')) + '">' + icon('copy') + '</button></div>' +
          '<div class="as-meter" aria-hidden="true" data-meter="' + esc(f.name) + '"><i></i><i></i><i></i><i></i></div>';
      } else {
        ctl = '<input class="input' + (f.mono ? ' mono' : '') + '" id="' + id + '" name="' + esc(f.name) + '" type="' + esc(f.type === 'number' ? 'text' : (f.type || 'text')) + '"' + (f.type === 'number' ? ' inputmode="decimal"' : '') + ' value="' + esc(v ?? '') + '" placeholder="' + esc(f.placeholder || '') + '" autocomplete="' + esc(f.autocomplete || 'off') + '" spellcheck="false"' + desc + inv + req + (f.suffix ? '' : '') + '>' + (f.suffix ? '<span class="as-suffix">' + esc(f.suffix) + '</span>' : '');
        if (f.suffix) ctl = '<div class="as-inwrap">' + ctl + '</div>';
      }
      return '<div class="as-field' + (err ? ' error' : '') + '" data-field="' + esc(f.name) + '">' + label + hint + ctl + errEl + '</div>';
    }
    const stepBody = (s) => '<h4 class="as-h" id="as-h" tabindex="-1">' + esc(s.title) + '</h4>' +
      (s.why ? '<p class="as-why">' + icon('info') + '<span><b>' + t('À quoi ça sert') + ' :</b> ' + esc(typeof s.why === 'function' ? s.why(ctx.data, ctx) : s.why) + '</span></p>' : '') +
      (typeof s.render === 'function' ? '<div class="as-custom">' + s.render(ctx.data, ctx) + '</div>' : '') +
      // tous les champs du mode courant sont rendus ; ceux dont `show` est faux sont masqués (hidden) puis révélés sur place : le focus ne saute jamais
      '<div class="as-fields">' + (s.fields || []).filter((f) => !(f.advanced && ctx.mode !== 'advanced')).map((f) => { const h = fieldHtml(f); return E.isVisible(f, ctx.data, ctx, ctx.mode) ? h : h.replace(/^<div /, '<div hidden '); }).join('') + '</div>';

    const presetBar = () => {
      if (st.i !== 0 || !(def.presets || []).length) return '';
      const rec = (def.presets || []).find((p) => p.recommended);
      const others = (def.presets || []).filter((p) => !p.recommended);
      return '<div class="as-presets">' + (rec ? '<button type="button" class="as-auto" data-preset="' + esc(rec.id) + '">' + icon('wand') + '<span><b>' + esc(rec.label || t('Je ne sais pas : choisir pour moi')) + '</b><small>' + esc(rec.desc || t('L\'assistant applique les réglages recommandés ; vous vérifiez avant que quoi que ce soit ne soit fait.')) + '</small></span>' + icon('chevron') + '</button>' : '') +
        (others.length ? '<div class="as-pre-list" role="group" aria-label="' + esc(t('Modèles prêts à l\'emploi')) + '">' + others.map((p) => '<button type="button" class="as-pre" data-preset="' + esc(p.id) + '">' + (p.icon ? icon(p.icon) : '') + '<span><b>' + esc(p.label) + '</b>' + (p.desc ? '<small>' + esc(p.desc) + '</small>' : '') + '</span></button>').join('') + '</div>' : '') + '</div>';
    };

    // ---------- pieds de fenêtre
    function setFoot(parts) {
      foot.innerHTML = parts.map((p) => p === 'spacer' ? '<span class="spacer"></span>' : '<button type="button" class="btn' + (p.cls ? ' ' + p.cls : '') + '" id="' + p.id + '"' + (p.disabled ? ' disabled' : '') + '>' + (p.icon ? icon(p.icon, p.flip ? 'flip' : '') : '') + esc(p.label) + '</button>').join('');
      parts.forEach((p) => { if (p !== 'spacer' && p.run) TP.qs('#' + p.id, foot).onclick = p.run; });
    }
    const hasPrev = () => st.stage === 'review' || (st.stage === 'form' && st.i > 0);

    // ---------- rendu des étapes
    function draw(focusSel) {
      const list = steps();
      if (st.stage === 'form') {
        if (st.i >= list.length) st.i = Math.max(0, list.length - 1);
        const s = list[st.i];
        box.innerHTML = head() + '<div class="as-pane" id="as-pane">' + (st.restored ? '<div class="alert info as-restored">' + icon('info') + '<div>' + t('Votre saisie précédente a été reprise.') + ' <button type="button" class="btn xs" data-fresh>' + t('Recommencer à zéro') + '</button></div></div>' : '') +
          (st.i === 0 && def.intro ? '<p class="as-intro">' + esc(def.intro) + '</p>' : '') + presetBar() + stepBody(s) + '</div>';
        st.restored = false;  // la bannière « saisie reprise » n'est montrée qu'une fois
        const last = st.i === list.length - 1;
        setFoot([{ id: 'as-cancel', label: t('Annuler'), run: () => m.close() }, 'spacer', ...(hasPrev() ? [{ id: 'as-prev', label: t('Retour'), icon: 'chevron', flip: true, run: prev }] : []),
          { id: 'as-next', label: last ? t('Voir le récapitulatif') : t('Suivant'), cls: 'primary', run: next }]);
        syncVisibility(); syncMeters();
      } else if (st.stage === 'review') {
        box.innerHTML = head() + '<div class="as-pane" id="as-pane"><h4 class="as-h" id="as-h" tabindex="-1">' + t('Voici ce qui va être fait') + '</h4>' + reviewBody() + '</div>';
        setFoot([{ id: 'as-cancel', label: t('Annuler'), run: () => m.close() }, 'spacer', { id: 'as-prev', label: t('Retour'), icon: 'chevron', flip: true, run: prev },
          { id: 'as-apply', label: def.applyLabel || t('Appliquer'), cls: 'primary', icon: 'check', disabled: !st.check, run: apply }]);
      } else if (st.stage === 'test') {
        box.innerHTML = head() + '<div class="as-pane" id="as-pane"><h4 class="as-h" id="as-h" tabindex="-1">' + t('Vérification de ce qui vient d\'être fait') + '</h4>' + testBody() + '</div>';
        setFoot([{ id: 'as-close', label: t('Fermer'), run: () => m.close() }, 'spacer', { id: 'as-retest', label: t('Relancer les vérifications'), icon: 'refresh', disabled: st.testing, run: () => runTests() },
          { id: 'as-cont', label: t('Continuer'), cls: 'primary', disabled: st.testing, run: () => { st.stage = 'done'; draw(); } }]);
      } else if (st.stage === 'done') {
        box.innerHTML = head() + '<div class="as-pane" id="as-pane">' + doneBody() + '</div>';
        if (def.done && typeof def.done.bind === 'function') def.done.bind(TP.qs('.as-result', box) || box, ctx.result || {}, ctx);
        setFoot([{ id: 'as-again', label: t('Recommencer'), icon: 'refresh', run: again }, 'spacer', { id: 'as-close', label: t('Terminer'), cls: 'primary', icon: 'check', run: () => m.close() }]);
      } else if (st.stage === 'failed') {
        box.innerHTML = head() + '<div class="as-pane" id="as-pane">' + failedBody() + '</div>';
        setFoot([{ id: 'as-close', label: t('Fermer'), run: () => m.close() }, 'spacer', { id: 'as-retry', label: t('Modifier et réessayer'), cls: 'primary', icon: 'refresh', run: () => { st.stage = 'review'; st.check = null; st.run = null; st.task = null; draw(); doCheck(); } }]);
      } else if (st.stage === 'load') {
        box.innerHTML = '<div class="as-loading" role="status">' + A.spinnerSvg(72) + '<p>' + t('Préparation de l\'assistant…') + '</p></div>';
        setFoot([{ id: 'as-cancel', label: t('Annuler'), run: () => m.close() }]);
      }
      TP.qsa('[data-as-adv]', box).forEach((a) => a.addEventListener('click', () => m.close()));
      const h = focusSel === false ? null : (focusSel ? TP.qs(focusSel, box) : TP.qs('#as-h', box));
      if (h) { const first = st.stage === 'form' && !focusSel ? TP.qs('.as-fields input:not([type=checkbox]), .as-fields select, .as-fields textarea, .as-card[tabindex="0"]', box) : null; (first || h).focus({ preventScroll: false }); }
      const hh = TP.qs('#as-h', box); if (hh) say(hh.textContent);
    }

    // ---------- visibilité conditionnelle, jauges, erreurs (sans re-rendre les champs : le focus ne saute pas)
    function syncVisibility() {
      const s = steps()[st.i]; if (!s) return;
      (s.fields || []).forEach((f) => {
        const el = TP.qs('[data-field="' + f.name + '"]', box);
        const vis = E.isVisible(f, ctx.data, ctx, ctx.mode);
        if (el) el.hidden = !vis;
      });
      (s.fields || []).filter((f) => f.type === 'html' || f.type === 'info' || typeof f.options === 'function' || typeof f.hint === 'function').forEach((f) => {
        const el = TP.qs('[data-field="' + f.name + '"]', box); if (!el || el.hidden || (f.type !== 'html' && f.type !== 'info' && !f.dependsOn)) return;
        if (f.type === 'html' || f.type === 'info') { const tmp = document.createElement('div'); tmp.innerHTML = fieldHtml(f); const n = tmp.firstChild; if (n && el.innerHTML !== n.innerHTML) el.innerHTML = n.innerHTML; }
      });
    }
    function rerenderField(name) {
      const s = steps()[st.i]; const f = s && (s.fields || []).find((x) => x.name === name); const el = TP.qs('[data-field="' + name + '"]', box);
      if (!f || !el) return;
      // champ texte dépendant d'un autre : mise à jour sur place (remplacer l'élément pendant un clic ou une tabulation ferait perdre le focus à l'utilisateur)
      const inp = el.querySelector('input.input:not([type=checkbox]):not([data-masked]), textarea.input');
      if (inp && typeof f.options !== 'function') {
        const val = ctx.data[name] === undefined || ctx.data[name] === null ? '' : String(ctx.data[name]);
        if (document.activeElement !== inp && inp.value !== val) inp.value = val;
        const h = TP.qs('.hint', el); if (h && typeof f.hint === 'function' && !f.hintHtml) h.textContent = f.hint(ctx.data, ctx);
        return;
      }
      const tmp = document.createElement('div'); tmp.innerHTML = fieldHtml(f); const n = tmp.firstChild;
      const focused = document.activeElement && document.activeElement.id; el.replaceWith(n);
      if (focused) { const again = document.getElementById(focused); if (again) again.focus(); }
      syncMeters();
    }
    function syncMeters() {
      TP.qsa('[data-meter]', box).forEach((mt) => { const s = E.strength(ctx.data[mt.dataset.meter]); mt.className = 'as-meter s' + s; mt.title = [t('Très faible'), t('Faible'), t('Correct'), t('Bon'), t('Excellent')][s]; });
      TP.qsa('input[data-masked]', box).forEach((i) => { if (i.dataset.masked === '1' && i.type !== 'password') { i.type = 'password'; } });
    }
    function showError(name, msg) {
      st.errors[name] = msg || '';
      const wrap = TP.qs('[data-field="' + name + '"]', box); if (!wrap) return;
      const holder = TP.qs('.as-ferr', wrap); if (holder) holder.innerHTML = msg ? icon('alert') + '<span>' + esc(msg) + '</span>' : '';
      wrap.classList.toggle('error', !!msg);
      TP.qsa('input,select,textarea', wrap).forEach((i) => { if (msg) i.setAttribute('aria-invalid', 'true'); else i.removeAttribute('aria-invalid'); });
    }
    function fieldDef(name) { const s = steps()[st.i]; return s && (s.fields || []).find((f) => f.name === name); }
    function readInput(el) {
      const f = fieldDef(el.name); if (!f) return;
      let v = el.type === 'checkbox' ? el.checked : el.value;
      if (f.type === 'number' && typeof v === 'string' && /^-?\d+(\.\d+)?$/.test(v.trim())) v = Number(v);
      ctx.data[el.name] = v;
      if (typeof f.onChange === 'function') f.onChange(v, ctx.data, ctx);
      saveDraft();
    }
    function afterChange(name, finalEvt) {
      const f = fieldDef(name); if (!f) return;
      if (finalEvt) st.touched[name] = true;
      if (st.touched[name] || st.errors[name]) showError(name, E.validateField(f, ctx.data[name], ctx.data, ctx));
      syncVisibility(); syncMeters();
      (steps()[st.i].fields || []).filter((x) => (x.dependsOn || []).includes(name)).forEach((x) => rerenderField(x.name));
      if (typeof f.sync === 'function') f.sync(ctx.data, ctx, box);
    }

    // ---------- navigation
    function validateCurrent(focus) {
      const s = steps()[st.i]; const errs = E.validateStep(s, ctx.data, ctx, ctx.mode);
      E.visibleFields(s, ctx.data, ctx, ctx.mode).forEach((f) => { st.touched[f.name] = true; showError(f.name, errs[f.name] || ''); });
      const names = Object.keys(errs).filter((k) => k !== '_step');
      if (errs._step) { const al = TP.qs('#as-pane', box); if (al && !TP.qs('.as-step-err', al)) al.insertAdjacentHTML('afterbegin', '<div class="alert danger as-step-err" role="alert">' + icon('alert') + '<div>' + esc(errs._step) + '</div></div>'); }
      if (names.length && focus !== false) {
        const el = TP.qs('[data-field="' + names[0] + '"] input, [data-field="' + names[0] + '"] select, [data-field="' + names[0] + '"] textarea, [data-field="' + names[0] + '"] .as-card', box);
        if (el) { el.focus(); if (el.scrollIntoView) el.scrollIntoView({ block: 'center' }); }
        say(names.length === 1 ? t('Une information est à corriger.') : t('{n} informations sont à corriger.', { n: names.length }));
      }
      return !Object.keys(errs).length;
    }
    function prev() {
      if (st.stage === 'review') { st.stage = 'form'; st.i = steps().length - 1; st.check = null; draw(); }
      else if (st.i > 0) { st.i -= 1; draw(); }
      saveDraft();
    }
    async function next() {
      if (!validateCurrent()) return;
      if (typeof steps()[st.i].check === 'function') {  // validation asynchrone propre à l'étape (ex. nom déjà pris)
        const btn = TP.qs('#as-next', foot); if (TP.btnLoading) TP.btnLoading(btn, true);
        let msg = '';
        try { msg = await steps()[st.i].check(ctx.data, ctx); } catch (e) { msg = e.message; }
        if (TP.btnLoading) TP.btnLoading(btn, false);
        if (msg) { const al = TP.qs('#as-pane', box); if (al && !TP.qs('.as-step-err', al)) al.insertAdjacentHTML('afterbegin', '<div class="alert danger as-step-err" role="alert">' + icon('alert') + '<div>' + esc(msg) + '</div></div>'); return; }
      }
      if (st.i < steps().length - 1) { st.i += 1; saveDraft(); draw(); return; }
      st.stage = 'review'; st.check = null; st.checkErr = null; saveDraft(); draw(); doCheck();
    }
    function reviewBody() {
      if (st.checkErr) return errBlock(st.checkErr) + (st.checkErr.data && st.checkErr.data.field ? '<p><button type="button" class="btn" id="as-gofield">' + icon('edit') + t('Corriger ce champ') + '</button></p>' : '');
      if (!st.check) return '<div class="as-loading inline" role="status">' + A.spinnerSvg(56) + '<p>' + t('Vérification de votre demande (rien n\'est encore modifié)…') + '</p></div>';
      const sm = st.check.summary && st.check.summary.length ? st.check.summary : (typeof def.summary === 'function' ? def.summary(ctx.data, ctx) : []);
      const kindIc = { ok: 'check', info: 'info', warn: 'alert', skip: 'info' };
      return '<ul class="as-recap">' + sm.map((x) => '<li class="' + esc(x.kind || 'ok') + '">' + icon(kindIc[x.kind || 'ok'] || 'check') + '<div><b>' + esc(tv(x.label, x.label_t)) + '</b>' + (x.detail ? '<small>' + esc(tv(x.detail, x.detail_t)) + '</small>' : '') + '</div></li>').join('') + '</ul>' +
        ((st.check.warnings || []).length ? '<div class="alert warn mt">' + icon('alert') + '<div>' + st.check.warnings.map((w) => '<div>' + esc(ts(w)) + '</div>').join('') + '</div></div>' : '') +
        '<p class="small muted as-note">' + icon('shield') + t('Rien n\'a encore été modifié. Si une étape échoue, ce qui vient d\'être créé est automatiquement supprimé.') + '</p>';
    }
    async function doCheck() {
      const mySeq = (st.seq = (st.seq || 0) + 1);
      try {
        const r = await TP.post('/api/assist/' + id + '/check', E.payload(def, ctx.data, ctx, ctx.mode));
        if (mySeq !== st.seq || st.closed) return;
        st.check = r.data; st.checkErr = null;
      } catch (e) { if (mySeq !== st.seq || st.closed) return; st.check = null; st.checkErr = e; }
      if (st.stage !== 'review') return;
      const pane = TP.qs('#as-pane', box); if (!pane) return;
      pane.innerHTML = '<h4 class="as-h" id="as-h" tabindex="-1">' + t('Voici ce qui va être fait') + '</h4>' + reviewBody();
      const ap = TP.qs('#as-apply', foot); if (ap) ap.disabled = !st.check;
      const gf = TP.qs('#as-gofield', box);
      if (gf) gf.onclick = () => {
        const name = st.checkErr.data.field, idx = E.stepOfField(def, name, ctx.data, ctx, ctx.mode);
        st.stage = 'form'; st.i = idx >= 0 ? idx : 0; draw(); showError(name, st.checkErr.data.msg); const el = TP.qs('[data-field="' + name + '"] input, [data-field="' + name + '"] select', box); if (el) el.focus();
      };
      const hh = TP.qs('#as-h', box); if (hh) hh.focus();
      say(st.check ? t('Récapitulatif prêt : vérifiez puis appliquez.') : (st.checkErr && st.checkErr.message) || '');
    }

    // ---------- application : chargement animé
    function busyOverlay(title, itemsInit) {
      const ov = document.createElement('div'); ov.className = 'as-busy'; ov.setAttribute('role', 'status'); ov.setAttribute('aria-live', 'polite');
      ov.innerHTML = A.spinnerSvg(124) + '<h4 class="as-busy-t"></h4><p class="as-busy-m"></p><ol class="as-list"></ol><div class="as-meta"></div><div class="as-busy-act"></div>';
      TP.qs('.as-busy-t', ov).textContent = title;
      dlg.appendChild(ov); dlg.classList.add('as-working');
      TP.qsa('.modal-b, .modal-f', dlg).forEach((x) => { try { x.inert = true; } catch (e) { /* navigateur sans inert */ } });
      const lst = stepList(TP.qs('.as-list', ov), itemsInit || []);
      const arc = TP.qs('.as-ring-arc', ov), meta = TP.qs('.as-meta', ov), msg = TP.qs('.as-busy-m', ov);
      return {
        el: ov, list: lst, msg: (s) => { msg.textContent = s; },
        progress(p, remaining, stepTxt) { const v = Math.round(p * 100); arc.setAttribute('stroke-dashoffset', String(100 - v)); ov.style.setProperty('--as-p', String(p)); meta.textContent = [v + ' %', stepTxt, remaining == null ? '' : (remaining > 1 ? t('environ {s} s restantes', { s: remaining }) : t('presque terminé'))].filter(Boolean).join(' · '); },
        actions(html) { TP.qs('.as-busy-act', ov).innerHTML = html; },
        close() { ov.remove(); dlg.classList.remove('as-working'); TP.qsa('.modal-b, .modal-f', dlg).forEach((x) => { try { x.inert = false; } catch (e) { /* */ } }); },
      };
    }
    const REASSURE = () => [t('Un instant : le serveur travaille pour vous.'), t('Vous pouvez fermer cette fenêtre, l\'opération continue en arrière-plan.'), t('Ne rechargez pas la page : tout est sous contrôle.'), t('Chaque étape est vérifiée avant de passer à la suivante.')];

    async function apply() {
      if (st.busy) return; st.busy = true;
      const btn = TP.qs('#as-apply', foot); if (TP.btnLoading) TP.btnLoading(btn, true);
      let r;
      try { r = (await TP.post('/api/assist/' + id + '/apply', E.payload(def, ctx.data, ctx, ctx.mode))).data; }
      catch (e) { st.busy = false; if (TP.btnLoading) TP.btnLoading(btn, false); st.checkErr = e; st.check = null; draw(); const pane = TP.qs('#as-pane', box); pane.insertAdjacentHTML('beforeend', errBlock(e)); return; }
      st.busy = false; st.stage = 'apply'; st.task = r.task_id; st.run = { steps: r.steps, eta: r.eta, started: Date.now() / 1000, status: 'running' };
      draw(false);
      const ov = busyOverlay(def.busyTitle || t('Je m\'en occupe…'), r.steps);
      st.ov = ov;
      ov.msg(REASSURE()[0]);
      ov.actions('<button type="button" class="btn sm" id="as-bg">' + t('Continuer en arrière-plan') + '</button><button type="button" class="btn sm danger" id="as-abort">' + t('Annuler') + '</button>');
      TP.qs('#as-bg', ov.el).onclick = () => m.close();
      TP.qs('#as-abort', ov.el).onclick = async () => { const b = TP.qs('#as-abort', ov.el); b.disabled = true; ov.msg(t('Annulation en cours : ce qui a été créé est supprimé…')); try { await TP.post('/api/assist/task/' + st.task + '/cancel'); } catch (e) { TP.toast(e.message, 'error'); b.disabled = false; } };
      pollRun(def, st, ctx, ov, REASSURE, finishApply);
    }
    function finishApply(run) {
      st.run = run;
      if (st.ov) { st.ov.progress(run.status === 'done' ? 1 : (E.progress(run).fraction), 0, ''); }
      setTimeout(() => {
        if (st.ov) { st.ov.close(); st.ov = null; }
        if (st.closed) return;
        if (run.status === 'done') {
          st.applied = true; delete drafts[id]; ctx.result = run.result || {};
          if (def.test === false) { st.stage = 'done'; draw(); } else { st.stage = 'test'; st.tests = null; draw(); runTests(); }
        } else { st.stage = 'failed'; draw(); }
      }, TP.motionOk && TP.motionOk() ? 450 : 0);
    }
    function failedBody() {
      const run = st.run || {}, e = run.error || {};
      const rb = (run.rollback || []).length ? '<h5 class="as-h5">' + t('Retour arrière') + '</h5><ul class="as-recap">' + run.rollback.map((x) => '<li class="' + (x.ok ? 'ok' : 'warn') + '">' + icon(x.ok ? 'check' : 'alert') + '<div><b>' + esc(ts(x.label)) + '</b><small>' + (x.ok ? esc(t('supprimé')) : esc(ts(x.error))) + '</small></div></li>').join('') + '</ul>' : '';
      return '<h4 class="as-h" id="as-h" tabindex="-1">' + (run.status === 'cancelled' ? t('Opération annulée') : t('Ça n\'a pas fonctionné')) + '</h4>' +
        (run.status === 'cancelled' ? '<div class="alert info">' + icon('info') + '<div>' + t('Rien n\'est resté en place : tout ce qui avait été créé a été supprimé.') + '</div></div>' : errBlock({ data: { msg: e.message, msg_t: e.message_t, cause: e.cause, cause_t: e.cause_t, fix: e.fix, fix_t: e.fix_t, help: e.help || def.help || def.pages[0] } })) +
        '<ul class="as-recap as-failsteps">' + (run.steps || []).map((x) => '<li class="' + (x.status === 'ok' ? 'ok' : x.status === 'error' ? 'bad' : 'skip') + '">' + icon(x.status === 'ok' ? 'check' : x.status === 'error' ? 'x' : 'info') + '<div><b>' + esc(ts(x.label)) + '</b>' + (x.detail ? '<small>' + esc(ts(x.detail)) + '</small>' : '') + '</div></li>').join('') + '</ul>' + rb;
    }
    // ---------- tests
    function testBody() {
      const decl = (st.declChecks || []).map((c) => ({ key: c.key, label: c.label, status: 'pending' }));
      if (st.testing || !st.tests) return '<div class="as-testing" role="status"><div class="as-test-ring">' + A.spinnerSvg(64) + '</div><p class="as-busy-m">' + t('Je vérifie que tout fonctionne vraiment (connexion, accès, réponse du serveur)…') + '</p><ol class="as-list" id="as-tl"></ol></div>' + (st.testErr ? errBlock(st.testErr) : '');
      const rep = st.tests, c = rep.counts || {}, tone = rep.status;
      const lab = { ok: t('OK'), warn: t('Attention'), fail: t('Échec') }, ic = { ok: 'check', warn: 'alert', fail: 'x' };
      const sum = tone === 'ok' ? t('Tout fonctionne : {n} vérification(s) réussie(s).', { n: c.ok || 0 }) : tone === 'warn' ? t('Ça fonctionne, avec {n} point(s) à surveiller.', { n: c.warn || 0 }) : t('{n} vérification(s) en échec : voici quoi faire.', { n: c.fail || 0 });
      return '<div class="as-report ' + tone + '"><div class="as-rep-sum">' + icon(tone === 'ok' ? 'check' : tone === 'warn' ? 'alert' : 'x') + '<div><b>' + esc(sum) + '</b><small>' + (c.ok || 0) + ' ' + t('réussie(s)') + ' · ' + (c.warn || 0) + ' ' + t('attention') + ' · ' + (c.fail || 0) + ' ' + t('échec(s)') + '</small></div></div>' +
        '<ul class="as-checks">' + (rep.checks || []).map((k, i) => '<li class="as-chk ' + k.status + '" style="--as-i:' + i + '"><span class="as-chk-ic" aria-hidden="true">' + icon(ic[k.status]) + '</span><div class="as-chk-b"><b>' + esc(tv(k.label, k.label_t)) + ' <span class="as-chk-st">' + esc(lab[k.status]) + '</span></b>' + (k.detail ? '<div class="small">' + esc(tv(k.detail, k.detail_t)) + '</div>' : '') +
          (k.cause ? '<div class="as-cause"><b>' + t('Cause probable') + ' :</b> ' + esc(tv(k.cause, k.cause_t)) + '</div>' : '') +
          (k.fix || k.help ? '<div class="as-chk-act">' + (k.fix ? '<button type="button" class="btn xs primary" data-fix="' + esc(k.fix.id) + '">' + icon('wand') + esc(ts(k.fix.label) || t('Corriger automatiquement')) + '</button>' : '') + (k.help ? '<button type="button" class="btn xs" data-help="' + esc(k.help) + '">' + icon('help') + t('Voir l\'aide') + '</button>' : '') + '</div>' : '') + '</div></li>').join('') + '</ul></div>';
    }
    async function runTests() {
      st.testing = true; st.testErr = null; st.tests = null; draw(false);
      const lst = TP.qs('#as-tl', box); const items = (st.declChecks || []).map((c) => ({ key: c.key, label: c.label, status: 'running' }));
      const tl = lst ? stepList(lst, items) : null;
      let rep = null; const t0 = Date.now();
      try { rep = (await TP.post('/api/assist/' + id + '/test', { task_id: st.task })).data; } catch (e) { st.testErr = e; }
      const wait = TP.motionOk && TP.motionOk() ? Math.max(0, 900 - (Date.now() - t0)) : 0; if (wait) await sleep(wait);  // laisse le temps de lire : le contrôle rapide ne clignote pas
      if (st.closed) return;
      if (tl && rep) { const byKey = {}; (rep.checks || []).forEach((c) => { byKey[c.key] = c; }); for (const c of (st.declChecks || [])) { const r = byKey[c.key]; tl.set(c.key, r ? (r.status === 'ok' ? 'ok' : r.status === 'warn' ? 'warn' : 'error') : 'skipped', ''); if (TP.motionOk && TP.motionOk()) await sleep(110); if (st.closed) return; } }
      st.testing = false; st.tests = rep; draw(false);
      const hh = TP.qs('#as-h', box); if (hh) hh.focus();
      if (rep) say(rep.status === 'ok' ? t('Toutes les vérifications ont réussi.') : rep.status === 'warn' ? t('Vérifications terminées : points à surveiller.') : t('Vérifications terminées : des échecs sont à corriger.'));
    }
    async function doFix(fixId, btn) {
      if (TP.btnLoading) TP.btnLoading(btn, true);
      try { const r = (await TP.post('/api/assist/' + id + '/fix', { task_id: st.task, fix: fixId })).data; st.tests = r.report; if (r.message) TP.toast(r.message); draw(false); say(r.message || t('Correction appliquée.')); }
      catch (e) { if (TP.btnLoading) TP.btnLoading(btn, false); TP.toast(e.message, 'error'); const cause = e.data && e.data.cause; if (cause) TP.toast(cause, 'warn', 7000); }
    }
    // ---------- fin : « Et maintenant ? »
    function doneBody() {
      const tone = st.tests ? st.tests.status : 'ok';
      const d = def.done || {};
      const resultHtml = typeof d.render === 'function' ? d.render(ctx.result || {}, ctx) : '';
      const next_ = (typeof d.next === 'function' ? d.next(ctx.result || {}, ctx) : (d.next || [])).filter((x) => !x.perm || (TP.can && TP.can(x.perm[0], x.perm[1])));
      return '<div class="as-done ' + tone + '"><div class="as-done-ic" aria-hidden="true"><svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="24"/><path d="m15 27 8 8 15-17" pathLength="30"/></svg></div>' +
        '<div><h4 class="as-h" id="as-h" tabindex="-1">' + esc(d.title || t('C\'est fait !')) + '</h4><p class="as-done-sub">' + esc(tone === 'ok' ? (d.subtitle || t('Tout a été créé et vérifié.')) : tone === 'warn' ? t('C\'est en place, avec quelques points à surveiller (voir la vérification).') : t('C\'est en place, mais certaines vérifications ont échoué : reprenez la vérification pour les corriger.')) + '</p></div></div>' +
        (resultHtml ? '<div class="as-result">' + resultHtml + '</div>' : '') +
        ((ctx.result && ctx.result.warnings && ctx.result.warnings.length) || (st.run && st.run.warnings && st.run.warnings.length) ? '<div class="alert warn mt">' + icon('alert') + '<div>' + (st.run.warnings || []).map((w) => '<div>' + esc(ts(w)) + '</div>').join('') + '</div></div>' : '') +
        (next_.length ? '<h5 class="as-h5">' + t('Et maintenant ?') + '</h5><div class="as-next">' + next_.map((x, i) => '<button type="button" class="as-nx" data-nx="' + i + '">' + icon(x.icon || 'chevron') + '<span><b>' + esc(x.label) + '</b>' + (x.desc ? '<small>' + esc(x.desc) + '</small>' : '') + '</span></button>').join('') + '</div>' : '') +
        (st.tests && st.tests.status !== 'ok' ? '<p class="mt"><button type="button" class="btn sm" id="as-backtest">' + icon('check') + t('Revoir la vérification') + '</button></p>' : '');
    }
    function again() { st.stage = 'form'; st.i = 0; st.errors = {}; st.touched = {}; st.check = null; st.run = null; st.tests = null; st.task = null; st.applied = false; ctx.data = E.defaults(def, ctx); Object.assign(ctx.data, opts.prefill || {}); draw(); }

    // ---------- événements délégués
    box.addEventListener('input', (e) => { const el = e.target; if (!el.name) return; readInput(el); afterChange(el.name, false); });
    box.addEventListener('change', (e) => {
      const el = e.target;
      if (el.dataset && el.dataset.multi) { const n = el.dataset.multi; ctx.data[n] = TP.qsa('[data-multi="' + n + '"]', box).filter((x) => x.checked).map((x) => x.value); saveDraft(); afterChange(n, true); return; }
      if (!el.name) return; readInput(el); afterChange(el.name, true);
    });
    box.addEventListener('focusout', (e) => { const el = e.target; if (el && el.name && st.stage === 'form') { st.touched[el.name] = true; const f = fieldDef(el.name); if (f) showError(el.name, E.validateField(f, ctx.data[el.name], ctx.data, ctx)); } });
    box.addEventListener('keydown', (e) => {
      const el = e.target;
      if (e.key === 'Enter' && st.stage === 'form' && el.tagName === 'INPUT' && el.type !== 'checkbox') { e.preventDefault(); next(); return; }
      if (el.classList && el.classList.contains('as-card') && ['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp'].includes(e.key)) {  // groupe radio : flèches
        e.preventDefault(); const cards = TP.qsa('.as-card[data-card="' + el.dataset.card + '"]', box); let i = cards.indexOf(el);
        i = (i + (['ArrowRight', 'ArrowDown'].includes(e.key) ? 1 : -1) + cards.length) % cards.length; cards[i].focus(); cards[i].click();
      }
    });
    box.addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.copyText !== undefined) { TP.copy(b.dataset.copyText); return; }
      if (b.dataset.tab) { const grp = b.closest('[data-tabs]'); if (grp) { TP.qsa('[data-tab]', grp).forEach((x) => x.setAttribute('aria-selected', String(x === b))); TP.qsa('[data-pane]', grp).forEach((x) => { x.hidden = x.dataset.pane !== b.dataset.tab; }); } return; }
      if (b.dataset.card) { ctx.data[b.dataset.card] = b.dataset.val; const f = fieldDef(b.dataset.card); saveDraft(); st.touched[b.dataset.card] = true; if (f && typeof f.onChange === 'function') f.onChange(b.dataset.val, ctx.data, ctx); rerenderField(b.dataset.card); syncVisibility(); const s = steps()[st.i]; (s.fields || []).filter((x) => (x.dependsOn || []).includes(b.dataset.card)).forEach((x) => rerenderField(x.name)); const again_ = TP.qs('.as-card.on[data-card="' + b.dataset.card + '"]', box); if (again_) again_.focus(); }
      else if (b.dataset.mode) { ctx.mode = b.dataset.mode; modeStore.set(ctx.mode); if (st.stage === 'review') { st.stage = 'form'; st.i = 0; } draw(false); const btn = TP.qs('[data-mode="' + ctx.mode + '"]', box); if (btn) btn.focus(); }
      else if (b.dataset.eye) { const i = TP.qs('[name="' + b.dataset.eye + '"]', box); i.type = i.type === 'password' ? 'text' : 'password'; i.dataset.masked = i.type === 'password' ? '1' : '0'; }
      else if (b.dataset.gen) { const f = fieldDef(b.dataset.gen); const pw = (f && typeof f.generate === 'function') ? f.generate() : E.genPassword(f && f.length || 16); ctx.data[b.dataset.gen] = pw; const i = TP.qs('[name="' + b.dataset.gen + '"]', box); i.value = pw; i.type = 'text'; i.dataset.masked = '0'; afterChange(b.dataset.gen, true); saveDraft(); TP.toast(t('Mot de passe fort généré')); }
      else if (b.dataset.copyf) { TP.copy(String(ctx.data[b.dataset.copyf] || '')); }
      else if (b.dataset.preset) {
        const vals = E.preset(def, b.dataset.preset, ctx); if (!vals) return;
        Object.assign(ctx.data, vals); st.auto = true; saveDraft();
        const bad = E.firstInvalid(def, ctx.data, ctx, ctx.mode);
        if (bad >= 0) { st.i = bad; draw(); validateCurrent(); TP.toast(t('Réglages recommandés appliqués : complétez les champs signalés.'), 'warn'); }
        else { st.stage = 'review'; st.check = null; draw(); doCheck(); TP.toast(t('Réglages recommandés appliqués : vérifiez le récapitulatif.')); }
      }
      else if (b.dataset.fresh !== undefined) { delete drafts[id]; again(); }
      else if (b.dataset.fix) doFix(b.dataset.fix, b);
      else if (b.dataset.nx !== undefined) { const d = def.done || {}; const arr = (typeof d.next === 'function' ? d.next(ctx.result || {}, ctx) : (d.next || [])).filter((x) => !x.perm || (TP.can && TP.can(x.perm[0], x.perm[1]))); const x = arr[Number(b.dataset.nx)]; m.close(); if (x) { if (x.run) x.run(ctx); else if (x.href) location.hash = x.href.replace(/^#/, ''); else if (x.assist) A.open(x.assist, x.opts); } }
      else if (b.id === 'as-backtest') { st.stage = 'test'; draw(); }
    });

    // ---------- démarrage : contexte serveur, brouillon, valeurs par défaut
    try {
      if (def.context) {  // contexte propre à l'assistant (moteurs installés, sites du compte…) : GET /api/assist/<id>/context
        const r = await TP.get('/api/assist/' + id + '/context'); ctx.meta = (r.data && r.data.context) || {}; ctx.server = (r.data && r.data.assistant) || {};
        st.declChecks = (ctx.server.checks || []);
        if (ctx.server.available === false) { box.innerHTML = '<div class="alert warn">' + icon('alert') + '<div><b>' + t('Cet assistant n\'est pas utilisable sur ce serveur pour le moment.') + '</b><div class="small mt-s">' + esc(ctx.server.reason || '') + '</div></div></div>'; setFoot([{ id: 'as-close', label: t('Fermer'), run: () => m.close() }]); return m; }
      } else {
        const sv = (await A.server()).find((x) => x.id === id); ctx.server = sv || {}; st.declChecks = (sv && sv.checks) || [];
      }
      if (typeof def.load === 'function') await def.load(ctx);
    } catch (e) {
      box.innerHTML = errBlock(e); setFoot([{ id: 'as-close', label: t('Fermer'), run: () => m.close() }]); return m;
    }
    ctx.data = E.defaults(def, ctx);
    if (saved) { Object.assign(ctx.data, saved.data); st.i = saved.i || 0; ctx.mode = saved.mode || ctx.mode; st.restored = true; }
    Object.assign(ctx.data, opts.prefill || {});
    st.stage = 'form'; draw();
    return m;
  };

  // suivi d'une exécution (interrogation de /api/assist/task/<id>) : met à jour la liste animée, le pourcentage et le message rassurant
  async function pollRun(def, st, ctx, ov, reassure, done) {
    let n = 0, fails = 0;
    for (;;) {
      if (st.closed || st.stage !== 'apply') return;
      let run = null;
      try { run = (await TP.get('/api/assist/task/' + st.task)).data; fails = 0; } catch (e) { if (++fails > 6) { done({ status: 'error', steps: st.run.steps, error: { message: e.message }, rollback: [] }); return; } }
      if (run) {
        st.run = Object.assign({}, st.run, run);
        ov.list.update(run.steps);
        const p = E.progress(run, Date.now() / 1000);
        const cur = run.steps.find((s) => s.status === 'running');
        ov.progress(p.fraction, p.remaining, t('{a} sur {b}', { a: Math.min(run.done + (cur ? 1 : 0), run.total), b: run.total }));
        if (run.task_status === 'queued') ov.msg(t('En file d\'attente : {n} tâche(s) avant la vôtre.', { n: run.queue_position || 1 }));
        else if (n % 5 === 0) ov.msg(reassure()[Math.floor(n / 5) % reassure().length]);
        if (['done', 'error', 'cancelled'].includes(run.status)) { done(run); return; }
        if (run.task_status && ['error', 'cancelled'].includes(run.task_status) && run.status === 'running') { done(Object.assign({}, run, { status: 'error', error: run.error || { message: t('La tâche s\'est arrêtée de façon inattendue') } })); return; }
      }
      n++; await sleep(700);
    }
  }
  // fenêtre fermée pendant l'application : on continue d'attendre en silence puis on prévient
  async function watchInBackground(def, st, ctx) {
    TP.toast(t('{t} continue en arrière-plan.', { t: def.title }), 'ok', 4000);
    for (let i = 0; i < 400; i++) {
      await sleep(1500);
      try {
        const run = (await TP.get('/api/assist/task/' + st.task)).data;
        if (['done', 'error', 'cancelled'].includes(run.status)) {
          if (run.status === 'done') { TP.toast(t('{t} : terminé.', { t: def.title }), 'ok', 6000); A.reloadPage(def); } else TP.toast(t('{t} : échec ({e}).', { t: def.title, e: (run.error && run.error.message) || '' }), 'error', 8000);
          return;
        }
      } catch (e) { return; }
    }
  }
  A.reloadPage = (def) => { try { if (!def || (def.pages || []).includes(TP.route ? TP.route() : '')) { const b = document.getElementById('btn-refresh'); if (b) b.click(); } } catch (e) { /* page non rechargeable */ } };

  // ============================================================ aides d'affichage pour les écrans de fin
  // Liste « libellé : valeur » avec bouton Copier ; rows = [[libellé, valeur, { secret: true }?], …]
  A.kv = (rows) => '<dl class="as-kv">' + rows.filter((r) => r && r[1] !== undefined && r[1] !== null && r[1] !== '').map((r) => '<dt>' + esc(r[0]) + '</dt><dd><span>' + esc(r[1]) + '</span><button type="button" class="btn xs" data-copy-text="' + esc(r[1]) + '" title="' + esc(t('Copier')) + '" aria-label="' + esc(t('Copier') + ' ' + r[0]) + '">' + icon('copy') + '</button></dd>').join('') + '</dl>';
  // Onglets d'extraits de code (PHP, Python, Node…) avec bouton Copier ; tabs = [{ id, label, code, note? }]
  A.codeTabs = (tabs) => {
    tabs = tabs.filter((x) => x && x.code);
    if (!tabs.length) return '';
    return '<div data-tabs><div class="as-tabs" role="tablist">' + tabs.map((x, i) => '<button type="button" role="tab" data-tab="' + esc(x.id) + '" aria-selected="' + (i === 0) + '">' + esc(x.label) + '</button>').join('') + '</div>' +
      tabs.map((x, i) => '<div class="as-tabpane as-code" role="tabpanel" data-pane="' + esc(x.id) + '"' + (i ? ' hidden' : '') + '>' + (x.note ? '<p class="small muted">' + esc(x.note) + '</p>' : '') + '<pre tabindex="0">' + esc(x.code) + '</pre><button type="button" class="btn xs" data-copy-text="' + esc(x.code) + '">' + icon('copy') + t('Copier') + '</button></div>').join('') + '</div>';
  };

  // ============================================================ lanceur
  const SHORT = {};  // descriptions courtes pour les grosses actions du tableau de bord
  A.launcher = function (opts) {
    opts = opts || {};
    const list = A.list(); if (!list.length) return '';
    const order = opts.order || ['site', 'database', 'ftp', 'mail', 'backup', 'cron', 'waf', 'account'];
    list.sort((a, b) => { const ia = order.indexOf(a.id), ib = order.indexOf(b.id); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib); });
    let hidden = false; try { hidden = localStorage.getItem('tp-assist-launcher') === 'hidden'; } catch (e) { /* stockage indisponible */ }
    return '<div class="card as-launcher mb' + (hidden ? ' collapsed' : '') + '" id="as-launcher"><div class="card-h"><h3>' + icon('wand') + t('Que voulez-vous faire ?') + '</h3><span class="muted small">' + t('Des assistants vous guident pas à pas, sans jargon.') + '</span><span class="spacer" style="flex:1"></span>' +
      '<button type="button" class="btn ghost sm" data-as-toggle aria-expanded="' + (!hidden) + '" aria-controls="as-tiles">' + (hidden ? t('Afficher') : t('Réduire')) + '</button></div>' +
      '<div class="card-b" id="as-tiles"' + (hidden ? ' hidden' : '') + '><div class="as-tiles" role="list">' + list.map((d) => '<button type="button" class="as-tile" role="listitem" data-assist-open="' + esc(d.id) + '"><span class="as-tile-ic">' + icon(d.icon || 'wand') + '</span><span class="as-tile-t"><b>' + esc(d.tile || d.title.replace(/^Assistant\s+/i, '')) + '</b><small>' + esc(d.short || d.description || SHORT[d.id] || '') + '</small></span></button>').join('') + '</div></div></div>';
  };
  A.pageButton = function (route, actionsHtml) {
    if (typeof actionsHtml === 'string' && (actionsHtml.includes('data-assist-open') || actionsHtml.includes('id="wizard"'))) return '';
    const l = A.forPage(route); if (!l.length) return '';
    if (l.length === 1) return '<button type="button" class="btn as-btn" data-assist-open="' + esc(l[0].id) + '" title="' + esc(l[0].title) + '">' + icon('wand') + t('Assistant') + '</button>';
    return '<span class="as-menuwrap"><button type="button" class="btn as-btn" data-assist-menu="' + esc(route) + '" aria-haspopup="menu" aria-expanded="false">' + icon('wand') + t('Assistant') + '</button></span>';
  };
  A.emptyButton = function (id) {
    const d = id ? REG[id] : A.forPage(TP.route ? TP.route() : '')[0];
    if (!d || !can(d)) return '';
    return '<button type="button" class="btn sm as-empty-btn" data-assist-open="' + esc(d.id) + '">' + icon('wand') + t('Lancer l\'assistant') + '</button>';
  };
  A.paletteEntries = function () {
    return A.list().map((d) => ({ label: t('Assistant : {n}', { n: d.title.replace(/^Assistant\s+(de |du |d')?/i, '').replace(/^./, (c) => c.toUpperCase()) }), sub: d.description || '', icon: 'wand', run: () => A.open(d.id) }));
  };
  // menu rapide « + » de la barre du haut
  A.quickButton = () => (A.list().length ? '<div class="as-quick"><button type="button" class="ibtn as-quick-btn" id="btn-quick" title="' + esc(t('Créer quelque chose')) + '" aria-label="' + esc(t('Créer quelque chose')) + '" aria-haspopup="menu" aria-expanded="false">' + icon('plus') + '</button></div>' : '');
  let pop = null;
  function closePop() { if (!pop) return; const p = pop; pop = null; p.el.remove(); document.removeEventListener('keydown', p.key, true); document.removeEventListener('mousedown', p.out, true); const b = p.btn; if (b) { b.setAttribute('aria-expanded', 'false'); try { b.focus(); } catch (e) { /* */ } } }
  function openPop(btn, list) {
    closePop();
    const el = document.createElement('div'); el.className = 'as-pop'; el.setAttribute('role', 'menu'); el.setAttribute('aria-label', t('Assistants'));
    const groups = {}; list.forEach((d) => { (groups[d.group] = groups[d.group] || []).push(d); });
    el.innerHTML = Object.keys(groups).map((g) => '<div class="as-pop-g" role="presentation">' + esc(A.groupLabel(g)) + '</div>' + groups[g].map((d) => '<button type="button" role="menuitem" class="as-pop-i" data-assist-open="' + esc(d.id) + '">' + icon(d.icon || 'wand') + '<span><b>' + esc(d.tile || d.title.replace(/^Assistant\s+/i, '')) + '</b></span></button>').join('')).join('');
    document.body.appendChild(el);
    const r = btn.getBoundingClientRect(); const w = el.offsetWidth;
    el.style.top = Math.round(r.bottom + 6) + 'px'; el.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, (document.dir === 'rtl' ? r.left : r.right - w))) + 'px';
    btn.setAttribute('aria-expanded', 'true');
    const items = TP.qsa('.as-pop-i', el);
    const key = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closePop(); }
      else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const i = items.indexOf(document.activeElement); items[(i + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length].focus(); }
      else if (e.key === 'Tab') closePop();
    };
    const out = (e) => { if (!el.contains(e.target) && e.target !== btn && !btn.contains(e.target)) closePop(); };
    document.addEventListener('keydown', key, true); document.addEventListener('mousedown', out, true);
    el.addEventListener('click', (e) => { if (e.target.closest('.as-pop-i')) { const p = pop; pop = null; el.remove(); document.removeEventListener('keydown', key, true); document.removeEventListener('mousedown', out, true); btn.setAttribute('aria-expanded', 'false'); } });
    pop = { el, key, out, btn };
    if (items[0]) items[0].focus();
  }
  document.addEventListener('click', (e) => {
    if (!e.target.closest) return;
    const tg = e.target.closest('[data-as-toggle]');
    if (tg) { const card = tg.closest('.as-launcher'), body = card && TP.qs('#as-tiles', card); if (body) { const hide = !body.hidden; body.hidden = hide; card.classList.toggle('collapsed', hide); tg.setAttribute('aria-expanded', String(!hide)); tg.textContent = hide ? t('Afficher') : t('Réduire'); try { localStorage.setItem('tp-assist-launcher', hide ? 'hidden' : 'shown'); } catch (er) { /* stockage indisponible */ } } return; }
    const o = e.target.closest('[data-assist-open]');
    if (o) { e.preventDefault(); A.open(o.dataset.assistOpen); return; }
    const q = e.target.closest('#btn-quick');
    if (q) { e.preventDefault(); if (pop && pop.btn === q) closePop(); else openPop(q, A.list()); return; }
    const mn = e.target.closest('[data-assist-menu]');
    if (mn) { e.preventDefault(); if (pop && pop.btn === mn) closePop(); else openPop(mn, A.forPage(mn.dataset.assistMenu)); }
  });
  if (typeof module !== 'undefined' && module.exports) module.exports = A;
})();
