/* Tableau commun du panel : TP.uiTable(options) renvoie le HTML d'un tableau à colonnes fixes (static/css/ui-table.css).

   Garanties : toutes les lignes ont la même hauteur (une ligne de texte tronquée par « … » avec infobulle, jamais de retour à la ligne), les pastilles et les
   icônes d'actions occupent des emplacements (« slots ») de largeur fixe donc alignés d'une ligne à l'autre, alignement vertical centré, clair / sombre, et
   sous 987 px de largeur du conteneur chaque ligne devient une carte. Pour une page qui n'est pas encore migrée, TP.table (core.js) reste inchangé.

   Usage (voir pages-sites.js) :

     root.innerHTML = '<div class="card">' + TP.uiTable({
       label: t('Sites web'),                              // nom accessible du tableau (aria-label)
       cols: [
         { key: 'site', label: t('Site'), cell: (s) => TP.uiTable.stack(line1Html, line2Html), card: { order: 0, full: true } },   // sans `w` : prend la place restante
         { key: 'type', label: t('Type'), w: 150, cell: (s) => TP.uiTable.pills([{ fill: true }], [TP.uiTable.pill('PHP 8.3', 'info', { tip: '…' })]), card: { order: 1 } },
         { key: 'root', label: t('Racine'), w: 170, wide: true, cell: (s) => TP.uiTable.trunc(TP.esc(s.root), { cls: 'uit-mono' }) },   // `wide` : masquée sous 1237 px
         { key: 'size', label: t('Taille'), w: 84, end: true, cell: (s) => TP.esc(s.size) },                                           // `end` : alignée à la fin (nombres)
         { key: 'act', label: t('Actions'), srLabel: true, w: TP.uiTable.actsWidth(3), cell: (s) => TP.uiTable.acts([ … 3 emplacements, null = vide … ]), card: { order: 9, full: true } },
       ],
       rows: sites, rowAttr: (s) => 'data-id="' + s.id + '"',
       empty: t('Aucun site'), icon: 'globe', cta: { label: …, target: '#add' },   // mêmes options que TP.table pour l'état vide
     }) + '</div>';

   Option `md: true` : tableau placé dans une colonne étroite (ex. enregistrements DNS à côté de la liste des zones) : les cartes n'apparaissent que sous 720 px (987 px sinon).
   Colonnes : `w` largeur en px (au moins une colonne sans `w`), `wide` (masquée sous 1237 px), `xwide` (masquée sous 1437 px : colonnes les moins utiles des tableaux chargés), `end`, `srLabel` (en-tête réservé aux lecteurs d'écran),
   `card: { order, full }` (rang et pleine largeur dans la carte mobile). Les gestionnaires de clic restent ceux de la page (data-a / data-id comme avant).
   Options du tableau : `dense: true` (listes secondaires à une seule ligne : journal, connexions), `rowAttr`, `id`, `label`. Assistants en plus : `meter(pct)` (jauge d'utilisation),
   `rowActs(items, id, nom)` (rangée d'actions d'une ligne : id, infobulle et nom accessible « Supprimer · nom » ajoutés ; `attr: 'p'` pour une page qui lit data-p="act" data-id,
   ou `attr` sans `act` pour data-<attr>="id" ; `attrs` pour des attributs en plus ; `href` pour un lien). Pages migrées : sites, FTP, messagerie, sauvegardes, tâches planifiées, comptes.
   Les cellules sont du HTML : échapper les données avec TP.esc ; les assistants ci-dessous échappent eux-mêmes leurs arguments texte. */
(function () {
  'use strict';
  const TP = window.TP, t = TP.t;
  const esc = (v) => TP.esc(v == null ? '' : v);

  // ---- assistants de cellule
  // texte sur une seule ligne tronquée ; html déjà échappé ; opts : tag ('span' | 'a' | 'b'), cls, attrs, tip (infobulle fixe, sinon le texte complet si la ligne est tronquée)
  const trunc = (html, opts) => { opts = opts || {}; const tag = opts.tag || 'span'; return '<' + tag + ' class="uit-trunc' + (opts.cls ? ' ' + opts.cls : '') + '"' + (opts.tip ? ' data-uit-tip="' + esc(opts.tip) + '"' : '') + (opts.attrs ? ' ' + opts.attrs : '') + '>' + html + '</' + tag + '>'; };
  // deux lignes empilées (hauteur fixe) : nom + détails ; sans détails, la ligne seule reste centrée
  // une seule ligne, centrée comme la pile (colonnes à une seule valeur) ; html déjà échappé
  const line = (html) => '<div class="uit-l1">' + (html || '') + '</div>';
  const stack = (l1, l2) => '<div class="uit-stack"><div class="uit-l1">' + (l1 || '') + '</div>' + (l2 ? '<div class="uit-l2">' + l2 + '</div>' : '') + '</div>';
  // pastille : tone ok | info | warn | danger | violet | '' ; opts : tip (infobulle), dot (défaut vrai), label (nom accessible),
  // icon (nom d'icône) ou glyph (1 à 2 caractères) : repère rond sans texte visible, `text` sert alors de nom accessible
  const pill = (text, tone, opts) => {
    opts = opts || {};
    const round = !!(opts.icon || opts.glyph);
    const tip = opts.tip || (round ? opts.label || text : '');
    const aria = round ? ' role="img" aria-label="' + esc(opts.label || text) + '"' : '';
    const inner = opts.icon ? TP.icon(opts.icon) : opts.glyph ? esc(opts.glyph) : (opts.dot === false ? '' : '<i class="dot"></i>') + '<span class="uit-trunc">' + esc(text) + '</span>';
    return '<span class="uit-pill ' + (tone || '') + (round ? ' uit-ico' : '') + '"' + (tip ? ' data-uit-tip="' + esc(tip) + '"' : '') + aria + '>' + inner + '</span>';
  };
  // rangée de pastilles sur une grille régulière : slots = [{ w: largeur px } | { fill: true }], items = une pastille (HTML) ou null par emplacement
  const pills = (slots, items) => '<div class="uit-pills">' + slots.map((sl, i) => '<span class="uit-slot' + (sl.fill ? ' uit-fill' : '') + '"' + (sl.w ? ' style="--w:' + Number(sl.w) + 'px"' : '') + '>' + ((items && items[i]) || '') + '</span>').join('') + '</div>';
  // « +N » : éléments supplémentaires listés dans l'infobulle (focusable : le clavier et le tactile y accèdent aussi)
  const more = (n, list) => n > 0 ? '<button type="button" class="uit-more" data-uit-tip="' + esc(list.join('\n')) + '" aria-label="' + esc(t('et {n} autres', { n: n }) + ' : ' + list.join(', ')) + '">+' + n + '</button>' : '';
  // icône d'action : { act, id, icon, label, tone ('' | 'on' | 'warn' | 'danger'), tip (par défaut label), disabled, static (repère non cliquable),
  // attr (autre attribut que data-a : data-<attr>="act" data-id="id", ou data-<attr>="id" sans `act`), href (+ blank, download) : lien au lieu d'un bouton ; attrs : attributs HTML déjà échappés (ex. data-edit="3"), en plus de data-a / data-id (ou à leur place si `act` est absent) }
  const act = (a) => {
    const tone = a.tone ? ' ' + (a.tone === 'on' ? 'is-on' : a.tone) : '';
    if (a.static) return '<span class="uit-act uit-act-static' + tone + '" role="img" aria-label="' + esc(a.label) + '" data-uit-tip="' + esc(a.tip || a.label) + '">' + TP.icon(a.icon) + '</span>';
    const common = ' aria-label="' + esc(a.label) + '" data-uit-tip="' + esc(a.tip || a.label) + '"' + (a.attrs ? ' ' + a.attrs : '');
    if (a.href) return '<a class="uit-act' + tone + '" href="' + esc(a.href) + '"' + (a.blank ? ' target="_blank" rel="noopener noreferrer"' : '') + (a.download ? ' download="' + esc(a.download) + '"' : '') + common + '>' + TP.icon(a.icon) + '</a>';
    const hook = a.attr && !a.act ? 'data-' + a.attr + '="' + esc(a.id) + '"' : (a.act ? 'data-' + (a.attr || 'a') + '="' + esc(a.act) + '" data-id="' + esc(a.id) + '"' : '');
    return '<button type="button" class="uit-act' + tone + '"' + (hook ? ' ' + hook : '') + common + (a.disabled ? ' disabled' : '') + '>' + TP.icon(a.icon) + '</button>';
  };
  // jauge fine d'utilisation (quota, disque) : pct de 0 à 100, teinte automatique (80 % attention, 95 % danger)
  const meter = (pct) => { pct = Math.max(0, Math.min(100, Number(pct) || 0)); return '<span class="uit-meter' + (pct >= 95 ? ' danger' : pct >= 80 ? ' warn' : '') + '" aria-hidden="true"><i style="width:' + Math.round(pct) + '%"></i></span>'; };
  // rangée d'actions : un emplacement par entrée (null = emplacement vide, la colonne reste alignée)
  const acts = (items) => '<div class="uit-acts" role="group">' + items.map((a) => a ? act(a) : '<span class="uit-act-ph" aria-hidden="true"></span>').join('') + '</div>';
  // rangée d'actions d'une ligne : chaque icône reçoit l'id de la ligne, son libellé comme infobulle et le nom de la ligne dans son nom accessible (« Supprimer · client1 »)
  const rowActs = (items, id, name) => acts(items.map((a) => a && (a.static ? a : Object.assign({ id: id, tip: a.label }, a, { label: a.label + (name ? ' · ' + name : '') }))));
  const actsWidth = (n) => n * 26 + Math.max(0, n - 1) + 24;   // largeur de colonne pour n icônes (26 px + 1 px d'écart + marges de cellule)

  // ---- tableau
  function uiTable(o) {
    const cols = o.cols || [], rows = o.rows;
    if (rows == null) return TP.skeleton(o.skeletonRows || 5, cols.length);
    if (!rows.length) return TP.empty(o.empty || t('Aucun élément'), o.icon, o);
    const cls = (c) => (c.wide ? ' uit-wide' : '') + (c.xwide ? ' uit-xwide' : '') + (c.end ? ' uit-end' : '');
    return '<div class="uit' + (o.md ? ' uit-md' : '') + (o.dense ? ' uit-dense' : '') + '"><table class="uit-t" role="table"' + (o.label ? ' aria-label="' + esc(o.label) + '"' : '') + (o.id ? ' id="' + esc(o.id) + '"' : '') + '>' +
      '<colgroup>' + cols.map((c) => '<col class="' + (c.wide ? 'uit-wide' : c.xwide ? 'uit-xwide' : '') + '"' + (c.w ? ' style="width:' + Number(c.w) + 'px"' : '') + '>').join('') + '</colgroup>' +
      '<thead role="rowgroup"><tr role="row">' + cols.map((c) => '<th role="columnheader" scope="col" class="' + cls(c).trim() + '">' + (c.srLabel ? '<span class="uit-sr">' + esc(c.label) + '</span>' : '<span class="uit-trunc">' + esc(c.label) + '</span>') + '</th>').join('') + '</tr></thead>' +
      '<tbody role="rowgroup">' + rows.map((r) => '<tr role="row"' + (o.rowAttr ? ' ' + o.rowAttr(r) : '') + '>' + cols.map((c) => {
        const cd = c.card || {};
        return '<td role="' + (c.rowHeader ? 'rowheader' : 'cell') + '" class="' + (cls(c) + (cd.full ? ' uit-full' : '')).trim() + '"' + (c.srLabel || c.rowHeader || !c.label ? '' : ' data-label="' + esc(c.label) + '"') + (cd.order != null ? ' style="--uit-co:' + Number(cd.order) + '"' : '') + '>' + c.cell(r) + '</td>';
      }).join('') + '</tr>').join('') + '</tbody></table></div>';
  }
  Object.assign(uiTable, { trunc, line, stack, pill, pills, more, act, acts, rowActs, actsWidth, meter });
  TP.uiTable = uiTable;

  // ---- infobulle unique : survol et focus clavier ; Échap ou défilement la referme ; texte complet des éléments tronqués
  let tip = null, cur = null;
  const pick = (el) => {
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.classList.contains('uit-trunc') && n.scrollWidth > n.clientWidth + 1 && !n.closest('[data-uit-tip]')) return { el: n, text: n.getAttribute('data-uit-full') || n.textContent };
      if (n.hasAttribute('data-uit-tip')) return { el: n, text: n.getAttribute('data-uit-tip') };
      if (n.classList.contains('uit')) break;
    }
    return null;
  };
  const hide = () => { if (!tip) return; tip.classList.remove('on'); if (cur) cur.removeAttribute('aria-describedby'); cur = null; };
  const show = (target) => {
    const p = target.closest && target.closest('.uit') ? pick(target) : null;
    if (!p || !p.text) { hide(); return; }
    if (!tip) { tip = document.createElement('div'); tip.className = 'uit-tooltip'; tip.id = 'uit-tooltip'; tip.setAttribute('role', 'tooltip'); document.body.appendChild(tip); }
    if (cur && cur !== p.el) cur.removeAttribute('aria-describedby');
    cur = p.el; cur.setAttribute('aria-describedby', 'uit-tooltip');
    tip.textContent = p.text;
    const r = p.el.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = window.innerHeight;
    tip.style.left = '0px'; tip.style.top = '0px'; tip.classList.add('on');
    const w = tip.offsetWidth, h = tip.offsetHeight;
    let x = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), Math.max(8, vw - w - 8));
    let y = r.bottom + 6; if (y + h > vh - 8 && r.top - h - 6 >= 8) y = r.top - h - 6;
    tip.style.left = Math.round(x) + 'px'; tip.style.top = Math.round(y) + 'px';
  };
  if (!window.__uitTip) {
    window.__uitTip = true;
    document.addEventListener('mouseover', (e) => { if (e.target.closest) show(e.target); });
    document.addEventListener('mouseout', (e) => { if (cur && (!e.relatedTarget || !cur.contains(e.relatedTarget))) hide(); });
    document.addEventListener('focusin', (e) => show(e.target));
    document.addEventListener('focusout', hide);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });
    window.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    window.addEventListener('hashchange', hide);
  }
})();
