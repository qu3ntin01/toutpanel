/* ToutPanel — thème d'automne : fond animé « vidéo » procédural (brume, rayons de lumière dorée, bokeh, halo suivant le curseur), pluie avec éclaboussures,
   feuilles qui tombent et tourbillonnent sur trois plans de profondeur, étincelles au survol, parallaxe souris + défilement, pied de page repliable.
   AUCUNE ressource externe : tout est dessiné en <canvas> 2D, feuilles pré-rendues une fois. Chargé en fin de page (lot site.js), démarré à l'inactivité.

   Coupure totale : l'interrupteur « Animations » (assets/theme.js : <html data-anim="on|off">, événement window « tp:anim ») arrête requestAnimationFrame
   et RETIRE les canvas du DOM ; même chose quand l'onglet est caché ou que la batterie est faible. Sous prefers-reduced-motion, les animations
   sont coupées par défaut (theme.js) et l'utilisateur peut les réactiver. Appareils tactiles ou étroits : version réduite (moins de feuilles / de gouttes,
   définition basse) ; la qualité baisse toute seule si la fréquence d'images chute (< ~40 i/s). Aucune lecture de layout dans la boucle. */
(function (win, doc) {
  'use strict';
  var root = doc.documentElement;
  var raf = win.requestAnimationFrame ? win.requestAnimationFrame.bind(win) : null;
  var caf = win.cancelAnimationFrame ? win.cancelAnimationFrame.bind(win) : function () {};
  function mq(q) { try { return win.matchMedia ? win.matchMedia(q) : null; } catch (e) { return null; } }
  function matches(q) { var m = mq(q); return !!(m && m.matches); }
  function onMq(m, fn) { if (!m) { return; } if (m.addEventListener) { m.addEventListener('change', fn); } else if (m.addListener) { m.addListener(fn); } }

  /* ---------------------------------------------------------------- pied de page : colonnes repliables sur mobile */
  function initFooter() {
    var cols = doc.querySelectorAll('.tp-foot__col');
    if (!cols.length) { return; }
    var narrow = mq('(max-width: 760px)');
    function sync() {
      for (var i = 0; i < cols.length; i++) {
        if (!narrow || !narrow.matches) { cols[i].open = true; } else if (cols[i].getAttribute('data-touched') !== '1') { cols[i].open = false; }
      }
    }
    for (var i = 0; i < cols.length; i++) {
      (function (c) {
        var s = c.querySelector('summary');
        if (!s) { return; }
        s.addEventListener('click', function (ev) {
          if (!narrow || !narrow.matches) { ev.preventDefault(); return; }   // grand écran : colonnes toujours ouvertes
          c.setAttribute('data-touched', '1');
        });
      })(cols[i]);
    }
    sync();
    onMq(narrow, sync);
  }

  /* ---------------------------------------------------------------- panneau « Réglages d'affichage » : Échap rend le focus au bouton, sortir du panneau au clavier le ferme
     (l'ouverture, la fermeture au clic extérieur et aria-expanded sont dans assets/app.js) */
  function initPrefs() {
    var box = doc.getElementById('lang');
    var btn = box && box.querySelector('.prefs__btn');
    if (!btn) { return; }
    /* Deux listes déroulantes du même modèle : langue (#prefs-lang-*) et devise (#prefs-cur-*). Une seule est ouverte à la fois. */
    var dds = [];
    function wire(btnId, listId) {
      var lb = doc.getElementById(btnId);
      var list = doc.getElementById(listId);
      var opts = list ? [].slice.call(list.querySelectorAll('[role=option]')) : [];
      var dd = { isOpen: function () { return !!list && !list.hidden; }, closeList: function () {} };
      if (!(lb && list && opts.length)) { return dd; }
      /* Liste longue (devises) : champ de recherche au-dessus de la liste (nom, code ou symbole, sans accents ni majuscules), compteur annoncé aux lecteurs d'écran. */
      var find = doc.getElementById(listId.replace(/-list$/, '-find'));
      var q = find ? find.querySelector('input') : null;
      var count = find ? find.querySelector('.prefs__count') : null;
      function vis() { return opts.filter(function (o) { return !o.hidden; }); }
      function norm(v) {
        v = String(v || '').toLowerCase();
        try { v = v.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) { /* navigateur ancien : sans normalisation */ }
        return v;
      }
      /* Indicateur de défilement : .has-up / .has-down tant qu'il reste des entrées hors de vue (ombres en haut / en bas, voir assets/country.css). */
      function edges() {
        list.classList.toggle('has-up', list.scrollTop > 2);
        list.classList.toggle('has-down', list.scrollTop + list.clientHeight < list.scrollHeight - 2);
      }
      list.addEventListener('scroll', edges);
      function say() {
        if (!count || !q) { return; }
        var n = vis().length;
        count.textContent = n ? (q.getAttribute('data-count') || '{n}').replace('{n}', String(n)) : (q.getAttribute('data-none') || '');
        count.classList.toggle('is-none', !n);
      }
      function filter() {
        var t = norm(q ? q.value : '').trim();
        opts.forEach(function (o) { o.hidden = !!t && norm(o.getAttribute('data-q') || o.textContent).indexOf(t) === -1; });
        list.scrollTop = 0;
        say(); edges();
      }
      function closeList(focusBtn) {
        if (!dd.isOpen()) { return; }
        list.hidden = true; lb.setAttribute('aria-expanded', 'false');
        if (find) { find.hidden = true; if (q && q.value) { q.value = ''; filter(); } }
        if (focusBtn) { lb.focus(); }
      }
      function openList(which) {
        dds.forEach(function (o) { if (o !== dd) { o.closeList(false); } });
        list.hidden = false; lb.setAttribute('aria-expanded', 'true');
        if (find) { find.hidden = false; say(); }
        var o = vis();
        var cur = o.filter(function (x) { return x.getAttribute('aria-selected') === 'true'; })[0] || o[0];
        var t = which === 'last' ? o[o.length - 1] : which === 'first' ? o[0] : cur;
        if (t) { t.focus(); if (t.scrollIntoView) { t.scrollIntoView({ block: 'nearest' }); } }
        edges();
      }
      dd.closeList = closeList;
      lb.addEventListener('click', function () { if (dd.isOpen()) { closeList(false); } else { openList(''); } });
      lb.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); openList(e.key === 'ArrowUp' ? 'last' : ''); }
      });
      list.addEventListener('keydown', function (e) {
        var o = vis(), i = o.indexOf(doc.activeElement), n = o.length, k = e.key, t = null;
        if (!n) { return; }
        if (k === 'ArrowDown') { t = o[(i + 1) % n]; }
        else if (k === 'ArrowUp') { t = o[(i - 1 + n) % n]; }
        else if (k === 'Home') { t = o[0]; }
        else if (k === 'End') { t = o[n - 1]; }
        else if (k === ' ') { e.preventDefault(); if (o[i]) { o[i].click(); } return; }
        else if (k === 'Tab') { closeList(false); return; }
        else if (q && k.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) { q.focus(); return; }   // une lettre tapée sur la liste va dans la recherche
        if (t) { e.preventDefault(); t.focus(); if (t.scrollIntoView) { t.scrollIntoView({ block: 'nearest' }); } }
      });
      if (q) {
        q.addEventListener('input', filter);
        q.addEventListener('keydown', function (e) {
          var o = vis();
          if (e.key === 'ArrowDown' && o.length) { e.preventDefault(); (o.filter(function (x) { return x.getAttribute('aria-selected') === 'true'; })[0] || o[0]).focus(); }
          else if (e.key === 'ArrowUp' && o.length) { e.preventDefault(); o[o.length - 1].focus(); }
          else if (e.key === 'Enter') { e.preventDefault(); if (o[0]) { o[0].click(); } }   // Entrée choisit la première devise trouvée
        });
      }
      box.addEventListener('click', function (e) {
        if (dd.isOpen() && !e.target.closest('#' + listId) && !e.target.closest('#' + btnId) && !(find && e.target.closest('#' + find.id))) { closeList(false); }
      });
      return dd;
    }
    dds.push(wire('prefs-lang-btn', 'prefs-lang-list'), wire('prefs-cur-btn', 'prefs-cur-list'));
    function anyOpen() { return dds.filter(function (d) { return d.isOpen(); })[0]; }
    doc.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') { return; }
      var o = anyOpen();
      if (o) { e.stopPropagation(); e.preventDefault(); o.closeList(true); return; }   // d'abord la sous-liste
      if (box.classList.contains('open')) { btn.focus(); }   // capture : avant la fermeture par app.js
    }, true);
    box.addEventListener('focusout', function (e) {
      var to = e.relatedTarget;
      if (box.classList.contains('open') && to && !box.contains(to)) { box.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); dds.forEach(function (d) { d.closeList(false); }); }
    });
    btn.addEventListener('click', function () { dds.forEach(function (d) { d.closeList(false); }); });
  }

  /* ---------------------------------------------------------------- moteur d'effets */
  var halloween = root.getAttribute('data-theme') === 'halloween';
  var canvasOk = !!(doc.createElement('canvas').getContext) && !!raf;

  var PI2 = Math.PI * 2;
  var state = {
    on: false, running: false, id: 0, last: 0, frame: 0, q: 1, res: 1, tier: 0, slowWin: 0, fx: true, auto: false, accT: 0, accN: 0, slow: 0, ema: 16,
    w: 0, h: 0, dpr: 1, mx: .5, my: .35, smx: .5, smy: .35, sy: 0, vy: 0, lastSy: 0, dark: false, lite: false, lowPower: false, t: 0
  };
  var els = null;          // { box, bg, back, front, bgc, bc, fc }
  var sprites = null;
  var leaves = [], drops = [], splashes = [], sparks = [], bokeh = [], blobs = [];
  var lastSpark = 0;

  function rnd(a, b) { return a + Math.random() * (b - a); }

  function liteMode() {
    var nav = win.navigator || {};
    var conn = nav.connection || {};
    return matches('(max-width: 760px)') || matches('(pointer: coarse)') || conn.saveData === true ||
      (nav.deviceMemory && nav.deviceMemory <= 2) || (nav.hardwareConcurrency && nav.hardwareConcurrency <= 2);
  }

  /* feuilles pré-rendues : 3 formes × 7 teintes d'automne (ambre, rouille, cuivre, bordeaux, or) */
  var LEAF_COLORS = [['#e8873a', '#b4501a'], ['#d4a017', '#9a6a0a'], ['#c8431e', '#8c2410'], ['#9c2f3c', '#601824'], ['#f0b13a', '#c47f12'], ['#b5541c', '#7a3510'], ['#d9692b', '#a03e12']];
  function makeSprites() {
    var out = [];
    for (var k = 0; k < 3; k++) {
      for (var c = 0; c < LEAF_COLORS.length; c++) {
        var cv = doc.createElement('canvas'); cv.width = cv.height = 64;
        var g = cv.getContext('2d');
        g.translate(32, 32);
        var gr = g.createLinearGradient(-26, -26, 26, 26);
        gr.addColorStop(0, LEAF_COLORS[c][0]); gr.addColorStop(1, LEAF_COLORS[c][1]);
        g.fillStyle = gr;
        g.beginPath();
        if (k === 0) {            // érable : cinq lobes
          for (var i = 0; i <= 90; i++) {
            var a = i / 90 * PI2, r = 27 * (0.46 + 0.54 * Math.pow(Math.abs(Math.cos(2.5 * a)), 0.75));
            var x = Math.sin(a) * r, y = -Math.cos(a) * r;
            if (i === 0) { g.moveTo(x, y); } else { g.lineTo(x, y); }
          }
        } else if (k === 1) {     // chêne / hêtre : ovale pointu
          g.moveTo(0, -28); g.bezierCurveTo(24, -16, 24, 16, 0, 28); g.bezierCurveTo(-24, 16, -24, -16, 0, -28);
        } else {                  // bouleau : cœur arrondi
          g.moveTo(0, 26); g.bezierCurveTo(-30, 6, -22, -26, 0, -12); g.bezierCurveTo(22, -26, 30, 6, 0, 26);
        }
        g.closePath(); g.fill();
        g.strokeStyle = 'rgba(60,20,5,.38)'; g.lineWidth = 1.4; g.lineCap = 'round';
        g.beginPath(); g.moveTo(0, 28); g.lineTo(0, -20);
        g.moveTo(0, 10); g.lineTo(-11, -2); g.moveTo(0, 10); g.lineTo(11, -2);
        g.moveTo(0, -2); g.lineTo(-9, -13); g.moveTo(0, -2); g.lineTo(9, -13);
        g.stroke();
        out.push(cv);
      }
    }
    return out;
  }

  /* ---------------------------------------------------------------- création / retrait du décor */
  function build() {
    if (els) { return; }
    var box = doc.createElement('div'); box.className = 'au-fx'; box.setAttribute('aria-hidden', 'true');
    var bg = doc.createElement('canvas');            // fond « vidéo » : dessiné hors écran en basse définition, recopié dans le plan arrière (un seul canvas plein écran en moins)
    var back = doc.createElement('canvas'); back.className = 'au-cv au-cv--back';
    var front = doc.createElement('canvas'); front.className = 'au-cv au-cv--front';
    box.appendChild(back);
    doc.body.appendChild(box);
    doc.body.appendChild(front);
    els = { box: box, bg: bg, back: back, front: front, bgc: bg.getContext('2d'), bc: back.getContext('2d'), fc: front.getContext('2d') };
    if (!sprites) { sprites = makeSprites(); }
    resize();
    populate();
    win.requestAnimationFrame(function () { if (els) { box.classList.add('is-on'); front.classList.add('is-on'); } });
  }
  function teardown() {
    if (!els) { return; }
    if (els.box.parentNode) { els.box.parentNode.removeChild(els.box); }
    if (els.front.parentNode) { els.front.parentNode.removeChild(els.front); }
    els = null; leaves = []; drops = []; splashes = []; sparks = []; bokeh = []; blobs = [];
  }

  function resize() {
    if (!els) { return; }
    var w = win.innerWidth || 1280, h = win.innerHeight || 800;
    state.w = w; state.h = h;
    state.dpr = state.res;                                 // définition des plans de pluie / feuilles : 1 pixel d'écran (puis moins si la machine peine)
    var bgScale = state.lite ? .22 : .32;
    els.bg.width = Math.max(64, Math.round(w * bgScale)); els.bg.height = Math.max(64, Math.round(h * bgScale));
    els.back.width = Math.round(w * state.dpr); els.back.height = Math.round(h * state.dpr);
    els.front.width = Math.round(w * state.res); els.front.height = Math.round(h * state.res);
  }

  function newLeaf(layer, anywhere) {
    var size = layer === 0 ? rnd(10, 16) : layer === 1 ? rnd(18, 28) : rnd(36, 58);
    return {
      layer: layer, s: size, x: rnd(-.1, 1.1) * state.w, y: anywhere ? rnd(-.1, 1) * state.h : -size - rnd(0, state.h * .3),
      vy: (layer === 0 ? rnd(16, 26) : layer === 1 ? rnd(28, 44) : rnd(48, 72)), ph: rnd(0, PI2), fr: rnd(.35, 1) * (layer === 2 ? .8 : 1),
      amp: rnd(14, 46) * (layer + 1) * .55, rot: rnd(0, PI2), vr: rnd(-.7, .7), tum: rnd(0, PI2), vt: rnd(.4, 1.3), vx: 0,
      spr: sprites[(Math.random() * sprites.length) | 0], a: layer === 0 ? .5 : layer === 1 ? .78 : .82
    };
  }
  function newDrop(layer, anywhere) {
    return { layer: layer, x: rnd(-.1, 1.15) * state.w, y: anywhere ? rnd(0, state.h) : -rnd(10, 140),
      v: layer === 0 ? rnd(200, 270) : layer === 1 ? rnd(330, 430) : rnd(500, 650), l: layer === 0 ? rnd(5, 9) : layer === 1 ? rnd(8, 14) : rnd(13, 22) };
  }
  function populate() {
    var f = state.lite ? .45 : 1, i;
    var nl = [Math.round(14 * f), Math.round(16 * f), Math.round(5 * f)];
    var nd = [Math.round(34 * f), Math.round(34 * f), Math.round(9 * f)];
    leaves = []; drops = []; splashes = []; sparks = [];
    for (i = 0; i < 3; i++) { for (var j = 0; j < nl[i]; j++) { leaves.push(newLeaf(i, true)); } }
    for (i = 0; i < 3; i++) { for (var k = 0; k < nd[i]; k++) { drops.push(newDrop(i, true)); } }
    bokeh = [];
    for (i = 0; i < (state.lite ? 10 : 22); i++) { bokeh.push({ x: Math.random(), y: Math.random(), r: rnd(.012, .04), v: rnd(.004, .016), ph: rnd(0, PI2), d: rnd(.3, 1) }); }
    blobs = [
      { x: .12, y: .08, r: .62, fx: .11, fy: .07, ph: 0, l: [255, 176, 80, .30], d: [214, 110, 50, .26], p: .7 },
      { x: .92, y: .22, r: .55, fx: .08, fy: .1, ph: 1.7, l: [200, 80, 40, .17], d: [150, 30, 60, .34], p: 1 },
      { x: .55, y: .95, r: .7, fx: .06, fy: .05, ph: 3.1, l: [255, 214, 120, .34], d: [255, 150, 60, .13], p: .5 },
      { x: .3, y: .62, r: .5, fx: .1, fy: .08, ph: 4.4, l: [150, 40, 70, .11], d: [120, 24, 56, .24], p: 1.2 },
      { x: .8, y: .7, r: .46, fx: .07, fy: .12, ph: 5.2, l: [110, 80, 230, .10], d: [92, 72, 232, .17], p: .8 }
    ];
  }

  /* ---------------------------------------------------------------- dessin */
  function drawBg(t) {
    var c = els.bgc, W = els.bg.width, H = els.bg.height, dk = state.dark, i;
    c.clearRect(0, 0, W, H);
    c.globalCompositeOperation = 'source-over';
    var px = (state.smx - .5), py = (state.smy - .5), sc = state.sy * .00018;
    for (i = 0; i < blobs.length; i++) {
      var b = blobs[i], col = dk ? b.d : b.l;
      var cx = (b.x + Math.sin(t * b.fx + b.ph) * .12 - px * .06 * b.p) * W;
      var cy = (b.y + Math.cos(t * b.fy + b.ph) * .1 - py * .05 * b.p - sc * b.p) * H;
      var r = b.r * Math.max(W, H);
      var g = c.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',' + col[3] + ')');
      g.addColorStop(1, 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',0)');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
    }
    /* rayons de lumière dorée (balancement lent) */
    c.save();
    c.translate(W * (.96 - px * .05), -H * .12);
    var pulse = .8 + .2 * Math.sin(t * .2);
    for (i = 0; i < 4; i++) {
      c.save();
      c.rotate(.5 + i * .16 + Math.sin(t * .09 + i) * .05);
      var gw = W * (.1 + i * .035), gl = H * 1.6;
      var lg = c.createLinearGradient(0, 0, 0, gl);
      var ra = (dk ? .075 : .15) * pulse;
      lg.addColorStop(0, 'rgba(255,214,130,' + ra + ')'); lg.addColorStop(.6, 'rgba(255,190,100,' + ra * .4 + ')'); lg.addColorStop(1, 'rgba(255,190,100,0)');
      c.fillStyle = lg; c.fillRect(-gw / 2, 0, gw, gl);
      c.restore();
    }
    c.restore();
    /* brume basse qui dérive */
    for (i = 0; i < 4; i++) {
      var mx = ((t * (.006 + i * .002) + i * .27) % 1.4 - .2) * W;
      var my = H * (.78 + i * .06) - sc * H * .3;
      var mg = c.createRadialGradient(mx, my, 0, mx, my, W * .5);
      mg.addColorStop(0, dk ? 'rgba(190,140,110,.10)' : 'rgba(255,244,226,.55)'); mg.addColorStop(1, 'rgba(255,244,226,0)');
      c.save(); c.scale(1, .42); c.translate(0, my * (1 / .42 - 1)); c.fillStyle = mg; c.fillRect(0, 0, W, H / .42); c.restore();
    }
    /* bokeh doré */
    for (i = 0; i < bokeh.length; i++) {
      var k = bokeh[i];
      var bx = (k.x + Math.sin(t * .2 + k.ph) * .02 - px * .04 * k.d) * W;
      var by = ((k.y - t * k.v - sc * k.d) % 1.1 + 1.1) % 1.1 * H - H * .05;
      var al = (.5 + .5 * Math.sin(t * .35 + k.ph)) * (dk ? .2 : .27) * k.d;
      var rr = k.r * Math.max(W, H);
      var bg = c.createRadialGradient(bx, by, 0, bx, by, rr);
      bg.addColorStop(0, 'rgba(255,205,110,' + al + ')'); bg.addColorStop(.7, 'rgba(255,170,70,' + al * .5 + ')'); bg.addColorStop(1, 'rgba(255,170,70,0)');
      c.fillStyle = bg; c.fillRect(bx - rr, by - rr, rr * 2, rr * 2);
    }
    /* halo doré qui suit le curseur */
    var hx = state.smx * W, hy = state.smy * H, hr = Math.max(W, H) * .22;
    var hg = c.createRadialGradient(hx, hy, 0, hx, hy, hr);
    hg.addColorStop(0, dk ? 'rgba(255,170,80,.12)' : 'rgba(255,196,110,.22)'); hg.addColorStop(1, 'rgba(255,170,80,0)');
    c.fillStyle = hg; c.fillRect(hx - hr, hy - hr, hr * 2, hr * 2);
  }

  function wind(t, y) { return 20 * Math.sin(t * .22 + y * .003) + 11 * Math.sin(t * .5 + y * .0011) + (state.smx - .5) * 26; }

  function drawLeaf(c, L, scale) {
    var f = Math.cos(L.tum);
    var s = L.s * scale / 64, cr = Math.cos(L.rot) * s, sr = Math.sin(L.rot) * s;
    c.globalAlpha = L.a;
    c.setTransform(cr, sr, -sr * f, cr * f, L.x * scale + 0, L.y * scale);
    c.drawImage(L.spr, -32, -32);
  }

  function drawFx(dt, t) {
    var bc = els.bc, fc = els.fc, i;
    var dk = state.dark, sB = els.back.width / state.w, sF = els.front.width / state.w;
    bc.setTransform(1, 0, 0, 1, 0, 0); bc.clearRect(0, 0, els.back.width, els.back.height);
    bc.globalAlpha = 1; bc.imageSmoothingQuality = 'low'; bc.drawImage(els.bg, 0, 0, els.back.width, els.back.height);
    fc.setTransform(1, 0, 0, 1, 0, 0); fc.clearRect(0, 0, els.front.width, els.front.height);
    if (!state.fx) { return; }
    var swirl = Math.max(-1, Math.min(1, state.vy * .02));          // le défilement fait voler les feuilles
    var mxp = state.mx * state.w, myp = state.my * state.h;
    var nLeaf = Math.round(leaves.length * state.q), nDrop = Math.round(drops.length * state.q);

    /* pluie : traits regroupés par plan (un seul tracé par plan) */
    var rainCol = dk ? '200,214,240' : '92,70,120';
    var layersCtx = [bc, bc, fc], layersScale = [sB, sB, sF], alpha = dk ? [.08, .12, .15] : [.10, .15, .18], lw = [.6, .8, 1];
    for (var ly = 0; ly < 3; ly++) {
      var c2 = layersCtx[ly]; c2.setTransform(layersScale[ly], 0, 0, layersScale[ly], 0, 0);
      c2.strokeStyle = 'rgba(' + rainCol + ',' + alpha[ly] + ')'; c2.lineWidth = lw[ly]; c2.lineCap = 'round'; c2.beginPath();
      for (i = 0; i < nDrop; i++) {
        var d = drops[i]; if (d.layer !== ly) { continue; }
        var wx = wind(t, d.y) * .12 + 14 * (ly + 1);
        d.x += wx * dt * .5; d.y += d.v * dt;
        if (d.y > state.h) {
          if (ly > 0 && splashes.length < 14 && Math.random() < .22) { splashes.push({ x: d.x, y: state.h - rnd(2, 14), r: 1, a: .26, ly: ly }); }
          d.x = rnd(-.1, 1.15) * state.w; d.y = -rnd(10, 120);
        }
        c2.moveTo(d.x, d.y); c2.lineTo(d.x - wx * .5 * d.l / d.v, d.y - d.l);
      }
      c2.stroke();
    }
    /* éclaboussures au bas de l'écran */
    if (splashes.length) {
      fc.setTransform(sF, 0, 0, sF, 0, 0); fc.lineWidth = 1;
      for (i = splashes.length - 1; i >= 0; i--) {
        var sp = splashes[i]; sp.r += 22 * dt; sp.a -= .55 * dt;
        if (sp.a <= 0) { splashes.splice(i, 1); continue; }
        fc.strokeStyle = 'rgba(' + rainCol + ',' + sp.a * .5 + ')'; fc.beginPath(); fc.ellipse(sp.x, sp.y, sp.r, sp.r * .32, 0, 0, PI2); fc.stroke();
      }
    }
    /* feuilles : trois plans (lointain, moyen derrière le contenu ; proche devant) */
    var pr = state.lite ? 0 : 1;
    for (i = 0; i < nLeaf; i++) {
      var L = leaves[i];
      L.ph += L.fr * dt; L.rot += L.vr * dt; L.tum += L.vt * dt;
      var gust = wind(t, L.y) * (.25 + L.layer * .35);
      L.vx += ((gust + swirl * 60 * (L.layer + 1)) - L.vx) * Math.min(1, dt * .9);
      L.x += (L.vx + Math.cos(L.ph) * L.amp * L.fr) * dt;
      L.y += (L.vy - swirl * 30 * (L.layer + 1) + Math.sin(L.ph * 1.3) * 7) * dt;
      if (pr && L.layer === 2) {                                    // les grandes feuilles s'écartent du curseur
        var dx = L.x - mxp, dy = L.y - myp, dd = dx * dx + dy * dy;
        if (dd < 14400 && dd > 1) { var inv = 1 / Math.sqrt(dd); L.x += dx * inv * 50 * dt; L.y += dy * inv * 50 * dt; }
      }
      if (L.y > state.h + L.s || L.x < -L.s * 3 || L.x > state.w + L.s * 3) { var nl = newLeaf(L.layer, false); leaves[i] = nl; continue; }
      if (L.layer === 2) { drawLeaf(fc, L, sF); } else { drawLeaf(bc, L, sB); }
    }
    bc.globalAlpha = 1; fc.globalAlpha = 1;
    /* étincelles dorées au survol des boutons et cartes */
    if (sparks.length) {
      fc.setTransform(sF, 0, 0, sF, 0, 0); fc.globalCompositeOperation = 'lighter';
      for (i = sparks.length - 1; i >= 0; i--) {
        var p = sparks[i]; p.life -= dt; if (p.life <= 0) { sparks.splice(i, 1); continue; }
        p.vy += 260 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        var al = Math.max(0, p.life / p.max);
        fc.fillStyle = 'rgba(255,' + (170 + (p.h | 0)) + ',70,' + al * .9 + ')';
        fc.beginPath(); fc.arc(p.x, p.y, p.r * (.4 + al * .6), 0, PI2); fc.fill();
      }
      fc.globalCompositeOperation = 'source-over';
    }
  }

  function frame(ts) {
    if (!state.running || !els) { return; }
    state.id = raf(frame);
    var raw = state.last ? (ts - state.last) / 1000 : .016, dt = Math.min(.05, raw);
    state.last = ts; state.t += dt; state.frame++;
    /* qualité adaptative, mesurée par fenêtres d'une seconde : moins d'objets, puis moins de pixels, puis fond seul, enfin arrêt (machine très lente) */
    state.accT += raw; state.accN++;
    if (state.accT >= 1.2) {
      var avg = state.accT / state.accN * 1000; state.accT = 0; state.accN = 0;
      /* pas de jugement pendant la mise en route (1,5 s) ; deux fenêtres lentes de suite avant de dégrader ; crochet de test : window.__tpNoAdapt = true */
      if (state.t > 1.5 && avg > 26 && !win.__tpNoAdapt) { state.slowWin++; } else { state.slowWin = 0; }
      if (state.slowWin >= 2) {
        state.slowWin = 0; state.tier++;
        if (state.tier === 1) { state.q = .6; }
        else if (state.tier === 2) { state.q = .4; state.res = .75; resize(); }
        else if (state.tier === 3) { state.res = .5; resize(); }
        else if (state.tier === 4) { state.fx = false; if (els) { els.fc.clearRect(0, 0, els.front.width, els.front.height); } }
        else { state.auto = true; evaluate(); return; }
      }
    }
    state.smx += (state.mx - state.smx) * Math.min(1, dt * 3); state.smy += (state.my - state.smy) * Math.min(1, dt * 3);
    if (state.frame % 2 === 0 || state.frame < 3) { drawBg(state.t); }
    drawFx(dt, state.t);
    state.vy *= Math.max(0, 1 - dt * 4);
  }

  /* ---------------------------------------------------------------- démarrage / arrêt */
  function wanted() { return state.on && !state.auto && !doc.hidden && !state.lowPower && canvasOk && !halloween && !!doc.body; }
  function evaluate() {
    state.dark = root.getAttribute('data-theme') === 'dark';
    if (wanted()) {
      if (state.running) { return; }
      state.lite = liteMode(); state.res = state.lite ? .75 : 1;
      build();
      state.running = true; state.last = 0; state.frame = 0;
      state.id = raf(frame);
    } else {
      if (state.running) { state.running = false; if (state.id) { caf(state.id); } state.id = 0; }
      teardown();
    }
  }
  function readOn() { return root.getAttribute('data-anim') !== 'off'; }
  function onAnim() { state.on = readOn(); state.auto = false; state.tier = 0; state.q = 1; state.fx = true; evaluate(); }

  function bindInput() {
    var tick = false;
    doc.addEventListener('pointermove', function (e) {
      if (!state.running) { return; }
      state.mx = e.clientX / (state.w || 1); state.my = e.clientY / (state.h || 1);
      if (e.pointerType === 'touch' || state.lite) { return; }
      var tg = e.target && e.target.closest ? e.target.closest('.tp-btn, .btn.primary, a.tp-card, .tp-card--feature, .au-anim') : null;
      var now = e.timeStamp;
      if (tg && now - lastSpark > 45 && sparks.length < 90) {
        lastSpark = now;
        for (var i = 0; i < 3; i++) { sparks.push({ x: e.clientX, y: e.clientY, vx: rnd(-90, 90), vy: rnd(-170, -40), life: rnd(.4, .9), max: .9, r: rnd(1, 2.4), h: rnd(0, 70) }); }
      }
    }, { passive: true });
    win.addEventListener('scroll', function () {
      if (tick) { return; }
      tick = true;
      raf(function () { tick = false; var y = win.pageYOffset || 0; state.vy += (y - state.lastSy) * .5; state.lastSy = y; state.sy = y; });
    }, { passive: true });
    var rz = 0;
    win.addEventListener('resize', function () { clearTimeout(rz); rz = setTimeout(function () { if (els) { state.lite = liteMode(); state.res = state.lite ? .75 : 1; resize(); populate(); } }, 160); });
  }

  function watchTheme() {
    if (!win.MutationObserver) { return; }
    new win.MutationObserver(function () { state.dark = root.getAttribute('data-theme') === 'dark'; }).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  }
  function watchBattery() {
    var nav = win.navigator;
    if (!nav || typeof nav.getBattery !== 'function') { return; }
    nav.getBattery().then(function (b) {
      function up() { var low = !b.charging && b.level <= .2; if (low !== state.lowPower) { state.lowPower = low; evaluate(); } }
      up();
      b.addEventListener('levelchange', up); b.addEventListener('chargingchange', up);
    }, function () {});
  }

  function boot() {
    if (halloween || !canvasOk) { return; }
    state.on = readOn();
    bindInput(); watchTheme();
    win.addEventListener('tp:anim', onAnim);
    doc.addEventListener('visibilitychange', evaluate);
    watchBattery();
    evaluate();
  }

  function whenIdle(fn) {
    var go = function () { if (win.requestIdleCallback) { win.requestIdleCallback(fn, { timeout: 1800 }); } else { setTimeout(fn, 400); } };
    if (doc.readyState === 'complete') { go(); } else { win.addEventListener('load', go); }
  }
  function initUi() { initFooter(); initPrefs(); }
  if (doc.readyState === 'loading') { doc.addEventListener('DOMContentLoaded', initUi); } else { initUi(); }
  whenIdle(function () { halloween = root.getAttribute('data-theme') === 'halloween'; boot(); });

  win.tpAutumn = {
    state: state, evaluate: evaluate,
    /* mesure (tests) : vitesses moyennes de chute en px/s, par plan, telles que configurées */
    speeds: function () {
      var r = [0, 0, 0], n = [0, 0, 0], l = [0, 0, 0], m = [0, 0, 0], i;
      for (i = 0; i < drops.length; i++) { r[drops[i].layer] += drops[i].v; n[drops[i].layer]++; }
      for (i = 0; i < leaves.length; i++) { l[leaves[i].layer] += leaves[i].vy; m[leaves[i].layer]++; }
      return { rain: r.map(function (v, k) { return Math.round(v / (n[k] || 1)); }), rainCount: n, leaves: l.map(function (v, k) { return Math.round(v / (m[k] || 1)); }), leafCount: m };
    },
    track: function () { return drops.slice(0, 40).map(function (d) { return [d.layer, d.y]; }); }
  };
})(window, document);
