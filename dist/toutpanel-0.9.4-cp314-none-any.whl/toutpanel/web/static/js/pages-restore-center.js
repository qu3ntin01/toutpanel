(function () {
  'use strict';
  const t = (s, v) => (TP.t ? TP.t(s, v) : s);
  const esc = (s) => TP.esc(s);
  const icon = (n) => TP.icon(n);
  const API = '/api/backups/restore-center';
  const RC = TP.restoreCenter = TP.restoreCenter || {};
  const num = (v) => Number(v) || 0;
  const FINAL = ['ok', 'simulated', 'error', 'cancelled'];
  const alertBox = (cls, ic, html) => '<div class="alert ' + esc(cls) + ' mb" role="' + (cls === 'danger' ? 'alert' : 'note') + '">' + icon(ic) + '<div>' + html + '</div></div>';
  const SK = [90, 71, 52, 83, 64, 75, 58, 87];
  const skel = (n) => '<div class="sk-lines" role="status" aria-busy="true" aria-label="' + esc(t('Chargement…')) + '">' + SK.slice(0, n).map((w) => '<span class="skeleton" style="width:' + Number(w) + '%"></span>').join('') + '</div>';
  const skelCard = () => '<div class="card"><div class="card-b">' + skel(5) + '</div></div>';

  const STATE = () => ({ ok: [t('protégé'), 'ok'], warning: [t('à vérifier'), 'warn'], stale: [t('point trop ancien'), 'warn'], unprotected: [t('non protégé'), 'danger'], failed: [t('sauvegardes en échec'), 'danger'] });
  const JOB = () => ({ queued: [t('en attente'), ''], running: [t('en cours'), 'info'], ok: [t('terminée'), 'ok'], simulated: [t('simulation'), 'info'], error: [t('en échec'), 'danger'], cancelled: [t('annulée'), 'warn'] });
  const STEP = () => ({ extract: t('Lecture du point'), safety: t('Sauvegarde de sécurité'), write: t('Remise en place'), compare: t('Comparaison'), finish: t('Fin') });
  const jobKind = (j) => (j.kind === 'undo' ? t('Retour à l\'état d\'avant') : j.kind === 'dr' ? t('Reprise après sinistre') : j.kind === 'drill' ? t('Test de restaurabilité') : j.mode === 'download' ? t('Téléchargement') : j.simulate ? t('Simulation') : t('Restauration'));
  const jobTarget = (j) => (j.kind === 'drill' && !j.backup_id ? t('points récents') : j.target === 'serveur' || j.scope === 'server' ? t('Serveur') : j.target);

  function alertText(a) {
    const who = a.owner || t('serveur');
    return { repo_unreachable: t('Le dépôt ToutPanel Backup est injoignable : les points distants ne peuvent pas être lus pour l\'instant.'),
      unprotected: t('{o} : aucune sauvegarde. Rien ne pourrait être restauré.', { o: who }), failed: t('{o} : aucune sauvegarde exploitable (partielles ou en échec de vérification).', { o: who }),
      stale: t('{o} : dernier point il y a {n} jour(s).', { o: who, n: num(a.days) }), warning: t('{o} : la sauvegarde la plus récente est partielle ou en échec de vérification.', { o: who }),
      last_restore_failed: t('La dernière restauration a échoué : ouvrez la file d\'attente pour la reprendre.') }[a.code] || a.code;
  }
  function repoBanner(r) {
    const map = { none: ['info', 'info', t('Ce panel n\'est pas relié à un serveur ToutPanel Backup : les points listés viennent des sauvegardes locales et des autres destinations.')],
      checking: ['info', 'refresh', t('Vérification du dépôt ToutPanel Backup en cours…')], ok: ['ok', 'check', t('Dépôt ToutPanel Backup joignable.')],
      unreachable: ['danger', 'alert', t('Dépôt ToutPanel Backup injoignable. Les sauvegardes locales restent restaurables.')] }[r.state] || ['info', 'info', ''];
    return '<div class="rc-repo ' + esc(map[0]) + '" role="' + (r.state === 'unreachable' ? 'alert' : 'status') + '" data-state="' + esc(r.state) + '">' + icon(map[1]) + '<span>' + esc(map[2]) +
      (r.name ? ' <span class="muted">· ' + esc(r.name) + (r.server_version ? ' · ' + esc(t('version {v}', { v: r.server_version })) : '') + '</span>' : '') + '</span></div>';
  }

  TP.registerPage('restore-center', {
    timer: null,
    destroy() { clearTimeout(this.timer); this.timer = null; this.dead = true; },
    async render(root) {
      const self = this; self.dead = false; clearTimeout(self.timer);
      const q = TP.query();
      const ov = (await TP.get(API + '/overview')).data;
      const admin = !!ov.is_admin, caps = ov.caps || {};
      const canRestore = TP.can('backups', 'restore'), canCreate = TP.can('backups', 'create'), canDl = TP.can('backups', 'download');
      const st = { tab: ['protection', 'points', 'queue', 'dr'].includes(q.tab) ? q.tab : 'protection', objects: null, obj: null, points: null, safety: false, jobs: null };
      if (st.tab === 'dr' && !admin) st.tab = 'protection';
      const tabs = [['protection', t('Protection')], ['points', t('Points de restauration')], ['queue', t('File d\'attente')]].concat(admin ? [['dr', t('Reprise et tests')]] : []);
      const T = ov.totals;
      const tile = (k, v, sub, ic) => '<div class="card rc-tile"><div class="stat"><span class="k">' + esc(k) + '<span class="ico">' + icon(ic) + '</span></span><span class="v">' + v + '</span><span class="small muted">' + sub + '</span></div></div>';
      const entry = (id, ic, title, text, cls) => '<button type="button" class="rc-entry ' + cls + '" id="' + id + '"' + (canRestore ? '' : ' disabled') + '><span class="rc-entry-ic">' + icon(ic) + '</span><span class="rc-entry-t"><b>' + esc(title) + '</b><span>' + esc(text) + '</span></span><span class="rc-entry-go" aria-hidden="true">' + icon('chevron') + '</span></button>';
      root.innerHTML = TP.pageHead(t('Centre de restauration'), t('Retrouvez un fichier, une base, un site, un compte ou le serveur entier dans l\'état d\'un point de restauration.'),
        admin ? '<a class="btn" id="rc-sheet" href="' + API + '/dr/sheet?fmt=text" download>' + icon('download') + esc(t('Fiche de reprise')) + '</a>' : '') +
        repoBanner(ov.repo) +
        '<div class="rc-entries' + (admin ? '' : ' two') + '">' +
        entry('rc-e-item', 'file', t('Restaurer un élément'), t('Un fichier, un dossier, une base, une table ou une boîte mail.'), 'a') +
        entry('rc-e-full', 'globe', t('Restaurer un compte ou un site complet'), t('Tout remettre dans l\'état d\'un point : fichiers, bases et courrier.'), 'b') +
        (admin ? entry('rc-e-dr', 'hdd', t('Reprise après sinistre'), t('Reconstruire le serveur complet sur une machine neuve.'), 'c') : '') + '</div>' +
        '<div class="rc-tiles">' +
        tile(t('Comptes protégés'), num(T.protected) + '<small>/ ' + num(T.accounts) + '</small>', num(T.unprotected) ? esc(t('{n} sans sauvegarde', { n: num(T.unprotected) })) : num(T.stale) ? esc(t('{n} avec un point trop ancien', { n: num(T.stale) })) : esc(t('aucun compte sans sauvegarde')), 'shield') +
        tile(t('Points disponibles'), String(num(T.points)), esc(t('{n} épinglé(s) · {s}', { n: num(T.pinned), s: TP.fmtBytes(T.size) })), 'backup') +
        tile(t('Dernier point'), T.last_point_at ? esc(TP.fmtDate(T.last_point_at)) : esc(t('aucun')), esc(t('{n} point(s) vérifié(s)', { n: num(T.verified) })), 'clock') +
        tile(t('Prochaine sauvegarde'), T.next_run ? esc(TP.fmtDate(T.next_run)) : esc(t('non planifiée')), T.next_run ? esc(t('selon vos planifications')) : '<a href="#/backups">' + esc(t('Planifier une sauvegarde')) + '</a>', 'activity') + '</div>' +
        (ov.alerts.length ? '<div class="card rc-alerts"><div class="card-h"><h3>' + esc(t('À traiter')) + ' <span class="rc-count">' + ov.alerts.length + '</span></h3></div><ul>' + ov.alerts.slice(0, 8).map((a) => '<li class="' + esc(a.level) + '">' + icon('alert') + '<span>' + esc(alertText(a)) + '</span></li>').join('') +
          (ov.alerts.length > 8 ? '<li class="more small muted">' + esc(t('et {n} autre(s) : voir l\'onglet Protection', { n: ov.alerts.length - 8 })) + '</li>' : '') + '</ul></div>' : '') +
        '<div class="tabs rc-tabs" role="tablist" aria-label="' + esc(t('Centre de restauration')) + '">' + tabs.map((x) => '<button type="button" role="tab" id="rc-tab-' + esc(x[0]) + '" aria-controls="rc-pane" aria-selected="' + (x[0] === st.tab ? 'true' : 'false') + '" tabindex="' + (x[0] === st.tab ? '0' : '-1') + '" data-tab="' + esc(x[0]) + '"' + (x[0] === st.tab ? ' class="active"' : '') + '>' + esc(x[1]) +
          (x[0] === 'queue' && num(ov.queue.running) ? ' <span class="rc-count">' + num(ov.queue.running) + '</span>' : '') + '</button>').join('') + '</div>' +
        '<div id="rc-pane" role="tabpanel" tabindex="0" aria-labelledby="rc-tab-' + esc(st.tab) + '"></div>';
      const pane = TP.qs('#rc-pane', root);
      const openWizard = (o) => RC.openWizard(Object.assign({ onDone: (jid) => { if (jid) { st.jobs = null; show('queue'); } } }, o || {}));
      const ei = TP.qs('#rc-e-item', root), ef = TP.qs('#rc-e-full', root), ed = TP.qs('#rc-e-dr', root);
      if (ei) ei.onclick = () => openWizard({ intent: 'item' });
      if (ef) ef.onclick = () => openWizard({ intent: 'full' });
      if (ed) ed.onclick = () => RC.openDisaster({ onDone: () => { st.jobs = null; } });

      function paneProtection() {
        const S = STATE();
        if (!ov.accounts.length) return '<div class="card">' + TP.empty(t('Rien à protéger pour l\'instant : créez un site, une base ou une boîte mail.'), 'shield') + '</div>';
        return '<div class="card"><div class="card-h"><h3>' + esc(t('Protection par compte')) + '<span class="sub">' + esc(t('Alerte quand le dernier point a plus de {n} jour(s).', { n: num(ov.stale_days) })) + '</span></h3></div>' +
          '<div class="table-wrap"><table class="tbl rc-tbl"><thead><tr><th scope="col">' + esc(t('Compte')) + '</th><th scope="col">' + esc(t('État')) + '</th><th scope="col">' + esc(t('Dernière sauvegarde réussie')) + '</th><th scope="col" class="r">' + esc(t('Taille')) + '</th>' +
          '<th scope="col">' + esc(t('Prochaine')) + '</th><th scope="col" class="r">' + esc(t('Points')) + '</th><th scope="col">' + esc(t('Vérifié le')) + '</th></tr></thead><tbody>' +
          ov.accounts.map((a) => { const s = S[a.state] || [a.state, '']; return '<tr><th scope="row" data-l="' + esc(t('Compte')) + '"><b>' + esc(a.is_server ? t('Administrateur et serveur') : a.owner) + '</b><div class="small muted">' + esc(t('{n} objet(s)', { n: num(a.objects) })) + '</div></th>' +
            '<td data-l="' + esc(t('État')) + '">' + TP.badge(s[0], esc(s[1])) + '</td>' +
            '<td data-l="' + esc(t('Dernière sauvegarde réussie')) + '">' + (a.last_ok_at ? esc(TP.fmtDate(a.last_ok_at)) + '<div class="small muted">' + esc(t('il y a {a}', { a: RC.age(a.age_hours) })) + (a.via_server ? ' · ' + esc(t('dans un point du serveur')) : '') + '</div>' : '<span class="muted">' + esc(t('jamais')) + '</span>') + '</td>' +
            '<td class="r" data-l="' + esc(t('Taille')) + '">' + (a.size ? esc(TP.fmtBytes(a.size)) : '<span class="muted">—</span>') + '</td>' +
            '<td data-l="' + esc(t('Prochaine')) + '">' + (a.next_run ? esc(TP.fmtDate(a.next_run)) : '<span class="muted">' + esc(t('non planifiée')) + '</span>') + '</td>' +
            '<td class="r" data-l="' + esc(t('Points')) + '">' + num(a.points) + (num(a.pinned) ? ' <span class="small muted">(' + esc(t('{n} épinglé(s)', { n: num(a.pinned) })) + ')</span>' : '') + '</td>' +
            '<td data-l="' + esc(t('Vérifié le')) + '">' + (a.verified_at ? esc(TP.fmtDate(a.verified_at)) : '<span class="muted">' + esc(t('jamais')) + '</span>') + '</td></tr>'; }).join('') + '</tbody></table></div></div>';
      }

      function panePoints() {
        const objs = st.objects;
        const sel = objs === null ? skel(2) : '<div class="rc-pick"><div class="as-field"><label for="rc-obj">' + esc(t('Objet')) + '</label><select class="input" id="rc-obj">' +
          ['site', 'database', 'mail_domain', 'mailbox', 'account', 'server'].map((k) => { const l = objs.filter((o) => o.kind === k); return l.length ? '<optgroup label="' + esc(RC.kindLabel(k)) + '">' + l.map((o) => '<option value="' + esc(o.kind + ':' + o.ref) + '"' + (st.obj && st.obj.kind === o.kind && st.obj.ref === o.ref ? ' selected' : '') + '>' + esc(RC.objLabel(o)) + (o.owner ? ' · ' + esc(o.owner) : '') + ' (' + num(o.points) + ')</option>').join('') + '</optgroup>' : ''; }).join('') + '</select></div>' +
          '<label class="rc-line rc-safety"><input type="checkbox" id="rc-safety"' + (st.safety ? ' checked' : '') + '><span>' + esc(t('Afficher aussi les sauvegardes de sécurité')) + '</span></label>' +
          (canCreate && st.obj && st.obj.kind !== 'server' ? '<button type="button" class="btn primary" id="rc-new">' + icon('plus') + esc(t('Créer un point maintenant')) + '</button>' : '') + '</div>';
        let list;
        if (objs !== null && !objs.length) list = TP.empty(t('Rien à restaurer pour l\'instant : aucun site, base ou boîte dans votre compte.'), 'backup');
        else if (st.points === null) list = '<div class="card-b">' + skel(5) + '</div>';
        else if (!st.points.length) list = TP.empty(t('Aucun point de restauration pour cet objet.'), 'backup');
        else list = '<div class="table-wrap"><table class="tbl rc-tbl"><thead><tr><th scope="col">' + esc(t('Point')) + '</th><th scope="col">' + esc(t('Type et dépôt')) + '</th><th scope="col" class="r">' + esc(t('Taille')) + '</th><th scope="col">' + esc(t('Vérification')) + '</th><th scope="col"><span class="sr-only">' + esc(t('Actions')) + '</span></th></tr></thead><tbody>' +
          st.points.map((p) => '<tr data-id="' + num(p.id) + '"><th scope="row" data-l="' + esc(t('Point')) + '"><b>' + esc(TP.fmtDate(p.time)) + '</b>' + (p.label ? ' <span class="rc-label">' + esc(p.label) + '</span>' : '') + (p.note ? '<div class="small muted">' + esc(p.note) + '</div>' : '') + '</th>' +
            '<td data-l="' + esc(t('Type et dépôt')) + '"><span class="rc-pt-b">' + RC.pointBadges(p) + '</span><div class="small muted">' + esc(RC.destLabel(p.dest)) + '</div></td><td class="r" data-l="' + esc(t('Taille')) + '">' + esc(TP.fmtBytes(p.size)) + '</td>' +
            '<td data-l="' + esc(t('Vérification')) + '">' + RC.verifiedBadge(p.verified) + (p.verified.at ? '<div class="small muted">' + esc(TP.fmtDate(p.verified.at)) + '</div>' : '') + '</td>' +
            '<td class="r"><div class="actions">' + (canRestore ? '<button type="button" class="btn sm" data-a="restore" data-id="' + num(p.id) + '">' + icon('refresh') + esc(t('Restaurer…')) + '</button>' : '') +
            (canCreate ? '<button type="button" class="btn ghost sm icon" data-a="pin" data-id="' + num(p.id) + '" aria-pressed="' + (p.pinned ? 'true' : 'false') + '" title="' + esc(p.pinned ? t('Désépingler : la rotation pourra supprimer ce point') : t('Épingler : aucune rotation ne supprimera ce point')) + '" aria-label="' + esc(p.pinned ? t('Désépingler') : t('Épingler')) + '">' + icon('star') + '</button>' +
              '<button type="button" class="btn ghost sm icon" data-a="label" data-id="' + num(p.id) + '" title="' + esc(t('Étiquette')) + '" aria-label="' + esc(t('Étiquette')) + '">' + icon('tag') + '</button>' : '') +
            (canDl && (admin || !['server', 'account'].includes(p.scope)) ? '<button type="button" class="btn ghost sm icon" data-a="dl" data-id="' + num(p.id) + '" title="' + esc(t('Télécharger une archive')) + '" aria-label="' + esc(t('Télécharger une archive')) + '">' + icon('download') + '</button>' : '') +
            (admin ? '<button type="button" class="btn ghost sm icon" data-a="drill" data-id="' + num(p.id) + '" title="' + esc(t('Tester la restaurabilité de ce point')) + '" aria-label="' + esc(t('Tester la restaurabilité de ce point')) + '">' + icon('shield') + '</button>' : '') + '</div></td></tr>').join('') + '</tbody></table></div>';
        return '<div class="card"><div class="card-b">' + sel + '</div>' + list + '</div>';
      }
      async function loadObjects() {
        st.objects = (await TP.get(API + '/objects')).data.objects;
        if (!st.obj) st.obj = st.objects.find((o) => q.kind && o.kind === q.kind && String(o.ref) === String(q.ref)) || st.objects.find((o) => o.points) || st.objects[0] || null;
      }
      async function loadPoints() {
        st.points = null; if (st.tab === 'points') paint();
        if (!st.obj) { st.points = []; return; }
        try { st.points = (await TP.get(API + '/points?kind=' + encodeURIComponent(st.obj.kind) + '&ref=' + encodeURIComponent(st.obj.ref) + (st.safety ? '&safety=true' : ''))).data.points; }
        catch (e) { st.points = []; TP.toast(e.message, 'error'); }
      }
      function bindPoints() {
        const o = TP.qs('#rc-obj', pane);
        if (o) o.onchange = async () => { const [k, ref] = o.value.split(':'); st.obj = st.objects.find((x) => x.kind === k && x.ref === ref); await loadPoints(); if (st.tab === 'points') paint(); };
        const sf = TP.qs('#rc-safety', pane); if (sf) sf.onchange = async () => { st.safety = sf.checked; await loadPoints(); if (st.tab === 'points') paint(); };
        const nw = TP.qs('#rc-new', pane);
        if (nw) nw.onclick = () => TP.modal({ title: t('Créer un point maintenant') + ' · ' + RC.objLabel(st.obj), okText: t('Créer le point'),
          body: '<div class="form"><div class="as-field"><label for="rc-nl">' + esc(t('Étiquette (facultative)')) + '</label><div class="hint" id="rc-nl-h">' + esc(t('Par exemple « avant la mise à jour ». 60 caractères au plus.')) + '</div><input class="input" id="rc-nl" maxlength="60" aria-describedby="rc-nl-h"></div>' +
            '<label class="rc-line"><input type="checkbox" id="rc-np"><span><b>' + esc(t('Épingler ce point')) + '</b><span class="small muted">' + esc(t('Aucune rotation ne le supprimera, tant qu\'il reste épinglé.')) + '</span></span></label></div>',
          onOk: async (bg) => {
            const r = await TP.post(API + '/points', { kind: st.obj.kind, ref: st.obj.ref, label: TP.qs('#rc-nl', bg).value, pin: TP.qs('#rc-np', bg).checked });
            TP.taskTerminal(r.data.task_id, t('Point de restauration') + ' · ' + RC.objLabel(st.obj), async () => { await loadPoints(); if (!self.dead && st.tab === 'points') paint(); });
          } });
        const byId = (id) => (st.points || []).find((p) => p.id === Number(id));
        TP.qsa('[data-a]', pane).forEach((b) => b.onclick = async () => {
          const p = byId(b.dataset.id); if (!p) return;
          const act = b.dataset.a;
          try {
            if (act === 'restore') openWizard({ intent: ['account'].includes(st.obj.kind) ? 'full' : 'item', kind: st.obj.kind, ref: st.obj.ref, point: p.id });
            else if (act === 'pin') { await TP.put(API + '/points/' + num(p.id), { pinned: !p.pinned }); TP.toast(p.pinned ? t('Point désépinglé') : t('Point épinglé : aucune rotation ne le supprimera')); await loadPoints(); if (!self.dead && st.tab === 'points') paint(); }
            else if (act === 'label') { const v = await TP.prompt(t('Étiquette'), t('Étiquette de ce point (vide pour l\'effacer)'), p.label || ''); if (v === null || v === undefined) return; await TP.put(API + '/points/' + num(p.id), { label: v }); await loadPoints(); if (!self.dead && st.tab === 'points') paint(); }
            else if (act === 'dl') { TP.btnLoading(b, true); try { await RC.download(p.id, p.prefix ? [p.prefix] : []); } finally { TP.btnLoading(b, false); } }
            else if (act === 'drill') { const r = await TP.post(API + '/drill/run', { backup_id: p.id }); TP.toast(r.msg); st.jobs = null; show('queue'); }
          } catch (e) { TP.toast(e.message, 'error'); }
        });
      }

      function jobRow(j) {
        const J = JOB(), s = J[j.status] || [j.status, ''];
        const live = !FINAL.includes(j.status);
        const sum = j.summary || {};
        const res = j.status === 'ok' && j.kind === 'restore' && j.mode !== 'download' ? t('{n} fichier(s)', { n: num(sum.files) }) + (sum.databases && sum.databases.length ? ' · ' + t('{n} base(s)', { n: sum.databases.length }) : '') : j.message || '';
        return '<tr data-job="' + num(j.id) + '"><th scope="row" data-l="' + esc(t('Quoi')) + '"><b>' + esc(jobTarget(j)) + '</b><div class="small muted">' + esc(jobKind(j)) + (j.undone_by ? ' · ' + esc(t('annulée ensuite')) : '') + '</div></th>' +
          '<td data-l="' + esc(t('État')) + '">' + TP.badge(s[0], esc(s[1])) + (live ? '<div class="rc-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + num(j.progress) + '" aria-label="' + esc(t('Avancement')) + '"><i style="width:' + Math.max(3, Math.min(100, num(j.progress))) + '%"></i></div>' : res ? '<div class="small muted rc-res">' + esc(res) + '</div>' : '') + '</td>' +
          '<td data-l="' + esc(t('Qui')) + '">' + esc(j.actor || '—') + '</td><td data-l="' + esc(t('Quand')) + '">' + esc(TP.fmtDate(j.created_at)) + '</td>' +
          '<td class="r"><div class="actions"><button type="button" class="btn ghost sm" data-j="open" data-id="' + num(j.id) + '">' + esc(t('Détails')) + '</button>' +
          (canRestore && j.cancellable ? '<button type="button" class="btn sm" data-j="cancel" data-id="' + num(j.id) + '">' + icon('stop') + esc(t('Annuler')) + '</button>' : '') +
          (canRestore && j.resumable ? '<button type="button" class="btn sm" data-j="resume" data-id="' + num(j.id) + '">' + icon('play') + esc(t('Reprendre')) + '</button>' : '') +
          (canRestore && j.undoable ? '<button type="button" class="btn sm" data-j="undo" data-id="' + num(j.id) + '">' + icon('refresh') + esc(t('Annuler cette restauration')) + '</button>' : '') + '</div></td></tr>';
      }
      function paneQueue() {
        if (st.jobs === null) return skelCard();
        if (!st.jobs.length) return '<div class="card">' + TP.empty(t('Aucune restauration pour l\'instant. Les restaurations lancées apparaîtront ici, avec leur avancement.'), 'clock') + '</div>';
        return '<div class="card"><div class="card-h"><h3>' + esc(t('Restaurations en cours et historique')) + '<span class="sub">' + esc(t('Qui a restauré quoi, quand, et avec quel résultat.')) + '</span></h3></div>' +
          '<div class="table-wrap"><table class="tbl rc-tbl"><thead><tr><th scope="col">' + esc(t('Quoi')) + '</th><th scope="col">' + esc(t('État')) + '</th><th scope="col">' + esc(t('Qui')) + '</th><th scope="col">' + esc(t('Quand')) + '</th><th scope="col"><span class="sr-only">' + esc(t('Actions')) + '</span></th></tr></thead>' +
          '<tbody id="rc-jobs">' + st.jobs.map((j) => jobRow(j)).join('') + '</tbody></table></div></div>';
      }
      async function loadJobs() { try { st.jobs = (await TP.get(API + '/restores?limit=100')).data.jobs; } catch (e) { st.jobs = st.jobs || []; } }
      function poll() {
        clearTimeout(self.timer);
        if (self.dead || st.tab !== 'queue') return;
        const live = (st.jobs || []).some((j) => !FINAL.includes(j.status));
        self.timer = setTimeout(async () => {
          if (self.dead || st.tab !== 'queue' || document.hidden) { poll(); return; }
          const before = JSON.stringify((st.jobs || []).map((j) => [j.id, j.status, j.progress, j.undoable, j.resumable]));
          await loadJobs();
          if (self.dead || st.tab !== 'queue') return;
          if (JSON.stringify(st.jobs.map((j) => [j.id, j.status, j.progress, j.undoable, j.resumable])) !== before && !TP.qs('.modal-bg')) {
            const done = st.jobs.filter((j) => FINAL.includes(j.status)).length;
            paint();
            if (live && !st.jobs.some((j) => !FINAL.includes(j.status)) && done) TP.announce(t('Restauration terminée'));
          }
          poll();
        }, live ? 1500 : 8000);
      }
      async function askPassword(title, text) {
        return new Promise((resolve) => {
          let done = false;
          TP.modal({ title, okText: t('Confirmer'), body: '<div class="form"><p>' + esc(text) + '</p><div class="as-field"><label for="rc-pw">' + esc(t('Votre mot de passe, pour confirmer')) + '</label><input class="input" id="rc-pw" type="password" autocomplete="current-password"></div></div>',
            onOk: (bg) => { done = true; resolve(TP.qs('#rc-pw', bg).value); }, onClose: () => { if (!done) resolve(null); } });
        });
      }
      function openJob(id) {
        const m = TP.modal({ title: t('Restauration') + ' #' + num(id), size: 'lg', body: '<div id="rc-jd">' + skel(6) + '</div>', footer: '<button type="button" class="btn primary" data-close>' + esc(t('Fermer')) + '</button>' });
        const box = TP.qs('#rc-jd', m.el), S = STEP(), J = JOB();
        const draw = (d) => {
          const s = J[d.status] || [d.status, ''], rep = d.report || {};
          const els = rep.elements || [];
          const res = rep.results || [];
          box.innerHTML = '<div class="rc-jh"><div><b>' + esc(jobTarget(d)) + '</b> <span class="muted">· ' + esc(jobKind(d)) + '</span><div class="small muted">' + esc(t('lancée par {u} le {d}', { u: d.actor || '?', d: TP.fmtDate(d.created_at) })) + (d.finished_at ? ' · ' + esc(t('finie le {d}', { d: TP.fmtDate(d.finished_at) })) : '') + '</div></div>' + TP.badge(s[0], esc(s[1])) + '</div>' +
            (d.kind === 'restore' || d.kind === 'undo' ? '<ol class="rc-steps">' + d.steps.map((x) => '<li class="' + esc(x.state) + '"><i></i><span>' + esc(S[x.key] || x.key) + '</span></li>').join('') + '</ol>' : '') +
            (!FINAL.includes(d.status) ? '<div class="rc-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + num(d.progress) + '" aria-label="' + esc(t('Avancement')) + '"><i style="width:' + Math.max(3, Math.min(100, num(d.progress))) + '%"></i></div>' : '') +
            (d.message ? alertBox(d.status === 'error' ? 'danger' : 'info', d.status === 'error' ? 'alert' : 'info', esc(d.message)) : '') +
            (d.kind === 'restore' && FINAL.includes(d.status) && d.mode !== 'download' ? '<div class="rc-sum"><span class="rc-chip ok">' + esc(t('{n} créé(s)', { n: num(rep.created) })) + '</span><span class="rc-chip warn">' + esc(t('{n} remplacé(s)', { n: num(rep.replaced) })) + '</span>' +
              (num(rep.unchanged) ? '<span class="rc-chip">' + esc(t('{n} identique(s)', { n: num(rep.unchanged) })) + '</span>' : '') + (num(rep.kept_existing) ? '<span class="rc-chip">' + esc(t('{n} déjà présent(s), gardé(s)', { n: num(rep.kept_existing) })) + '</span>' : '') +
              ((rep.databases || []).length ? '<span class="rc-chip info">' + esc(t('base(s)')) + ' : ' + esc(rep.databases.join(', ')) + '</span>' : '') + '</div>' : '') +
            (d.safety.length ? '<p class="small">' + icon('shield') + ' ' + esc(t('Sauvegarde de sécurité prise avant l\'écrasement : {l}', { l: d.safety.map((i) => '#' + num(i)).join(', ') })) + (d.undoable ? '' : ' <span class="muted">· ' + esc(d.undone_by ? t('restauration déjà annulée') : t('elle n\'existe plus : retour en arrière impossible')) + '</span>') + '</p>' : '') +
            (els.length ? '<ul class="rc-changes">' + els.map((e) => '<li><span class="rc-chip">' + esc(e.status) + '</span><span class="small">' + esc(e.key) + (e.reason ? ' · ' + esc(t(e.reason)) : '') + '</span></li>').join('') + '</ul>' : '') +
            (res.length ? '<ul class="rc-changes">' + res.map((e) => '<li><span class="rc-chip ' + (e.ok ? 'ok' : 'danger') + '">' + esc(e.ok ? t('restaurable') : t('en échec')) + '</span><span class="small">#' + num(e.id) + ' ' + esc(e.target) + (e.message ? ' · ' + esc(e.message) : '') + '</span></li>').join('') + '</ul>' : '') +
            ((rep.changes || []).length ? '<details class="rc-proc"><summary>' + esc(t('Ce qui changerait ({n})', { n: rep.changes.length })) + '</summary><ul class="rc-changes">' + rep.changes.slice(0, 200).map((c) => '<li><span class="rc-chip ' + (c.action === 'create' ? 'ok' : 'warn') + '">' + esc(c.action === 'create' ? t('créé') : c.action === 'kept' ? t('conservé') : t('remplacé')) + '</span><span class="mono small">' + esc(c.path) + '</span></li>').join('') + '</ul></details>' : '') +
            '<details class="rc-proc"' + (FINAL.includes(d.status) ? '' : ' open') + '><summary>' + esc(t('Journal')) + '</summary><pre class="pre rc-log" tabindex="0">' + esc(d.log || t('Journal vide')) + '</pre></details>';
        };
        RC.waitJob(id, draw, () => document.contains(m.el)).then(async () => { await loadJobs(); if (!self.dead && st.tab === 'queue' && !TP.qs('.modal-bg .assist-bg')) paint(); }).catch((e) => { box.innerHTML = alertBox('danger', 'alert', esc(e.message)); });
      }
      function bindQueue() {
        TP.qsa('[data-j]', pane).forEach((b) => b.onclick = async () => {
          const id = Number(b.dataset.id), act = b.dataset.j, j = (st.jobs || []).find((x) => x.id === id);
          try {
            if (act === 'open') { openJob(id); return; }
            if (act === 'cancel') { if (!await TP.confirm(t('Annuler la restauration'), t('La restauration s\'arrête entre deux fichiers. Ce qui a déjà été remis en place le reste ; la sauvegarde de sécurité permet de revenir en arrière.'), { danger: true })) return; const r = await TP.post(API + '/restores/' + id + '/cancel'); TP.toast(r.msg); }
            if (act === 'resume') {
              const destr = j && !j.simulate && (j.mode === 'inplace' || j.kind === 'dr');
              const pw = destr ? await askPassword(t('Reprendre la restauration'), t('La restauration reprend avec les mêmes choix. Une nouvelle sauvegarde de sécurité est prise avant tout remplacement.')) : '';
              if (pw === null) return;
              const r = await TP.post(API + '/restores/' + id + '/resume', { password: pw }); TP.toast(r.msg);
            }
            if (act === 'undo') {
              const pw = await askPassword(t('Annuler cette restauration'), t('L\'état d\'avant la restauration est remis en place, à partir de la sauvegarde de sécurité prise juste avant.'));
              if (pw === null) return;
              const r = await TP.post(API + '/restores/' + id + '/undo', { password: pw }); TP.toast(r.msg);
            }
            await loadJobs(); if (!self.dead && st.tab === 'queue') paint();
          } catch (e) { TP.toast(e.message, 'error'); }
        });
        poll();
      }

      function paneDr() {
        const d = st.drill || ov.drill || { schedule: 'off', points: 3, last: null };
        const off = true, ready = !!caps.server_publish;
        return '<div class="grid g2 rc-dr-grid"><div class="card"><div class="card-h"><h3>' + esc(t('Reprise après sinistre')) + '</h3></div><div class="card-b"><p>' + esc(t('Sur un serveur neuf : choisissez le serveur sauvegardé, un point, vérifiez les prérequis, puis reprenez dans l\'ordre. La reprise se relance sans refaire ce qui a réussi.')) + '</p>' +
          '<div class="rc-row"><button type="button" class="btn primary" id="rc-dr-open">' + icon('hdd') + esc(t('Ouvrir l\'assistant de reprise')) + '</button></div></div></div>' +
          '<div class="card"><div class="card-h"><h3>' + esc(t('Fiche de reprise')) + '</h3></div><div class="card-b"><p>' + esc(t('Ce qu\'il faut avoir sous la main le jour du sinistre : adresse du serveur ToutPanel Backup, identifiant du dépôt, empreinte, et l\'endroit où se trouve la clé de chiffrement. La clé elle-même n\'y figure jamais.')) + '</p>' +
          '<div class="rc-row"><a class="btn" href="' + API + '/dr/sheet?fmt=text" download>' + icon('download') + esc(t('Télécharger la fiche')) + '</a><button type="button" class="btn" id="rc-sheet-print">' + icon('file') + esc(t('Afficher et imprimer')) + '</button></div></div></div>' +
          '<div class="card"><div class="card-h"><h3>' + esc(t('Test de restaurabilité')) + '<span class="sub">' + esc(t('Une sauvegarde n\'est sûre que si elle se restaure.')) + '</span></h3></div><div class="card-b"><p>' + esc(t('Un échantillon de chaque point testé est restauré dans un bac à sable temporaire : fichiers contrôlés, bases ouvertes. Le point est alors marqué « restauration testée ». Le test tourne en priorité basse (processeur et disque).')) + '</p>' +
          '<div class="rc-form"><div class="as-field"><label for="rc-dsch">' + esc(t('Fréquence')) + '</label><select class="input" id="rc-dsch">' + [['off', t('Désactivé')], ['daily', t('Chaque nuit')], ['weekly', t('Chaque dimanche')], ['monthly', t('Le 1er du mois')]].map((o) => '<option value="' + esc(o[0]) + '"' + (d.schedule === o[0] ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select></div>' +
          '<div class="as-field"><label for="rc-dn">' + esc(t('Points testés à chaque passage')) + '</label><input class="input" id="rc-dn" type="number" min="1" max="20" value="' + num(d.points) + '"></div></div>' +
          '<div class="rc-row"><button type="button" class="btn primary" id="rc-dsave">' + esc(t('Enregistrer')) + '</button><button type="button" class="btn" id="rc-drun">' + icon('play') + esc(t('Tester maintenant')) + '</button></div>' +
          '<p class="small muted" id="rc-dlast">' + (d.last ? esc(t('Dernier passage le {d} : {n} point(s) testé(s), {f} en échec.', { d: TP.fmtDate(d.last.at), n: num(d.last.tested), f: num(d.last.failed) })) : esc(t('Aucun test n\'a encore été fait.'))) + '</p></div></div>' +
          '<div class="card"><div class="card-h"><h3>' + esc(t('Réécriture DNS après un changement d\'adresse')) + '</h3></div><div class="card-b"><p>' + esc(t('Si le serveur neuf n\'a pas la même adresse IP, remplacez l\'ancienne par la nouvelle dans les enregistrements A et AAAA de vos zones.')) + '</p>' +
          '<div class="rc-form"><div class="as-field"><label for="rc-rold">' + esc(t('Ancienne adresse')) + '</label><input class="input mono" id="rc-rold" autocomplete="off"></div><div class="as-field"><label for="rc-rnew">' + esc(t('Nouvelle adresse')) + '</label><input class="input mono" id="rc-rnew" autocomplete="off"></div></div>' +
          '<div class="rc-row"><button type="button" class="btn" id="rc-rprev">' + icon('search') + esc(t('Voir ce qui changerait')) + '</button><button type="button" class="btn danger" id="rc-rgo" disabled>' + esc(t('Appliquer')) + '</button></div><div id="rc-rout" role="status"></div></div></div>' +
          '<div class="card rc-soon' + (off ? ' off' : '') + '"' + (off ? ' aria-disabled="true"' : '') + '><div class="card-h"><h3>' + esc(t('Publication sur le serveur ToutPanel Backup')) + '</h3>' + '<span class="rc-chip">' + icon('lock') + esc(t('nécessite ToutPanel Backup ≥ {v}', { v: caps.server_publish_min || '1.4' })) + '</span>' + '</div>' +
          '<div class="card-b"><p>' + esc(t('Afficher dans la console du serveur de sauvegarde les points épinglés, leurs étiquettes et l\'état « restauration testée », et les faire respecter par ses propres règles de rétention.')) + '</p>' +
          '<p class="small muted">' + esc(ready ? t('Le serveur relié annonce cette fonction ; son branchement dans le panel arrivera avec une prochaine version de ToutPanel.') : caps.tpb_linked ? t('Le serveur relié ne propose pas encore cette fonction. Dans ce panel, épingles et tests fonctionnent déjà : ils ne sont simplement pas visibles depuis la console du serveur.') : t('Ce panel n\'est pas relié à un serveur ToutPanel Backup.')) + '</p></div></div></div>';
      }
      function bindDr() {
        TP.qs('#rc-dr-open', pane).onclick = () => RC.openDisaster({ onDone: () => { st.jobs = null; } });
        TP.qs('#rc-dsave', pane).onclick = async () => { try { const r = await TP.put(API + '/drill', { schedule: TP.qs('#rc-dsch', pane).value, points: num(TP.qs('#rc-dn', pane).value) || 3 }); st.drill = r.data; TP.toast(r.msg); } catch (e) { TP.toast(e.message, 'error'); } };
        TP.qs('#rc-drun', pane).onclick = async () => { try { const r = await TP.post(API + '/drill/run', {}); TP.toast(r.msg); st.jobs = null; show('queue'); } catch (e) { TP.toast(e.message, 'error'); } };
        TP.qs('#rc-sheet-print', pane).onclick = async () => {
          try {
            const res = await fetch(API + '/dr/sheet?fmt=text', { credentials: 'same-origin', headers: { 'X-Requested-With': 'ToutPanel' } });
            const txt = await res.text();
            const m = TP.modal({ title: t('Fiche de reprise'), size: 'lg', body: '<pre class="pre rc-sheet" tabindex="0">' + esc(txt) + '</pre>', footer: '<button type="button" class="btn" data-close>' + esc(t('Fermer')) + '</button><button type="button" class="btn primary" id="rc-print">' + icon('file') + esc(t('Imprimer')) + '</button>' });
            TP.qs('#rc-print', m.el).onclick = () => { document.body.classList.add('rc-printing'); const done = () => { document.body.classList.remove('rc-printing'); window.removeEventListener('afterprint', done); }; window.addEventListener('afterprint', done); window.print(); };
          } catch (e) { TP.toast(e.message, 'error'); }
        };
        const out = TP.qs('#rc-rout', pane), go = TP.qs('#rc-rgo', pane);
        const pair = () => 'old=' + encodeURIComponent(TP.qs('#rc-rold', pane).value.trim()) + '&new=' + encodeURIComponent(TP.qs('#rc-rnew', pane).value.trim());
        TP.qs('#rc-rprev', pane).onclick = async () => {
          out.innerHTML = skel(2); go.disabled = true;
          try {
            const d = (await TP.get(API + '/dr/dns-rewrite?' + pair())).data;
            out.innerHTML = d.total ? '<p class="small">' + esc(t('{n} enregistrement(s) pointent encore vers l\'ancienne adresse :', { n: num(d.total) })) + '</p><ul class="rc-changes">' + d.records.slice(0, 100).map((r) => '<li><span class="rc-chip">' + esc(r.type) + '</span><span class="mono small">' + esc(r.name) + ' · ' + esc(r.zone) + '</span></li>').join('') + '</ul>'
              : '<p class="small muted">' + esc(t('Aucun enregistrement ne pointe vers l\'ancienne adresse dans les zones de ce panel.')) + '</p>';
            go.disabled = !d.total;
          } catch (e) { out.innerHTML = alertBox('danger', 'alert', esc(e.message)); }
        };
        go.onclick = async () => {
          const pw = await askPassword(t('Réécriture DNS'), t('Les enregistrements listés seront modifiés et les zones réécrites.'));
          if (pw === null) return;
          try { const r = await TP.post(API + '/dr/dns-rewrite', { old: TP.qs('#rc-rold', pane).value.trim(), new: TP.qs('#rc-rnew', pane).value.trim(), password: pw }); TP.toast(r.msg); out.innerHTML = '<p class="small">' + esc(t('{n} enregistrement(s) modifié(s).', { n: num(r.data.changed) })) + '</p>'; go.disabled = true; }
          catch (e) { TP.toast(e.message, 'error'); }
        };
      }

      function paint() {
        pane.setAttribute('aria-labelledby', 'rc-tab-' + st.tab);
        pane.innerHTML = st.tab === 'protection' ? paneProtection() : st.tab === 'points' ? panePoints() : st.tab === 'queue' ? paneQueue() : paneDr();
        if (st.tab === 'points') bindPoints(); else if (st.tab === 'queue') bindQueue(); else if (st.tab === 'dr') bindDr();
      }
      async function show(tab) {
        st.tab = tab;
        TP.qsa('.rc-tabs [role=tab]', root).forEach((b) => { const on = b.dataset.tab === tab; b.classList.toggle('active', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1; });
        clearTimeout(self.timer);
        paint();
        try {
          if (tab === 'points' && st.objects === null) { await loadObjects(); await loadPoints(); if (!self.dead && st.tab === 'points') paint(); }
          if (tab === 'queue' && st.jobs === null) { await loadJobs(); if (!self.dead && st.tab === 'queue') paint(); }
        } catch (e) { pane.innerHTML = alertBox('danger', 'alert', esc(e.message)); }
      }
      const tabBtns = TP.qsa('.rc-tabs [role=tab]', root);
      tabBtns.forEach((b, i) => {
        b.onclick = () => show(b.dataset.tab);
        b.onkeydown = (e) => {
          const rtl = document.documentElement.dir === 'rtl';
          const d = e.key === 'ArrowRight' ? (rtl ? -1 : 1) : e.key === 'ArrowLeft' ? (rtl ? 1 : -1) : e.key === 'Home' ? -i : e.key === 'End' ? tabBtns.length - 1 - i : 0;
          if (!d) return; e.preventDefault();
          const n = tabBtns[(i + d + tabBtns.length) % tabBtns.length]; n.focus(); show(n.dataset.tab);
        };
      });
      await show(st.tab);
      if (q.kind && canRestore) { openWizard({ intent: q.intent === 'full' ? 'full' : 'item', kind: q.kind, ref: q.ref }); history.replaceState(null, '', location.pathname + location.search + '#/restore-center'); }
      else if (q.dr && admin) RC.openDisaster({});
      if (ov.repo.state === 'checking') {
        let tries = 0;
        const again = async () => {
          if (self.dead || tries++ > 8) return;
          try { const r = (await TP.get(API + '/overview')).data.repo; const el = TP.qs('.rc-repo', root); if (el && r.state !== 'checking') { el.outerHTML = repoBanner(r); return; } } catch (e) { }
          setTimeout(again, 2500);
        };
        setTimeout(again, 2000);
      }
    },
  });
})();
