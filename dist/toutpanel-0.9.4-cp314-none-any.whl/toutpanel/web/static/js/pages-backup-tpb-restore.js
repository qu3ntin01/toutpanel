(function () {
  'use strict';
  const t = (s, v) => (TP.t ? TP.t(s, v) : s);
  const esc = (s) => TP.esc(s);
  const icon = (n) => TP.icon(n);
  const API = '/api/backup-server/restore';
  const CONFIRM = 'RESTAURER';
  const UT = () => TP.uiTable;
  const SCOPE_CLS = { site: 'info', database: 'violet', mailbox: 'ok', mail_domain: 'ok', account: 'warn', server: 'danger', path: '' };
  const scopeLabel = (s) => ({ site: t('Site'), database: t('Base'), mailbox: t('Boîte mail'), mail_domain: t('Domaine mail'), account: t('Compte'), server: t('Serveur'), path: t('Dossier') }[s] || s);
  const tagLabel = (g) => (g === 'pre-op' ? t('sécurité') : g === 'plan' ? t('planifiée') : t('manuelle'));
  const target = (x) => (x.scope === 'server' && x.target === 'serveur' ? t('Serveur') : x.target);
  const BLOB_MAX = 512 * 1024 * 1024;

  const R = TP.tpbRestore = {};

  async function download(it, items) {
    const q = (items || []).map((i) => 'items=' + encodeURIComponent(i)).join('&');
    const url = API + '/' + it.id + '/download' + (q ? '?' + q : '');
    if (it.size > BLOB_MAX) { const a = document.createElement('a'); a.href = url; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); return; }
    let res;
    try { res = await fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'ToutPanel', 'X-TP-Lang': TP.lang } }); } catch (e) { throw new Error(t('Serveur injoignable')); }
    if (!res.ok) { let m = 'HTTP ' + res.status; try { m = (await res.json()).msg || m; } catch (e) { } throw new Error(m); }
    const cd = res.headers.get('Content-Disposition') || '';
    const name = (/filename="?([^";]+)"?/.exec(cd) || [])[1] || 'toutpanel-backup.zip';
    const blob = await res.blob();
    const href = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = href; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(href), 4000);
  }

  R.openWizard = async function (it, opts) {
    opts = opts || {};
    const isAdmin = !!opts.isAdmin;
    const st = { i: 0, mode: 'all', sel: new Set(), target: it.inplace.ok ? 'inplace' : 'folder', folder: '', database: '', confirm: '', cur: '', dbs: null, busy: false };
    if (!it.inplace.ok && isAdmin && opts.restoreRoot) st.folder = opts.restoreRoot.replace(/\/$/, '') + '/' + it.short;
    const hasDumps = it.dumps && it.dumps.length > 0;
    const titles = [t('Quoi restaurer'), t('Où restaurer'), t('Confirmer')];
    const m = TP.modal({ title: t('Restaurer depuis ToutPanel Backup') + ' · ' + target(it), size: 'lg assist', sticky: true, body: '<div class="as-root" id="tr-root"></div>', footer: '<div class="as-foot"></div>' });
    const bg = m.el; bg.classList.add('assist-bg');
    const box = TP.qs('#tr-root', bg), foot = TP.qs('.as-foot', bg), dlg = TP.qs('.modal', bg);
    foot.parentNode.classList.add('as-modal-f');
    box.setAttribute('aria-live', 'polite');
    const live = document.createElement('div'); live.className = 'sr-only'; live.setAttribute('role', 'status'); live.setAttribute('aria-live', 'polite'); dlg.appendChild(live);
    const say = (s) => { live.textContent = ''; setTimeout(() => { live.textContent = s; }, 30); };
    const fld = (n, label, value, ph, hint) => '<div class="as-field"><label for="tr-' + n + '">' + esc(label) + '</label>' + (hint ? '<div class="hint" id="tr-' + n + '-h">' + hint + '</div>' : '') +
      '<input class="input mono" id="tr-' + n + '" name="' + n + '" type="text" autocomplete="off" spellcheck="false" value="' + esc(value) + '" placeholder="' + esc(ph || '') + '"' + (hint ? ' aria-describedby="tr-' + n + '-h"' : '') + '></div>';
    const sel = (n, label, value, options, hint) => '<div class="as-field"><label for="tr-' + n + '">' + esc(label) + '</label>' + (hint ? '<div class="hint" id="tr-' + n + '-h">' + hint + '</div>' : '') + '<select class="input" id="tr-' + n + '" name="' + n + '"' +
      (hint ? ' aria-describedby="tr-' + n + '-h"' : '') + '>' + options.map((o) => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(value) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select></div>';
    const alert = (cls, ic, html) => '<div class="alert ' + cls + ' mb">' + icon(ic) + '<div>' + html + '</div></div>';
    const h = (s, why) => '<h4 class="as-h" id="tr-h" tabindex="-1">' + esc(s) + '</h4>' + (why ? '<p class="as-why">' + icon('info') + '<span>' + why + '</span></p>' : '');
    const head = () => '<div class="as-head"><div class="as-top"><div class="as-prog-txt">' + t('Étape {i} sur {n}', { i: st.i + 1, n: titles.length }) + ' <span class="muted">· ' + esc(titles[st.i]) + '</span></div></div>' +
      '<ol class="as-dots" aria-label="' + esc(t('Étapes')) + '">' + titles.map((s, i) => '<li class="' + (i === st.i ? 'on' : i < st.i ? 'done' : '') + '"' + (i === st.i ? ' aria-current="step"' : '') + '><span class="as-dot" title="' + esc(s) + '"></span><span class="as-dl">' + esc(s) + '</span></li>').join('') + '</ol>' +
      '<div class="as-bar" aria-hidden="true"><i style="width:' + Math.round(((st.i + 0.5) / titles.length) * 100) + '%"></i></div></div>';
    function setFoot(parts) {
      foot.innerHTML = parts.map((p) => p === 'spacer' ? '<span class="spacer"></span>' : '<button type="button" class="btn' + (p.cls ? ' ' + p.cls : '') + '" id="' + p.id + '"' + (p.disabled ? ' disabled' : '') + '>' + (p.icon ? icon(p.icon) : '') + esc(p.label) + '</button>').join('');
      parts.forEach((p) => { if (p !== 'spacer' && p.run) TP.qs('#' + p.id, foot).onclick = p.run; });
    }
    const destructive = () => st.target === 'inplace' || !!st.database;
    const summary = () => {
      const what = st.mode === 'all' ? t('tout l\'instantané') : t('{n} élément(s) choisi(s)', { n: st.sel.size });
      const where = st.target === 'inplace' ? t('sur place : {l}', { l: it.inplace.label }) : t('dans le dossier {d}', { d: st.folder });
      return { what, where };
    };

    async function loadDir(path) {
      const list = TP.qs('[data-list]', box);
      if (!list) return;
      list.innerHTML = TP.loading();
      try {
        const d = (await TP.get('/api/backups/' + it.id + '/browse?path=' + encodeURIComponent(path))).data;
        st.cur = d.path;
        const parts = st.cur ? st.cur.split('/') : [];
        TP.qs('[data-crumb]', box).innerHTML = '<a href="#" data-nav="">/</a>' + parts.map((p, i) => ' / <a href="#" data-nav="' + esc(parts.slice(0, i + 1).join('/')) + '">' + esc(p) + '</a>').join('') + ' <span class="muted">· ' + t('{n} fichier(s) au total', { n: d.files }) + '</span>';
        list.innerHTML = TP.table([
          { label: '', render: (e) => '<input type="checkbox" data-pick="' + esc(e.path) + '"' + (st.sel.has(e.path) ? ' checked' : '') + ' aria-label="' + esc(e.name) + '">' },
          { label: t('Nom'), render: (e) => e.type === 'dir' ? '<a href="#" data-nav="' + esc(e.path) + '">' + icon('folder') + ' ' + esc(e.name) + '</a>' : icon('file') + ' ' + esc(e.name) + (d.dumps.includes(e.path) ? ' ' + TP.badge(t('dump'), 'violet') : '') },
          { label: t('Taille'), cls: 'r', render: (e) => TP.fmtBytes(e.size) + (e.type === 'dir' ? ' <span class="muted small">(' + e.count + ')</span>' : '') },
        ], d.entries, { empty: t('Dossier vide'), icon: 'folder' });
        TP.qsa('[data-nav]', box).forEach((a) => a.onclick = (ev) => { ev.preventDefault(); loadDir(a.dataset.nav); });
        TP.qsa('[data-pick]', box).forEach((c) => c.onchange = () => { if (c.checked) st.sel.add(c.dataset.pick); else st.sel.delete(c.dataset.pick); updCount(); });
      } catch (e) { list.innerHTML = alert('danger', 'alert', esc(e.message)); }
    }
    const updCount = () => {
      const c = TP.qs('[data-count]', box), nx = TP.qs('#tr-next', foot);
      if (c) c.textContent = st.sel.size ? t('{n} élément(s) sélectionné(s)', { n: st.sel.size }) : t('Cochez au moins un élément');
      if (nx) nx.disabled = st.mode === 'pick' && !st.sel.size;
    };
    function stepWhat() {
      return h(t('Quoi restaurer'), t('Tout l\'instantané, ou seulement des fichiers et dossiers que vous cochez dans son contenu.')) +
        '<div class="as-fields"><label class="check" style="display:flex;gap:8px;align-items:flex-start"><input type="radio" name="mode" value="all"' + (st.mode === 'all' ? ' checked' : '') + '> <span><b>' + t('Tout l\'instantané') + '</b><div class="small muted">' + esc(target(it)) + ' · ' + esc(TP.fmtBytes(it.size)) + '</div></span></label>' +
        '<label class="check" style="display:flex;gap:8px;align-items:flex-start"><input type="radio" name="mode" value="pick"' + (st.mode === 'pick' ? ' checked' : '') + '> <span><b>' + t('Choisir des éléments') + '</b><div class="small muted">' + t('Parcourez le contenu de l\'instantané et cochez ce qu\'il faut récupérer.') + '</div></span></label></div>' +
        '<div data-tree style="' + (st.mode === 'pick' ? '' : 'display:none') + '" class="mt"><div data-crumb class="small mono mb"></div><div data-list style="max-height:36vh;overflow:auto"></div><div class="small muted mt" data-count></div></div>';
    }
    function bindWhat() {
      TP.qsa('[name=mode]', box).forEach((r) => r.onchange = () => {
        st.mode = r.value; TP.qs('[data-tree]', box).style.display = st.mode === 'pick' ? '' : 'none';
        if (st.mode === 'pick' && !TP.qs('[data-list] table, [data-list] .uit', box)) loadDir(st.cur);
        updCount();
      });
      if (st.mode === 'pick') loadDir(st.cur);
      updCount();
    }

    async function ensureDbs() {
      if (st.dbs !== null) return;
      try { st.dbs = ((await TP.get('/api/databases')).data.databases || []).map((d) => [String(d.id), d.name + ' (' + d.engine + ')']); } catch (e) { st.dbs = []; }
    }
    function stepWhere() {
      const inpl = it.inplace.ok;
      const dbOpts = [['', st.target === 'inplace' ? t('Base d\'origine') : t('Ne pas importer : copier le dump dans le dossier')]].concat(st.dbs || []);
      return h(t('Où restaurer'), t('Sur place remplace les données actuelles, après une sauvegarde de sécurité. Un dossier ne touche à rien d\'existant.')) +
        '<div class="as-fields">' +
        '<label class="check" style="display:flex;gap:8px;align-items:flex-start;' + (inpl ? '' : 'opacity:.6') + '"><input type="radio" name="target" value="inplace"' + (st.target === 'inplace' ? ' checked' : '') + (inpl ? '' : ' disabled') + '> <span><b>' + t('Sur place') + '</b>' +
        '<div class="small muted">' + (inpl ? t('Remplace les données actuelles de « {l} » (même emplacement qu\'à la sauvegarde).', { l: esc(it.inplace.label) }) : t('Indisponible pour cet instantané : l\'objet sauvegardé n\'existe plus ou n\'est pas à vous. Choisissez un dossier.')) + '</div></span></label>' +
        '<label class="check" style="display:flex;gap:8px;align-items:flex-start"><input type="radio" name="target" value="folder"' + (st.target === 'folder' ? ' checked' : '') + '> <span><b>' + t('Dans un dossier') + '</b>' +
        '<div class="small muted">' + t('Les fichiers sont extraits dans le dossier choisi ; rien n\'est remplacé.') + '</div></span></label>' +
        '<div data-f style="' + (st.target === 'folder' ? '' : 'display:none') + '">' + fld('folder', t('Dossier de destination'), st.folder, isAdmin ? (opts.restoreRoot || '/restauration') + '/' + it.short : '/www/wwwroot/site/restauration') + '</div>' +
        (hasDumps ? '<div data-d>' + sel('database', t('Base cible des dumps'), st.database, dbOpts, t('Les dumps restaurés sont réimportés dans cette base (existante) ; son contenu actuel est remplacé.')) + '</div>' : '') +
        (inpl && st.target === 'inplace' ? '<div data-safe>' + (opts.safety ? alert('info', 'shield', t('Une sauvegarde de sécurité de l\'état actuel est créée avant tout remplacement (étiquette « sécurité »).')) : alert('warn', 'alert', t('Les sauvegardes de sécurité sont désactivées (Sauvegardes › Options) : aucune copie de l\'état actuel ne sera faite.'))) + '</div>' : '') +
        '</div>';
    }
    function readWhere() {
      const tg = TP.qs('[name=target]:checked', box); if (tg) st.target = tg.value;
      const f = TP.qs('[name=folder]', box); if (f) st.folder = f.value.trim();
      const d = TP.qs('[name=database]', box); if (d) st.database = d.value;
    }
    function bindWhere() {
      TP.qsa('[name=target]', box).forEach((r) => r.onchange = () => { readWhere(); render(); });
      TP.qsa('[name=folder],[name=database]', box).forEach((el) => { el.onchange = readWhere; el.oninput = () => { readWhere(); chkNext(); }; });
      chkNext();
    }
    const chkNext = () => { const nx = TP.qs('#tr-next', foot); if (nx) nx.disabled = st.target === 'folder' && !st.folder; };

    function stepConfirm() {
      const s = summary();
      return h(t('Confirmer'), t('Relisez ce qui va se passer.')) +
        '<ul style="list-style:none;padding:0;margin:0 0 .8rem"><li><b>' + t('Instantané') + '</b> ' + esc(it.target) + ' · ' + esc(TP.fmtDate(it.time)) + ' · <span class="mono">' + esc(it.short) + '</span></li>' +
        '<li><b>' + t('Contenu') + '</b> ' + esc(s.what) + '</li><li><b>' + t('Destination') + '</b> ' + esc(s.where) + '</li>' +
        (st.database ? '<li><b>' + t('Base cible') + '</b> ' + esc(((st.dbs || []).find((d) => d[0] === st.database) || [0, '#' + st.database])[1]) + '</li>' : '') + '</ul>' +
        (st.mode === 'pick' ? '<details class="mb"><summary class="small">' + t('{n} élément(s) choisi(s)', { n: st.sel.size }) + '</summary><ul class="small mono">' + Array.from(st.sel).slice(0, 50).map((p) => '<li>' + esc(p) + '</li>').join('') + '</ul></details>' : '') +
        (st.target === 'inplace' ? alert('info', 'eye', t('« Simuler » ne modifie rien : le compte rendu indique ce qui serait créé, remplacé ou conservé.')) : '') +
        (destructive() ? alert('danger', 'alert', '<b>' + t('Les données actuelles seront remplacées.') + '</b> ' + (st.target === 'inplace' && opts.safety ? t('Une sauvegarde de sécurité est créée avant.') : t('Aucune sauvegarde de sécurité automatique pour cette cible.'))) +
          '<div class="as-field"><label for="tr-confirm">' + t('Tapez {w} pour confirmer', { w: CONFIRM }) + '</label><input class="input mono" id="tr-confirm" name="confirm" autocomplete="off" spellcheck="false" value="' + esc(st.confirm) + '"></div>'
          : alert('info', 'info', t('Rien n\'est remplacé : les fichiers sont extraits dans le dossier.')));
    }
    function bindConfirm() {
      const c = TP.qs('#tr-confirm', box), go = TP.qs('#tr-go', foot);
      if (c) c.oninput = () => { st.confirm = c.value.trim(); go.disabled = st.confirm !== CONFIRM; };
    }

    async function go(simulate) {
      if (st.busy) return; st.busy = true;
      const goBtn = TP.qs(simulate ? '#tr-sim' : '#tr-go', foot); if (goBtn) TP.btnLoading(goBtn, true);
      try {
        const body = { items: st.mode === 'pick' ? Array.from(st.sel) : [], target: st.target, folder: st.target === 'folder' ? st.folder : '', confirm: destructive() && !simulate ? st.confirm : '' };
        if (st.database) body.database = Number(st.database);
        if (simulate) body.simulate = true;
        const r = await TP.post(API + '/' + it.id + '/run', body);
        if (simulate) { TP.taskModal(r.data.task_id, t('Simulation'), null); }
        else { m.close(); TP.taskModal(r.data.task_id, t('Restauration'), opts.onDone); }
      } catch (e) { TP.toast(e.message, 'error'); }
      if (goBtn) TP.btnLoading(goBtn, false);
      st.busy = false;
    }

    async function render() {
      if (st.i === 1 && hasDumps) await ensureDbs();
      const body = [stepWhat, stepWhere, stepConfirm][st.i]();
      box.innerHTML = head() + '<div class="as-pane">' + body + '</div>';
      const parts = [];
      if (st.i > 0) parts.push({ id: 'tr-back', label: t('Retour'), run: () => { if (st.i === 1) readWhere(); st.i--; render(); } });
      parts.push('spacer', { id: 'tr-cancel', label: t('Annuler'), run: m.close });
      if (st.i < 2) parts.push({ id: 'tr-next', label: t('Suivant'), cls: 'primary', run: () => { if (st.i === 1) readWhere(); st.i++; render(); } });
      else {
        if (st.target === 'inplace') parts.push({ id: 'tr-sim', label: t('Simuler'), icon: 'eye', run: () => go(true) });
        parts.push({ id: 'tr-go', label: destructive() ? t('Restaurer maintenant') : t('Extraire dans le dossier'), icon: 'refresh', cls: destructive() ? 'danger' : 'primary', disabled: destructive() && st.confirm !== CONFIRM, run: () => go(false) });
      }
      setFoot(parts);
      if (st.i === 0) bindWhat(); else if (st.i === 1) bindWhere(); else bindConfirm();
      say(titles[st.i]);
      const hh = TP.qs('#tr-h', box); if (hh) hh.focus({ preventScroll: true });
    }
    render();
    return m;
  };

  R.openServer = async function (it, opts) {
    opts = opts || {};
    let plan;
    try { plan = (await TP.get(API + '/' + it.id + '/server-plan')).data; } catch (e) { TP.toast(e.message, 'error'); return; }
    const steps = plan.steps.map((s, i) => '<li style="margin:.35rem 0"><label class="check"><input type="checkbox" data-step="' + esc(s.category) + '"' + (s.manual || s.category === 'panel' ? ' disabled' : ' checked') + '> <span><b>' + (i + 1) + '. ' + esc(t(s.label)) + '</b> <span class="muted small">· ' + t('{n} fichier(s)', { n: s.files }) + (s.services.length ? ' · ' + t('rechargement') + ' : ' + esc(s.services.join(', ')) : '') + '</span>' +
      (s.category === 'panel' ? '<div class="small muted">' + t('Base, réglages et clé du panel : jamais écrasés depuis le panel en marche. En ligne de commande, panel arrêté : toutpanel backup restore-server FICHIER --apply --panel') + '</div>' : '') +
      (s.manual ? '<div class="small muted">' + t('Règles restaurées avec la base du panel ; utilisez ensuite Pare-feu → Réappliquer. Les exports nftables / iptables servent de référence.') + '</div>' : '') + '</span></label></li>').join('');
    TP.modal({ title: t('Restauration du serveur entier') + ' · ' + it.short, size: 'lg',
      body: '<div class="alert info mb">' + icon('info') + '<div>' + t('Sauvegarde du {d}{h}. La configuration est restaurée dans cet ordre ; chaque fichier remplacé est conservé sous le nom « fichier.pre-restore-AAAAMMJJ… » ; nginx est testé avant rechargement. Commencez par une simulation.', { d: TP.fmtDate(plan.created), h: plan.hostname ? ' · ' + esc(plan.hostname) : '' }) + '</div></div>' +
        '<ol style="list-style:none;padding:0;margin:.6rem 0">' + steps + '</ol>' +
        '<details class="mt"><summary><b>' + t('Procédure complète sur un serveur neuf') + '</b></summary><ol class="small" style="margin:.5rem 0 0 1.2rem">' + plan.procedure.map((x) => '<li>' + esc(t(x)) + '</li>').join('') + '</ol></details>' +
        '<details class="mt"><summary><b>' + t('Ce que la sauvegarde ne contient PAS') + '</b></summary><ul class="small" style="margin:.5rem 0 0 1.2rem">' + plan.not_included.map((x) => '<li>' + esc(t(x)) + '</li>').join('') + '</ul></details>' +
        '<div class="field mt"><label for="trs-confirm">' + t('Tapez {w} pour confirmer', { w: CONFIRM }) + ' <span class="muted small">(' + t('uniquement pour appliquer') + ')</span></label><input class="input mono" id="trs-confirm" name="confirm" autocomplete="off" spellcheck="false"></div>',
      footer: '<button class="btn" data-close>' + t('Fermer') + '</button><button class="btn" data-sim>' + icon('eye') + t('Simuler') + '</button><button class="btn danger" data-apply disabled>' + icon('refresh') + t('Restaurer la configuration') + '</button>',
      onOpen: (bg, close) => {
        const conf = TP.qs('#trs-confirm', bg), apply = TP.qs('[data-apply]', bg);
        conf.oninput = () => { apply.disabled = conf.value.trim() !== CONFIRM; };
        const run = async (doApply) => {
          const chosen = TP.qsa('[data-step]:checked', bg).map((c) => c.dataset.step);
          if (!chosen.length) { TP.toast(t('Choisissez au moins une étape'), 'error'); return; }
          try {
            const r = await TP.post(API + '/' + it.id + '/server', { steps: chosen, apply: !!doApply, confirm: doApply ? conf.value.trim() : '' });
            TP.taskModal(r.data.task_id, doApply ? t('Restauration guidée') : t('Simulation'), opts.onDone);
          } catch (e) { TP.toast(e.message, 'error'); }
        };
        TP.qs('[data-sim]', bg).onclick = () => run(false);
        apply.onclick = () => run(true);
      } });
  };

  R.mount = function (el, opts) {
    opts = opts || {};
    const f = { q: '', kind: 'all', tag: 'all' };
    let last = null, timer = null, seq = 0;
    el.innerHTML = '<div class="card mb" id="tpbr"><div class="card-h"><h3>' + (opts.mine ? t('Mes instantanés') : t('Instantanés et restauration')) + '</h3><button type="button" class="btn" id="tpbr-refresh">' + icon('refresh') + t('Actualiser') + '</button></div><div class="card-b">' +
      '<p class="small muted">' + (opts.mine ? t('Vos sites, bases et boîtes mail sauvegardés sur ToutPanel Backup : restaurez-les en entier ou fichier par fichier, sur place ou dans un dossier, ou téléchargez-les. Vous ne voyez que les vôtres.')
        : t('Chaque instantané du dépôt peut être restauré en entier ou fichier par fichier, sur place ou dans un dossier, ou téléchargé. Les nouveaux instantanés sont importés automatiquement.')) + '</p>' +
      '<div id="tpbr-note" role="status" aria-live="polite"></div>' +
      '<div class="row wrap mb" style="gap:8px;align-items:center"><input type="search" class="input" id="tpbr-q" style="flex:1;min-width:12rem" aria-label="' + esc(t('Rechercher un instantané')) + '" placeholder="' + esc(t('Rechercher : site, base, hôte, identifiant…')) + '" autocomplete="off">' +
      '<div class="tabs sm" id="tpbr-kinds" role="group" aria-label="' + esc(t('Type')) + '"></div>' +
      '<select class="input" id="tpbr-tag" style="width:auto" aria-label="' + esc(t('Origine')) + '">' + [['all', t('Toutes')], ['manual', t('Manuelles')], ['plan', t('Planifiées')], ['pre-op', t('De sécurité')]].map((o) => '<option value="' + o[0] + '">' + esc(o[1]) + '</option>').join('') + '</select></div>' +
      '<div id="tpbr-list"></div></div></div>';
    const note = (cls, ic, html) => { TP.qs('#tpbr-note', el).innerHTML = html ? '<div class="alert ' + cls + ' mb">' + icon(ic) + '<div>' + html + '</div></div>' : ''; };
    const kinds = () => [['all', t('Tous')], ['site', t('Sites')], ['database', t('Bases')], ['server', t('Serveur')], ['other', t('Autres')]];
    function drawKinds(counts) {
      TP.qs('#tpbr-kinds', el).innerHTML = kinds().map((k) => '<button type="button" data-k="' + k[0] + '"' + (k[0] === f.kind ? ' class="active" aria-pressed="true"' : ' aria-pressed="false"') + '>' + esc(k[1]) + (counts ? ' <span class="muted small">' + (counts[k[0]] || 0) + '</span>' : '') + '</button>').join('');
      TP.qsa('[data-k]', el).forEach((b) => b.onclick = () => { f.kind = b.dataset.k; load(); });
    }
    async function load() {
      const my = ++seq, list = TP.qs('#tpbr-list', el);
      list.innerHTML = TP.loading();
      let d;
      try { d = (await TP.get(API + '/snapshots?q=' + encodeURIComponent(f.q) + '&kind=' + f.kind + '&tag=' + f.tag)).data; } catch (e) { if (my === seq) list.innerHTML = '<div class="alert danger">' + icon('alert') + '<div>' + esc(e.message) + '</div></div>'; return; }
      if (my !== seq) return;
      last = d;
      if (opts.mine && !d.linked) { el.innerHTML = ''; return; }
      drawKinds(d.counts);
      if (d.linked && d.reachable === false) note('warn', 'alert', t('Le serveur de sauvegarde ne répond pas : la liste vient de l\'inventaire du panel et une restauration peut échouer.'));
      const UTc = UT();
      const dash = '<span class="uit-muted">—</span>';
      const unavailable = (x) => x.available === false;
      list.innerHTML = UTc({
        label: t('Instantanés'), rowAttr: (x) => 'data-id="' + x.id + '"',
        cols: [
          { key: 'date', label: t('Date'), w: 150, card: { order: 0 }, cell: (x) => UTc.stack(UTc.trunc(esc(TP.fmtDate(x.time)), { tag: 'b' }), UTc.trunc(esc(x.short), { cls: 'uit-mono' })) },
          { key: 'type', label: t('Type'), rowHeader: true, card: { order: 1, full: true }, cell: (x) => UTc.stack(UTc.trunc(esc(target(x)), { tag: 'b' }),
            UTc.pills([{ w: 102 }, { w: 84 }, { fill: true }], [UTc.pill(scopeLabel(x.scope), SCOPE_CLS[x.scope] || ''), UTc.pill(tagLabel(x.tag), x.tag === 'pre-op' ? 'warn' : ''),
              unavailable(x) ? UTc.pill(t('Absent du dépôt'), 'danger', { tip: t('Cet instantané n\'existe plus sur le serveur (rétention) : il ne peut pas être restauré.') }) : x.profile === 'full' ? UTc.pill(t('configuration comprise'), 'violet', { icon: 'settings' }) : x.adopted ? UTc.pill(t('importé'), 'info', { tip: t('Importé du dépôt') }) : '']) ) },
          { key: 'host', label: t('Hôte'), w: 120, card: { order: 2 }, cell: (x) => x.host ? UTc.trunc(esc(x.host), { cls: 'uit-mono' }) : (x.owner ? UTc.trunc(esc(x.owner)) : dash) },
          { key: 'size', label: t('Taille'), w: 84, end: true, card: { order: 3 }, cell: (x) => UTc.trunc(esc(x.size ? TP.fmtBytes(x.size) : '—')) },
          { key: 'actions', label: t('Actions'), srLabel: true, w: UTc.actsWidth(3), card: { order: 9, full: true }, cell: (x) => UTc.rowActs([
            unavailable(x) ? null : { act: 'restore', icon: 'refresh', label: t('Restaurer…') },
            x.guided && !unavailable(x) ? { act: 'srv', icon: 'tool', label: t('Restauration du serveur entier…') } : null,
            x.downloadable && !unavailable(x) && TP.can('backups', 'download') ? { act: 'dl', icon: 'download', label: t('Télécharger') } : null], x.id, target(x)) },
        ],
        rows: d.items, empty: d.linked ? (f.q || f.kind !== 'all' || f.tag !== 'all' ? t('Aucun instantané ne correspond à cette recherche') : t('Aucun instantané pour le moment')) : t('ToutPanel Backup n\'est pas relié'), icon: 'backup',
      });
      TP.qsa('[data-a]', list).forEach((b) => b.onclick = async () => {
        const x = d.items.find((i) => String(i.id) === b.dataset.id); if (!x) return;
        const a = b.dataset.a;
        if (a === 'restore') R.openWizard(x, { isAdmin: d.is_admin, safety: d.safety, restoreRoot: d.restore_root, onDone: opts.onDone || load });
        else if (a === 'srv') R.openServer(x, { onDone: opts.onDone || load });
        else if (a === 'dl') { TP.btnLoading(b, true); try { await download(x); } catch (e) { TP.toast(e.message, 'error'); } TP.btnLoading(b, false); }
      });
    }
    async function sync(announce) {
      if (!opts.isAdmin) { load(); return; }
      const btn = TP.qs('#tpbr-refresh', el); TP.btnLoading(btn, true);
      try {
        const r = (await TP.post(API + '/sync')).data;
        const found = r.found === 0 ? t('Aucun instantané sur le serveur pour le moment. Lancez une sauvegarde pour en créer un.') : r.found === 1 ? t('{n} instantané trouvé sur le serveur.', { n: r.found }) : t('{n} instantanés trouvés sur le serveur.', { n: r.found });
        note('info', 'info', esc(found) + (r.added ? ' ' + esc(t('Importés automatiquement : {m}.', { m: r.added })) : ''));
      } catch (e) { note('warn', 'alert', esc(e.message)); }
      TP.btnLoading(btn, false);
      load();
    }
    TP.qs('#tpbr-refresh', el).onclick = () => sync(true);
    TP.qs('#tpbr-q', el).oninput = (ev) => { clearTimeout(timer); timer = setTimeout(() => { f.q = ev.target.value.trim(); load(); }, 250); };
    TP.qs('#tpbr-tag', el).onchange = (ev) => { f.tag = ev.target.value; load(); };
    drawKinds(null);
    sync(false);
    return { reload: load, state: () => last };
  };
})();
