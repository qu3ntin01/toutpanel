/* Chargé dans <head>, avant le rendu : attributs que le site pose sur <html> et dont ses feuilles dépendent
   (le thème clair / sombre vient de assets/tp/theme.js, copie du script du site). */
(function () {
  var r = document.documentElement;
  r.setAttribute("data-accent", "blue");
  r.classList.add("tp-docs");
})();
