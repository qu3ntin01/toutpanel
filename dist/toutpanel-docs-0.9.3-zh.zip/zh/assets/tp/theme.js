/* Thème clair / sombre / système du site.
   Chargé dans <head> (compatible CSP script-src 'self') : applique la préférence AVANT le rendu, puis gère les sélecteurs
   (tout élément [data-th] d'un groupe [data-theme-seg] ou #theme-seg : barre du haut et menu replié). Aucune autre dépendance :
   assets/app.js ne touche plus au thème. La préférence est mémorisée dans localStorage (clé tp-site-theme), toujours sous
   try/catch : navigation privée, stockage bloqué ou cookies refusés ne cassent ni l'affichage ni le sélecteur (le choix vaut
   alors jusqu'au rechargement). */
(function (win, doc) {
  'use strict';
  var KEY = 'tp-site-theme';
  var VALID = { light: 1, dark: 1, system: 1 };
  var memo = null; // choix de la page quand localStorage est inaccessible
  var root = doc.documentElement;

  function readPref() {
    try {
      var s = win.localStorage.getItem(KEY);
      if (VALID[s] === 1) { return s; }
    } catch (e) { /* stockage indisponible */ }
    return memo || 'system';
  }
  function savePref(p) {
    memo = p;
    try { win.localStorage.setItem(KEY, p); return true; } catch (e) { return false; }
  }
  function mql() {
    try { return win.matchMedia ? win.matchMedia('(prefers-color-scheme: dark)') : null; } catch (e) { return null; }
  }
  function prefersDark() { var m = mql(); return !!(m && m.matches); }
  /** Thème effectif (« light » ou « dark ») pour une préférence et l'état du système. */
  function resolve(pref, dark) { return pref === 'dark' || (pref === 'system' && dark) ? 'dark' : 'light'; }

  function paint(pref, theme) {
    var buttons = doc.querySelectorAll ? doc.querySelectorAll('[data-th]') : [];
    for (var i = 0; i < buttons.length; i++) {
      var on = buttons[i].getAttribute('data-th') === pref;
      if (buttons[i].classList) { buttons[i].classList.toggle('on', on); }
      buttons[i].setAttribute('aria-pressed', on ? 'true' : 'false');
    }
    // Barre du navigateur (Chrome Android) : suit le thème choisi, pas seulement celui du système.
    var metas = doc.querySelectorAll ? doc.querySelectorAll('meta[name="theme-color"]') : [];
    for (var j = 0; j < metas.length; j++) { metas[j].setAttribute('content', theme === 'dark' ? '#150b08' : '#fbf3e6'); }
  }
  /** Applique une préférence à la page (sans l'enregistrer). */
  function apply(pref) {
    if (VALID[pref] !== 1) { pref = 'system'; }
    var theme = resolve(pref, prefersDark());
    root.setAttribute('data-theme', theme);
    root.setAttribute('data-theme-pref', pref);
    paint(pref, theme);
    return theme;
  }
  /** Choix de l'utilisateur : enregistré puis appliqué. */
  function set(pref) {
    if (VALID[pref] !== 1) { return false; }
    savePref(pref);
    apply(pref);
    return true;
  }

  apply(readPref());

  // Clic sur une option : délégation sur le document, donc valable avant la fin du chargement et pour plusieurs sélecteurs.
  doc.addEventListener('click', function (ev) {
    var el = ev.target && ev.target.closest ? ev.target.closest('[data-th]') : null;
    if (el && VALID[el.getAttribute('data-th')] === 1) { set(el.getAttribute('data-th')); }
  });
  // État des boutons dès que le DOM existe.
  if (doc.readyState === 'loading') { doc.addEventListener('DOMContentLoaded', function () { apply(readPref()); }); }
  // « Système » : suit le changement de thème de l'appareil en direct.
  var m = mql();
  if (m) {
    var onChange = function () { if ((root.getAttribute('data-theme-pref') || 'system') === 'system') { apply('system'); } };
    if (m.addEventListener) { m.addEventListener('change', onChange); } else if (m.addListener) { m.addListener(onChange); }
  }
  // Autre onglet : le choix y est repris.
  win.addEventListener('storage', function (ev) { if (ev.key === KEY || ev.key === null) { apply(readPref()); } });

  /* ---- Animations de saison (pluie, feuilles, fond animé, parallaxe) : interrupteur « Animations » ----
     Préférence « on » / « off » dans localStorage (tp-site-anim) ET dans le cookie tp_anim, toujours sous try/catch. Sans choix, les animations
     sont COUPÉES quand le système demande moins de mouvement (prefers-reduced-motion) et actives sinon. <html data-anim="on|off"> (+ data-motion="off"
     qui réaffiche tout le contenu sans mouvement) est posé AVANT le rendu ; assets/autumn.js écoute l'événement « tp:anim » et arrête tout travail
     (requestAnimationFrame, vidéo de fond) quand l'état est « off », que l'onglet est caché ou que l'appareil économise l'énergie. */
  var AKEY = 'tp-site-anim';
  var amemo = null;
  function reduced() { try { return !!(win.matchMedia && win.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } }
  function readAnim() {
    var v = null;
    try { v = win.localStorage.getItem(AKEY); } catch (e) { /* stockage indisponible */ }
    if (v !== 'on' && v !== 'off') {
      try { var m = /(?:^|;\s*)tp_anim=(on|off)/.exec(doc.cookie || ''); v = m ? m[1] : null; } catch (e) { v = null; }
    }
    return v === 'on' || v === 'off' ? v : (amemo || (reduced() ? 'off' : 'on'));
  }
  function saveAnim(v) {
    amemo = v;
    try { win.localStorage.setItem(AKEY, v); } catch (e) { /* ignoré */ }
    try { doc.cookie = 'tp_anim=' + v + '; path=/; max-age=31536000; SameSite=Lax'; } catch (e) { /* ignoré */ }
  }
  function paintAnim(v) {
    var on = v === 'on';
    root.setAttribute('data-anim', v);
    root.setAttribute('data-motion', on ? 'on' : 'off');
    var bs = doc.querySelectorAll ? doc.querySelectorAll('[data-anim-toggle]') : [];
    for (var i = 0; i < bs.length; i++) {
      bs[i].setAttribute('aria-pressed', on ? 'true' : 'false');
      if (bs[i].classList) { bs[i].classList.toggle('on', on); }
      var tt = bs[i].getAttribute(on ? 'data-title-on' : 'data-title-off');
      if (tt) { bs[i].setAttribute('title', tt); }
    }
  }
  function applyAnim(v, notify) {
    paintAnim(v);
    if (notify) {
      var ev; try { ev = new win.CustomEvent('tp:anim', { detail: { state: v } }); } catch (e) { ev = null; }
      if (ev && win.dispatchEvent) { win.dispatchEvent(ev); }
    }
  }
  function setAnim(v) { if (v !== 'on' && v !== 'off') { return false; } saveAnim(v); applyAnim(v, true); return true; }
  applyAnim(readAnim(), false);
  doc.addEventListener('click', function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest('[data-anim-toggle]') : null;
    if (b) { setAnim(readAnim() === 'on' ? 'off' : 'on'); }
  });
  if (doc.readyState === 'loading') { doc.addEventListener('DOMContentLoaded', function () { paintAnim(readAnim()); }); }
  win.addEventListener('storage', function (ev) { if (ev.key === AKEY || ev.key === null) { applyAnim(readAnim(), true); } });
  win.tpAnim = { get: readAnim, set: setAnim };

  /* ---- Thème « Black Friday » (inc/blackfriday.php) : seulement si le serveur a posé <html data-event="blackfriday"> ; les effets (assets/blackfriday.js) sont chargés
     400 ms après la page, jamais avant ; hors période, rien n'est chargé. */
  function loadBlackFriday() {
    if (root.getAttribute('data-event') !== 'blackfriday') { return; }
    var l = doc.querySelector('link[data-bf-js]');
    if (!l) { return; }
    win.setTimeout(function () {
      if (root.getAttribute('data-event') !== 'blackfriday') { return; }
      var s = doc.createElement('script'); s.src = l.getAttribute('data-bf-js'); s.async = true; doc.head.appendChild(s);
    }, 400);
  }
  if (doc.readyState === 'complete') { loadBlackFriday(); } else { win.addEventListener('load', loadBlackFriday); }

  win.tpTheme = { apply: apply, set: set, get: readPref, resolve: resolve };
})(window, document);
