/* Tableau commun du panel : TP.uiTable(options) renvoie le HTML d'un tableau à colonnes fixes (static/css/ui-table.css).

   Garanties : toutes les lignes ont la même hauteur (une ligne de texte tronquée par « … » avec infobulle, jamais de retour à la ligne), les pastilles et les
   icônes d'actions occupent des emplacements (« slots ») de largeur fixe donc alignés d'une ligne à l'autre, alignement vertical centré, clair / sombre, et
   sous 987 px de largeur du conteneur chaque ligne devient une carte. Pour une page qui n'est pas encore migrée, TP.table (core.js) reste inchangé.

   Usage (voir pages-sites.js) :

     root.innerHTML = '<div class="card">' + TP.uiTable({
       label: t('Sites web'),                              // nom accessible du tableau (aria-label)
       cols: [
         { key: 'site', label: t('Site'), cell: (s) => TP.uiTable.stack(line1Html, line2Html), card: { order: 0, full: true } },   // sans `w` : prend la place restante
         { key: 'type', label: t('Type'), w: 150, cell: (s) => TP.uiTable.pills([{ fill: true }], [TP.uiTable.pill('PHP 8.3', 'info', { tip: '…' })]), card: { order: 1 } },
         { key: 'root', label: t('Racine'), w: 170, wide: true, cell: (s) => TP.uiTable.trunc(TP.esc(s.root), { cls: 'uit-mono' }) },   // `wide` : masquée sous 1237 px
         { key: 'size', label: t('Taille'), w: 84, end: true, cell: (s) => TP.esc(s.size) },                                           // `end` : alignée à la fin (nombres)
         { key: 'act', label: t('Actions'), srLabel: true, w: TP.uiTable.actsWidth(3), cell: (s) => TP.uiTable.acts([ … 3 emplacements, null = vide … ]), card: { order: 9, full: true } },
       ],
       rows: sites, rowAttr: (s) => 'data-id="' + s.id + '"',
       empty: t('Aucun site'), icon: 'globe', cta: { label: …, target: '#add' },   // mêmes options que TP.table pour l'état vide
     }) + '</div>';

   Option `md: true` : tableau placé dans une colonne étroite (ex. enregistrements DNS à côté de la liste des zones) : les cartes n'apparaissent que sous 720 px (987 px sinon).
   Colonnes : `w` largeur en px (au moins une colonne sans `w`), `wide` (masquée sous 1237 px), `xwide` (masquée sous 1437 px : colonnes les moins utiles des tableaux chargés), `end`, `srLabel` (en-tête réservé aux lecteurs d'écran),
   `card: { order, full }` (rang et pleine largeur dans la carte mobile). Les gestionnaires de clic restent ceux de la page (data-a / data-id comme avant).
   Options du tableau : `dense: true` (listes secondaires à une seule ligne : journal, connexions), `rowAttr`, `id`, `label`. Assistants en plus : `meter(pct)` (jauge d'utilisation),
   `rowActs(items, id, nom)` (rangée d'actions d'une ligne : id, infobulle et nom accessible « Supprimer · nom » ajoutés ; `attr: 'p'` pour une page qui lit data-p="act" data-id,
   ou `attr` sans `act` pour data-<attr>="id" ; `attrs` pour des attributs en plus ; `href` pour un lien). Pages migrées : sites, FTP, messagerie, sauvegardes, tâches planifiées, comptes.
   Les cellules sont du HTML : échapper les données avec TP.esc ; les assistants ci-dessous échappent eux-mêmes leurs arguments texte. */
(function () {
  'use strict';
  const TP = window.TP, t = TP.t;
  const esc = (v) => TP.esc(v == null ? '' : v);

  // ---- assistants de cellule
  // texte sur une seule ligne tronquée ; html déjà échappé ; opts : tag ('span' | 'a' | 'b'), cls, attrs, tip (infobulle fixe, sinon le texte complet si la ligne est tronquée)
  const trunc = (html, opts) => { opts = opts || {}; const tag = opts.tag || 'span'; return '<' + tag + ' class="uit-trunc' + (opts.cls ? ' ' + opts.cls : '') + '"' + (opts.tip ? ' data-uit-tip="' + esc(opts.tip) + '"' : '') + (opts.attrs ? ' ' + opts.attrs : '') + '>' + html + '</' + tag + '>'; };
  // deux lignes empilées (hauteur fixe) : nom + détails ; sans détails, la ligne seule reste centrée
  // une seule ligne, centrée comme la pile (colonnes à une seule valeur) ; html déjà échappé
  const line = (html) => '<div class="uit-l1">' + (html || '') + '</div>';
  const stack = (l1, l2) => '<div class="uit-stack"><div class="uit-l1">' + (l1 || '') + '</div>' + (l2 ? '<div class="uit-l2">' + l2 + '</div>' : '') + '</div>';
  // pastille : tone ok | info | warn | danger | violet | '' ; opts : tip (infobulle), dot (défaut vrai), label (nom accessible),
  // icon (nom d'icône) ou glyph (1 à 2 caractères) : repère rond sans texte visible, `text` sert alors de nom accessible
  const pill = (text, tone, opts) => {
    opts = opts || {};
    const round = !!(opts.icon || opts.glyph);
    const tip = opts.tip || (round ? opts.label || text : '');
    const aria = round ? ' role="img" aria-label="' + esc(opts.label || text) + '"' : '';
    const inner = opts.icon ? TP.icon(opts.icon) : opts.glyph ? esc(opts.glyph) : (opts.dot === false ? '' : '<i class="dot"></i>') + '<span class="uit-trunc">' + esc(text) + '</span>';
    return '<span class="uit-pill ' + (tone || '') + (round ? ' uit-ico' : '') + '"' + (tip ? ' data-uit-tip="' + esc(tip) + '"' : '') + aria + '>' + inner + '</span>';
  };
  // rangée de pastilles sur une grille régulière : slots = [{ w: largeur px } | { fill: true }], items = une pastille (HTML) ou null par emplacement
  const pills = (slots, items) => '<div class="uit-pills">' + slots.map((sl, i) => '<span class="uit-slot' + (sl.fill ? ' uit-fill' : '') + '"' + (sl.w ? ' style="--w:' + Number(sl.w) + 'px"' : '') + '>' + ((items && items[i]) || '') + '</span>').join('') + '</div>';
  // « +N » : éléments supplémentaires listés dans l'infobulle (focusable : le clavier et le tactile y accèdent aussi)
  const more = (n, list) => n > 0 ? '<button type="button" class="uit-more" data-uit-tip="' + esc(list.join('\n')) + '" aria-label="' + esc(t('et {n} autres', { n: n }) + ' : ' + list.join(', ')) + '">+' + n + '</button>' : '';
  // icône d'action : { act, id, icon, label, tone ('' | 'on' | 'warn' | 'danger'), tip (par défaut label), disabled, static (repère non cliquable),
  // attr (autre attribut que data-a : data-<attr>="act" data-id="id", ou data-<attr>="id" sans `act`), href (+ blank, download) : lien au lieu d'un bouton ; attrs : attributs HTML déjà échappés (ex. data-edit="3"), en plus de data-a / data-id (ou à leur place si `act` est absent) }
  const act = (a) => {
    const tone = a.tone ? ' ' + (a.tone === 'on' ? 'is-on' : a.tone) : '';
    if (a.static) return '<span class="uit-act uit-act-static' + tone + '" role="img" aria-label="' + esc(a.label) + '" data-uit-tip="' + esc(a.tip || a.label) + '">' + TP.icon(a.icon) + '</span>';
    const common = ' aria-label="' + esc(a.label) + '" data-uit-tip="' + esc(a.tip || a.label) + '"' + (a.attrs ? ' ' + a.attrs : '');
    if (a.href) return '<a class="uit-act' + tone + '" href="' + esc(a.href) + '"' + (a.blank ? ' target="_blank" rel="noopener noreferrer"' : '') + (a.download ? ' download="' + esc(a.download) + '"' : '') + common + '>' + TP.icon(a.icon) + '</a>';
    const hook = a.attr && !a.act ? 'data-' + a.attr + '="' + esc(a.id) + '"' : (a.act ? 'data-' + (a.attr || 'a') + '="' + esc(a.act) + '" data-id="' + esc(a.id) + '"' : '');
    return '<button type="button" class="uit-act' + tone + '"' + (hook ? ' ' + hook : '') + common + (a.disabled ? ' disabled' : '') + '>' + TP.icon(a.icon) + '</button>';
  };
  // jauge fine d'utilisation (quota, disque) : pct de 0 à 100, teinte automatique (80 % attention, 95 % danger)
  const meter = (pct) => { pct = Math.max(0, Math.min(100, Number(pct) || 0)); return '<span class="uit-meter' + (pct >= 95 ? ' danger' : pct >= 80 ? ' warn' : '') + '" aria-hidden="true"><i style="width:' + Math.round(pct) + '%"></i></span>'; };
  // rangée d'actions : un emplacement par entrée (null = emplacement vide, la colonne reste alignée)
  const acts = (items) => '<div class="uit-acts" role="group">' + items.map((a) => a ? act(a) : '<span class="uit-act-ph" aria-hidden="true"></span>').join('') + '</div>';
  // rangée d'actions d'une ligne : chaque icône reçoit l'id de la ligne, son libellé comme infobulle et le nom de la ligne dans son nom accessible (« Supprimer · client1 »)
  const rowActs = (items, id, name) => acts(items.map((a) => a && (a.static ? a : Object.assign({ id: id, tip: a.label }, a, { label: a.label + (name ? ' · ' + name : '') }))));
  const actsWidth = (n) => n * 26 + Math.max(0, n - 1) + 24;   // largeur de colonne pour n icônes (26 px + 1 px d'écart + marges de cellule)

  // ---- tableau
  function uiTable(o) {
    const cols = o.cols || [], rows = o.rows;
    if (rows == null) return TP.skeleton(o.skeletonRows || 5, cols.length);
    if (!rows.length) return TP.empty(o.empty || t('Aucun élément'), o.icon, o);
    const cls = (c) => (c.wide ? ' uit-wide' : '') + (c.xwide ? ' uit-xwide' : '') + (c.end ? ' uit-end' : '');
    const sel = o.selectable, sortSt = o.sortState || {};    // vue pilotée (uiTable.view) : cases de sélection et en-têtes triables
    const allSel = sel && rows.length && rows.every((r) => sel.ids.has(String(sel.id(r))));
    const head = (c) => {
      const label = c.srLabel ? '<span class="uit-sr">' + esc(c.label) + '</span>' : '<span class="uit-trunc">' + esc(c.label) + '</span>';
      if (!c.sort || !o.sortState) return '<th role="columnheader" scope="col" class="' + cls(c).trim() + '">' + label + '</th>';
      const on = sortSt.key === c.key;
      return '<th role="columnheader" scope="col" class="' + (cls(c) + ' uit-sortable').trim() + '" aria-sort="' + (on ? (sortSt.dir === 'desc' ? 'descending' : 'ascending') : 'none') + '">' +
        '<button type="button" class="uit-sort' + (on ? ' on ' + (sortSt.dir === 'desc' ? 'desc' : 'asc') : '') + '" data-uit-sort="' + esc(c.key) + '" aria-label="' + esc(t('Trier par {c}', { c: c.label })) + '">' + label + '<i class="uit-sort-ic" aria-hidden="true"></i></button></th>';
    };
    return '<div class="uit' + (o.md ? ' uit-md' : '') + (o.dense ? ' uit-dense' : '') + '"><table class="uit-t" role="table"' + (o.label ? ' aria-label="' + esc(o.label) + '"' : '') + (o.id ? ' id="' + esc(o.id) + '"' : '') + '>' +
      '<colgroup>' + (sel ? '<col style="width:48px">' : '') + cols.map((c) => '<col class="' + (c.wide ? 'uit-wide' : c.xwide ? 'uit-xwide' : '') + '"' + (c.w ? ' style="width:' + Number(c.w) + 'px"' : '') + '>').join('') + '</colgroup>' +
      '<thead role="rowgroup"><tr role="row">' + (sel ? '<th role="columnheader" scope="col" class="uit-selc"><input type="checkbox" class="uit-check" data-uit-all aria-label="' + esc(t('Tout sélectionner')) + '"' + (allSel ? ' checked' : '') + '></th>' : '') + cols.map(head).join('') + '</tr></thead>' +
      '<tbody role="rowgroup">' + rows.map((r) => '<tr role="row"' + (o.rowAttr ? ' ' + o.rowAttr(r) : '') + (sel && sel.ids.has(String(sel.id(r))) ? ' class="uit-sel"' : '') + '>' + (sel ? '<td role="cell" class="uit-selc"><input type="checkbox" class="uit-check" data-uit-sel="' + esc(sel.id(r)) + '" aria-label="' + esc(t('Sélectionner') + (sel.name ? ' · ' + sel.name(r) : '')) + '"' + (sel.ids.has(String(sel.id(r))) ? ' checked' : '') + '></td>' : '') + cols.map((c) => {
        const cd = c.card || {};
        return '<td role="' + (c.rowHeader ? 'rowheader' : 'cell') + '" class="' + (cls(c) + (cd.full ? ' uit-full' : '')).trim() + '"' + (c.srLabel || c.rowHeader || !c.label ? '' : ' data-label="' + esc(c.label) + '"') + (cd.order != null ? ' style="--uit-co:' + Number(cd.order) + '"' : '') + '>' + c.cell(r) + '</td>';
      }).join('') + '</tr>').join('') + '</tbody></table></div>';
  }

  // ---- vue pilotée : recherche, tri par colonne, pagination et actions groupées au-dessus du tableau commun
  //   TP.uiTable.view(hôte, { ...options de uiTable, id: (ligne) => id, search: (ligne) => texte, searchPlaceholder, pageSizes: [10, 25, 50, 100], pageSize: 25,
  //     sort: { key, dir } (tri initial), stateKey (garde recherche, tri et taille de page entre deux rechargements de la page), selectName: (ligne) => nom accessible, bulk: [{ key, label, icon, tone, run: async (lignes) => … }], onRender: (hôte) => … })
  //   Les colonnes triables portent `sort: (ligne) => valeur`. onRender est rappelée après chaque affichage (les gestionnaires data-… de la page y sont posés à nouveau).
  //   Rien n'est recalculé côté serveur : la liste complète est déjà chargée par la page. Rend { refresh(rows), selected() }.
  const fold = (v) => String(v == null ? '' : v).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const memo = {};
  function view(host, o) {
    const sizes = o.pageSizes || [10, 25, 50, 100];
    const stt = { q: '', sort: o.sort ? Object.assign({}, o.sort) : null, size: sizes.includes(o.pageSize) ? o.pageSize : (o.pageSize ? sizes.find((n) => n >= o.pageSize) || sizes[sizes.length - 1] : sizes[1] || sizes[0]), page: 1, sel: new Set() };
    const idOf = (r) => String(o.id(r));
    const coll = new Intl.Collator(TP.lang || undefined, { numeric: true, sensitivity: 'base' });
    const rowsAll = () => o.rows || [];
    const visible = () => {
      let l = rowsAll();
      const toks = fold(stt.q).split(/\s+/).filter(Boolean);
      if (toks.length && o.search) l = l.filter((r) => { const h = fold(o.search(r)); return toks.every((k) => h.includes(k)); });
      const col = stt.sort && (o.cols || []).find((c) => c.key === stt.sort.key && c.sort);
      if (col) {
        const dir = stt.sort.dir === 'desc' ? -1 : 1;
        l = l.map((r, i) => [r, i, col.sort(r)]).sort((a, b) => {
          const x = a[2], y = b[2], ex = x == null || x === '', ey = y == null || y === '';
          if (ex || ey) return ex === ey ? a[1] - b[1] : ex ? 1 : -1;          // valeurs vides toujours en dernier
          const c = typeof x === 'number' && typeof y === 'number' ? x - y : coll.compare(String(x), String(y));
          return c ? c * dir : a[1] - b[1];
        }).map((a) => a[0]);
      }
      return l;
    };
    const keep = o.stateKey ? (memo[o.stateKey] = memo[o.stateKey] || {}) : null;      // recherche, tri et taille de page gardés quand la page se recharge après une action
    if (keep && keep.set) { stt.q = keep.q || ''; stt.sort = keep.sort || null; if (sizes.includes(keep.size)) stt.size = keep.size; }
    const rows0 = rowsAll();
    if (!rows0.length) { host.innerHTML = uiTable(o); if (o.onRender) o.onRender(host); return { refresh: () => {}, selected: () => [] }; }
    const tools = o.search ? '<div class="uit-tools"><div class="uit-search"><span class="uit-search-ic" aria-hidden="true">' + TP.icon('search') + '</span>' +
      '<input type="search" class="input" data-uitv-q value="' + esc(stt.q) + '" placeholder="' + esc(o.searchPlaceholder || t('Rechercher')) + '" aria-label="' + esc(o.searchPlaceholder || t('Rechercher')) + '" autocomplete="off" spellcheck="false"></div>' +
      ((o.cols || []).some((c) => c.sort) ? '<select class="input uit-sortsel" data-uitv-sortsel aria-label="' + esc(t('Trier')) + '"><option value="">' + esc(t('Trier')) + '</option>' +
        (o.cols || []).filter((c) => c.sort).map((c) => ['asc', 'desc'].map((d) => '<option value="' + esc(c.key) + ':' + d + '">' + esc(c.label) + (d === 'asc' ? ' ↑' : ' ↓') + '</option>').join('')).join('') + '</select>' : '') +
      '<span class="uit-count small muted" data-uitv-count role="status" aria-live="polite"></span></div>' : '';
    host.innerHTML = '<div class="uit-view">' + tools + '<div data-uitv-body></div></div>';
    const body = TP.qs('[data-uitv-body]', host);
    function draw() {
      const all = rowsAll(), ids = new Set(all.map(idOf));
      stt.sel.forEach((k) => { if (!ids.has(k)) stt.sel.delete(k); });
      if (keep) { keep.set = true; keep.q = stt.q; keep.sort = stt.sort; keep.size = stt.size; }
      const list = visible(), total = list.length, pages = Math.max(1, Math.ceil(total / stt.size));
      stt.page = Math.min(Math.max(1, stt.page), pages);
      const from = (stt.page - 1) * stt.size, slice = list.slice(from, from + stt.size);
      const ss = TP.qs('[data-uitv-sortsel]', host); if (ss) ss.value = stt.sort ? stt.sort.key + ':' + stt.sort.dir : '';
      const cnt = TP.qs('[data-uitv-count]', host);
      if (cnt) cnt.textContent = stt.q.trim() ? t('{n} résultat(s) sur {total}', { n: total, total: all.length }) : '';
      const bulk = o.bulk && stt.sel.size ? '<div class="uit-bulk" role="region" aria-label="' + esc(t('Actions groupées')) + '"><b>' + esc(t('{n} sélectionné(s)', { n: stt.sel.size })) + '</b>' +
        o.bulk.map((b) => '<button type="button" class="btn xs' + (b.tone === 'danger' ? ' danger' : '') + '" data-uitv-bulk="' + esc(b.key) + '">' + (b.icon ? TP.icon(b.icon) : '') + esc(b.label) + '</button>').join('') +
        '<button type="button" class="btn xs" data-uitv-clear>' + esc(t('Tout désélectionner')) + '</button></div>' : '';
      const noHit = !total ? '<div class="uit-nohit">' + TP.empty(t('Aucun résultat pour « {q} »', { q: stt.q.trim() }), 'search') + '<div class="uit-nohit-b"><button type="button" class="btn sm" data-uitv-reset>' + esc(t('Effacer la recherche')) + '</button></div></div>' : '';
      const table = total ? uiTable(Object.assign({}, o, { rows: slice, sortState: stt.sort || {}, selectable: o.bulk ? { ids: stt.sel, id: idOf, name: o.selectName } : null })) : noHit;
      const pager = total > sizes[0] ? '<div class="uit-pager"><label class="small muted">' + esc(t('Par page')) + ' <select class="input" data-uitv-size aria-label="' + esc(t('Par page')) + '">' +
        sizes.map((n) => '<option value="' + n + '"' + (n === stt.size ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></label>' +
        '<span class="small muted uit-pg-info">' + esc(t('{a}–{b} sur {n}', { a: from + 1, b: Math.min(from + stt.size, total), n: total })) + '</span>' +
        '<span class="btn-group"><button type="button" class="btn xs uit-pg-prev" data-uitv-page="-1" aria-label="' + esc(t('Page précédente')) + '"' + (stt.page <= 1 ? ' disabled' : '') + '>' + TP.icon('chevron') + '</button>' +
        '<span class="small uit-pg-n">' + stt.page + ' / ' + pages + '</span>' +
        '<button type="button" class="btn xs uit-pg-next" data-uitv-page="1" aria-label="' + esc(t('Page suivante')) + '"' + (stt.page >= pages ? ' disabled' : '') + '>' + TP.icon('chevron') + '</button></span></div>' : '';
      body.innerHTML = bulk + table + pager;
      const all0 = TP.qs('[data-uit-all]', body);
      if (all0) { const n = slice.filter((r) => stt.sel.has(idOf(r))).length; all0.indeterminate = n > 0 && n < slice.length; }
      if (o.onRender) o.onRender(body);
    }
    const q = TP.qs('[data-uitv-q]', host);
    if (q) q.addEventListener('input', () => { stt.q = q.value; stt.page = 1; draw(); });
    host.addEventListener('click', (e) => {
      const el = e.target.closest && e.target.closest('[data-uit-sort],[data-uitv-page],[data-uitv-clear],[data-uitv-reset],[data-uitv-bulk]');
      if (!el || !host.contains(el)) return;
      if (el.dataset.uitSort) { const k = el.dataset.uitSort; stt.sort = stt.sort && stt.sort.key === k ? (stt.sort.dir === 'asc' ? { key: k, dir: 'desc' } : null) : { key: k, dir: 'asc' }; stt.page = 1; draw(); const nb = TP.qs('[data-uit-sort="' + k + '"]', body); if (nb) nb.focus(); }
      else if (el.dataset.uitvPage) { stt.page += Number(el.dataset.uitvPage); draw(); const nb = TP.qs('[data-uitv-page="' + el.dataset.uitvPage + '"]:not([disabled])', body) || TP.qs('[data-uitv-size]', body); if (nb) nb.focus(); }
      else if (el.hasAttribute('data-uitv-clear')) { stt.sel.clear(); draw(); }
      else if (el.hasAttribute('data-uitv-reset')) { stt.q = ''; if (q) { q.value = ''; q.focus(); } stt.page = 1; draw(); }
      else if (el.dataset.uitvBulk) {
        const b = o.bulk.find((x) => x.key === el.dataset.uitvBulk), rows = rowsAll().filter((r) => stt.sel.has(idOf(r)));
        if (b && rows.length) Promise.resolve(b.run(rows)).catch((err) => TP.toast(err && err.message ? err.message : String(err), 'error'));
      }
    });
    host.addEventListener('change', (e) => {
      const el = e.target;
      if (el.matches && el.matches('[data-uitv-sortsel]')) { const [k, d] = (el.value || ':').split(':'); stt.sort = k ? { key: k, dir: d } : null; stt.page = 1; draw(); }
      else if (el.matches && el.matches('[data-uitv-size]')) { stt.size = Number(el.value) || stt.size; stt.page = 1; draw(); }
      else if (el.matches && el.matches('[data-uit-all]')) {
        const list = visible(), from = (stt.page - 1) * stt.size;
        list.slice(from, from + stt.size).forEach((r) => { if (el.checked) stt.sel.add(idOf(r)); else stt.sel.delete(idOf(r)); });
        draw(); const na = TP.qs('[data-uit-all]', body); if (na) na.focus();
      } else if (el.matches && el.matches('[data-uit-sel]')) {
        if (el.checked) stt.sel.add(el.dataset.uitSel); else stt.sel.delete(el.dataset.uitSel);
        draw(); const nb = TP.qsa('[data-uit-sel]', body).find((x) => x.dataset.uitSel === el.dataset.uitSel); if (nb) nb.focus();
      }
    });
    draw();
    return { refresh: (rows) => { o.rows = rows; draw(); }, selected: () => rowsAll().filter((r) => stt.sel.has(idOf(r))) };
  }
  // exécute une action sur chaque ligne (une à la fois), puis annonce le bilan : « n réussie(s), m échec(s) » + premières erreurs
  async function runEach(rows, fn, label) {
    let ok = 0; const errs = [];
    for (const r of rows) { try { await fn(r); ok++; } catch (e) { errs.push(((label ? label(r) + ' : ' : '') + (e && e.message ? e.message : String(e)))); } }
    TP.toast(t('{ok} réussie(s), {ko} échec(s)', { ok: ok, ko: errs.length }) + (errs.length ? ' — ' + errs.slice(0, 3).join(' ; ') : ''), errs.length ? (ok ? 'warn' : 'error') : '', errs.length ? 9000 : undefined);
    return { ok: ok, errors: errs };
  }
  Object.assign(uiTable, { view, runEach, trunc, line, stack, pill, pills, more, act, acts, rowActs, actsWidth, meter });
  TP.uiTable = uiTable;

  // ---- infobulle unique : survol et focus clavier ; Échap ou défilement la referme ; texte complet des éléments tronqués
  let tip = null, cur = null;
  const pick = (el) => {
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.classList.contains('uit-trunc') && n.scrollWidth > n.clientWidth + 1 && !n.closest('[data-uit-tip]')) return { el: n, text: n.getAttribute('data-uit-full') || n.textContent };
      if (n.hasAttribute('data-uit-tip')) return { el: n, text: n.getAttribute('data-uit-tip') };
      if (n.classList.contains('uit')) break;
    }
    return null;
  };
  const hide = () => { if (!tip) return; tip.classList.remove('on'); if (cur) cur.removeAttribute('aria-describedby'); cur = null; };
  const show = (target) => {
    const p = target.closest && target.closest('.uit') ? pick(target) : null;
    if (!p || !p.text) { hide(); return; }
    if (!tip) { tip = document.createElement('div'); tip.className = 'uit-tooltip'; tip.id = 'uit-tooltip'; tip.setAttribute('role', 'tooltip'); document.body.appendChild(tip); }
    if (cur && cur !== p.el) cur.removeAttribute('aria-describedby');
    cur = p.el; cur.setAttribute('aria-describedby', 'uit-tooltip');
    tip.textContent = p.text;
    const r = p.el.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = window.innerHeight;
    tip.style.left = '0px'; tip.style.top = '0px'; tip.classList.add('on');
    const w = tip.offsetWidth, h = tip.offsetHeight;
    let x = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), Math.max(8, vw - w - 8));
    let y = r.bottom + 6; if (y + h > vh - 8 && r.top - h - 6 >= 8) y = r.top - h - 6;
    tip.style.left = Math.round(x) + 'px'; tip.style.top = Math.round(y) + 'px';
  };
  if (!window.__uitTip) {
    window.__uitTip = true;
    document.addEventListener('mouseover', (e) => { if (e.target.closest) show(e.target); });
    document.addEventListener('mouseout', (e) => { if (cur && (!e.relatedTarget || !cur.contains(e.relatedTarget))) hide(); });
    document.addEventListener('focusin', (e) => show(e.target));
    document.addEventListener('focusout', hide);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });
    window.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    window.addEventListener('hashchange', hide);
  }
})();
